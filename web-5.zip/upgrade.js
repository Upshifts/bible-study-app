/* Scripture — refinement layer (v15).
   Extends the app the same way its earlier layers do (wrapping render/act/view functions); nothing existing is removed.
   1 KJV text repair  2 reader header + text settings  3 verse actions  4 saved Scripture + memorise
   5 reading plans  6 search & shortcuts  7 journal  8 AI reference checks  9 home refinements */
(function () {
  'use strict';
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  Object.assign(ICP, {
    aa: '<path d="M3 19l5-13 5 13M4.800 14h6.400M14 19l3.500-9 3.500 9M15.200 16h3.600"/>',
    bmk: '<path d="M6 3h12v18l-6-4-6 4z"/>', bmkf: '<path d="M6 3h12v18l-6-4-6 4z" fill="currentColor"/>',
    more: '<circle cx="5" cy="12" r="1.300"/><circle cx="12" cy="12" r="1.300"/><circle cx="19" cy="12" r="1.300"/>',
    link: '<path d="M10 14a4 4 0 005.700 0l3-3a4 4 0 00-5.700-5.700l-1 1M14 10a4 4 0 00-5.700 0l-3 3a4 4 0 005.700 5.700l1-1"/>',
    brain: '<path d="M9 4a3 3 0 00-3 3 3 3 0 00-2 5 3 3 0 002 5 3 3 0 006 1V4.500A2.500 2.500 0 009 4zM15 4a3 3 0 013 3 3 3 0 012 5 3 3 0 01-2 5 3 3 0 01-6 1"/>',
    cols2: '<rect x="3" y="4" width="8" height="16" rx="1.500"/><rect x="13" y="4" width="8" height="16" rx="1.500"/>',
    keyb: '<rect x="2" y="6" width="20" height="12" rx="2"/><path d="M6 10h.01M10 10h.01M14 10h.01M18 10h.01M7 14h10"/>'
  });
  THEMES.paper = 'Paper';
  var U = store.g('u15', { tools: false, mw: 40, firstRun: true });
  var usv = function () { store.s('u15', U); };
  if (U.firstRun) { // new readers start on the warm paper theme; existing choices are kept
    var st = store.g('set', null); if ((!st || !st.theme) && !matchMedia('(prefers-color-scheme: dark)').matches) { S.theme = 'paper'; sv(); }
    U.firstRun = false; usv();
  }
  if (tbMin === false && !store.g('tbFull', false)) tbMin = true; // actions first; formatting under "More"
  var AA = false, JQ = '', LIBT = 'bibles', SVQ = '';
  var MEM = store.g('mem', []), PLN = store.g('plans', { active: {} });
  var msv = function () { store.s('mem', MEM); }, psv = function () { store.s('plans', PLN); };
  var refStr = function (b, c, v) { return b + ' ' + c + ':' + v; };
  var vtext = function (ref, ver) { var p = parse(ref); if (!p) return ''; ver = ver && ver !== 'HEB' ? ver : (mainV() === 'HEB' ? 'KJV' : mainV()); var t = gv(ver, p.b, p.c, p.v) || gv('KJV', p.b, p.c, p.v); return t ? plain(t).replace(/\s+/g, ' ').trim() : ''; };

  /* ============ 1. KJV text repair ============ */
  // ~8,200 verses in the embedded KJV had words run together ("Night.Andtheevening"). kjv-spaces.json lists only
  // the positions where a space belongs; letters, punctuation and Strong's tags are never changed.
  var FIXED = false;
  function applyFix(F) {
    if (FIXED || !KJV.Genesis || Object.keys(KJV).length < 60) return false;
    var n = 0;
    for (var b in F) for (var c in F[b]) for (var v in F[b][c]) {
      var arr = KJV[b] && KJV[b][c], i = +v - 1; if (!arr || typeof arr[i] !== 'string') continue;
      var t = arr[i], ps = F[b][c][v].slice().sort(function (x, y) { return y - x; });
      ps.forEach(function (p) { t = t.slice(0, p) + ' ' + t.slice(p); }); arr[i] = t; n++;
    }
    // 201 verses carry stray tense codes such as {(H8798)}, which showed in the reader as “H8798)”: remove them
    for (var b2 in KJV) for (var c2 in KJV[b2]) { var A2 = KJV[b2][c2]; for (var q = 0; q < A2.length; q++) if (typeof A2[q] === 'string' && /\{[^{}]*\)\s*\}|\{\(/.test(A2[q])) A2[q] = A2[q].replace(/\{[^{}]*\)\s*\}|\{\([^}]*\}/g, ''); }
    // some verses carry a Strong's tag with no English word (an untranslated Greek or Hebrew word), which showed as a bare "G1161": drop the orphan tag
    for (var b3 in KJV) for (var c3 in KJV[b3]) { var A3 = KJV[b3][c3]; for (var q3 = 0; q3 < A3.length; q3++) { if (typeof A3[q3] !== 'string') continue; if (/^\s*\{[GH]\d+\}/.test(A3[q3])) A3[q3] = A3[q3].replace(/^\s*(\{[GH]\d+\}\s*)+/, ''); if (/[,;:.!?(]\s*\{[GH]\d+\}/.test(A3[q3])) A3[q3] = A3[q3].replace(/([,;:.!?(])(\s*)(?:\{[GH]\d+\}\s*)+/g, function (m0, p, sp) { return p + (sp || ' '); }); } }
    FIXED = true;
    CI = null; EN = {}; RK = null; VIX = null; VID = []; WC = { k: '', O: [] }; if (SL) { SL._k = 0; SL._ex = 0; }
    window.__kjvRepaired = n; render(); return true;
  }
  fetch('kjv-spaces.json').then(function (r) { return r.ok ? r.json() : null; }).then(function (j) {
    if (!j || !j.fix) return;
    var tries = 0, t = setInterval(function () { if (applyFix(j.fix) || ++tries > 600) clearInterval(t); }, 100);
  }).catch(function () {});

  /* ============ 2. Reader header + text settings ============ */
  var ribbon0 = ribbon;
  ribbon = function () {
    var full = ribbon0(), bm = FAV.includes(refStr(cur.b, cur.c, cur.v)), one = LAY.length === 1;
    var chips = LAY.map(function (v) { return '<span class="vchip"><button data-act="open" data-v="' + v + '" title="' + esc((VINFO[v] || [v])[0]) + '">' + esc(v) + '</button>' + (one ? '' : '<button data-act="tog" data-v="' + v + '" aria-label="Close ' + esc(v) + '">' + ic('x', 11) + '</button>') + '</span>'; }).join('') +
      '<span class="vchip add"><button data-act="picker" title="Add a Bible side by side">' + ic('plus', 12) + ' Compare</button></span>';
    var bar = '<div class="rd2" role="toolbar" aria-label="Reader">' +
      '<button class="ib ghost" data-act="side" title="Menu">' + ic('menu') + '</button>' +
      '<button class="ib ghost" data-act="pc" title="Previous chapter (←)">' + ic('cl') + '</button>' +
      '<button class="psg" id="refb" data-act="nav" title="Go to passage (G)">' + esc(cur.b) + ' ' + cur.c + ':' + cur.v + ' ' + ic('cd', 14) + '</button>' +
      '<button class="ib ghost" data-act="nc" title="Next chapter (→)">' + ic('cr') + '</button>' +
      '<div class="vchips">' + chips + '</div><span class="sp"></span>' +
      '<label class="hsearch" title="Search (/)">' + ic('search', 16) + '<input id="hq" placeholder="Search or type a reference" autocomplete="off" aria-label="Search the Bible"></label>' +
      '<button class="ib ghost showm" data-act="msearch" title="Search">' + ic('search') + '</button>' +
      '<button class="ib ghost ' + (AA ? 'on' : '') + '" data-act="aa" title="Text settings (T)" aria-expanded="' + AA + '">' + ic('aa') + '</button>' +
      '<button class="ib ghost ' + (bm ? 'on' : '') + '" data-act="bmk" title="Bookmark ' + esc(refStr(cur.b, cur.c, cur.v)) + ' (B)">' + ic(bm ? 'bmkf' : 'bmk') + '</button>' +
      '<button class="ib ghost hidem ' + (drawer ? 'on' : '') + '" data-act="drawer" title="Study panel">' + ic('bulb') + '</button>' +
      '<button class="ib ghost ' + (U.tools ? 'on' : '') + '" data-act="tools" title="' + (U.tools ? 'Hide' : 'Show') + ' all tools">' + ic('more') + '</button>' +
      (AA ? aaHtml() : '') + '</div>';
    full = full.replace('<div class="rib">', '<div class="rib slim">').replace('id="refb"', '');
    if (!U.tools) full = full.replace(/<div class="rmenu">[\s\S]*$/, '</div>');
    return bar + full;
  };
  function aaHtml() {
    var mw = [[34, 'Narrow'], [40, 'Medium'], [48, 'Wide']], ths = ['paper', 'snow', 'sepia', 'blue', 'forest', 'black'];
    var tc = { paper: '#FFFDF8', snow: '#fff', sepia: '#ece0c8', blue: '#10203a', forest: '#12251c', black: '#000' };
    return '<div id="aa" role="dialog" aria-label="Text settings">' +
      '<div class="aar"><h6 style="flex:1">Text size</h6><button data-act="sz" data-d="-1" aria-label="Smaller">A−</button><span class="sz">' + S.size + 'px</span><button data-act="sz" data-d="1" aria-label="Bigger">A+</button></div>' +
      '<label>Line spacing <input type="range" min="1.3" max="2.3" step=".05" value="' + S.lh + '" data-set="lh"></label>' +
      '<div><h6>Text width</h6><div class="aar" style="margin-top:6px">' + mw.map(function (x) { return '<button data-act="mw" data-w="' + x[0] + '" class="' + (U.mw === x[0] ? 'on' : '') + '">' + x[1] + '</button>'; }).join('') + '</div></div>' +
      '<div><h6>Theme</h6><div class="ths" style="margin-top:6px">' + ths.map(function (t) { return '<button data-act="theme" data-v="' + t + '" class="' + (S.theme === t ? 'on' : '') + '"><i style="background:' + tc[t] + '"></i>' + THEMES[t] + '</button>'; }).join('') + '</div></div>' +
      '<div><h6>Typeface</h6><select data-set="font" style="margin-top:6px">' + FONTS.map(function (f) { return '<option ' + (f === S.font ? 'selected' : '') + '>' + f + '</option>'; }).join('') + '</select></div>' +
      '<div><h6>Strong\'s numbers under words</h6><div class="aar" style="margin-top:6px">' + [[0, 'Off'], [1, 'Numbers'], [2, '+ Meanings']].map(function (x) { return '<button data-act="sn" data-m="' + x[0] + '" class="' + ((+S.il || 0) === x[0] ? 'on' : '') + '">' + x[1] + '</button>'; }).join('') + '</div></div>' +
      '<label><input type="checkbox" data-set="vpl" ' + (S.vpl ? 'checked' : '') + '> One verse per line</label>' +
      '<label><input type="checkbox" data-set="vn" ' + (S.vn ? 'checked' : '') + '> Verse numbers</label>' +
      '<label><input type="checkbox" data-set="red" ' + (S.red ? 'checked' : '') + '> Words of Jesus in colour</label>' +
      '<div class="aar"><button data-act="focus">' + ic('focus', 15) + ' Focus mode</button><button data-act="kbd">' + ic('keyb', 15) + ' Shortcuts</button></div></div>';
  }
  var readHtml0 = readHtml;
  readHtml = function () {
    var h = readHtml0(); if (!KJV[cur.b] || !KJV[cur.b][cur.c]) return h;
    var bi = BOOKS.indexOf(cur.b), grp = (CLS && (CLS.books.find(function (x) { return x.name === cur.b; }) || {}).group) || GEN(bi)[0], n = Object.keys(KJV[cur.b]).length;
    h = h.replace('<h1 class="ct">' + cur.b + ' ' + cur.c + '</h1>', '<header class="chead"><small>' + esc(grp) + '</small><h1 class="ct">' + esc(cur.b) + ' ' + cur.c + '</h1><small>Chapter ' + cur.c + ' of ' + n + '</small></header>');
    if (LAY.length === 1) h = h.replace('<div class="panes"', '<div class="panes solo"');
    var pb = planBar(); if (pb) h = h.replace(/(<div class="nav">[\s\S]*?<\/div>)(<\/div>)$/, '$1' + pb + '$2');
    return h;
  };
  // mark bookmarked verses
  var paneU = paneHtml;
  paneHtml = function (v, i) {
    var h = paneU(v, i); if (!FAV.length) return h;
    FAV.forEach(function (r) { var vk = v + '|' + r; h = h.split('class="vs" data-vk="' + vk + '"').join('class="vs bm" data-vk="' + vk + '"').split('class="vs cv" data-vk="' + vk + '"').join('class="vs cv bm" data-vk="' + vk + '"'); });
    return h;
  };

  /* ============ 3. Verse actions ============ */
  function selRefs() { var seen = {}, out = []; sel.forEach(function (x) { var p = x[0].split('|'); if (!seen[p[1]]) { seen[p[1]] = 1; out.push({ ver: p[0], ref: p[1] }); } }); return out; }
  function rangeLabel(rs) {
    if (!rs.length) return ''; var ps = rs.map(function (r) { return parse(r.ref); }).filter(Boolean);
    if (ps.length > 1 && ps.every(function (p) { return p.b === ps[0].b && p.c === ps[0].c; })) { var vs = ps.map(function (p) { return p.v; }).sort(function (a, b) { return a - b; }); var contiguous = vs.every(function (v, i) { return !i || v === vs[i - 1] + 1; }); return ps[0].b + ' ' + ps[0].c + ':' + (contiguous ? vs[0] + '–' + vs[vs.length - 1] : vs.join(',')); }
    return rs.map(function (r) { return r.ref; }).join('; ');
  }
  var tbDraw0 = tbDraw;
  tbDraw = function () {
    tbDraw0(); var t = $('#tb'); if (!t || t.style.display === 'none' || !sel.length) return;
    var rs = selRefs(), lab = rangeLabel(rs), allBm = rs.every(function (r) { return FAV.includes(r.ref); }), memd = rs.length === 1 && MEM.some(function (m) { return m.ref === rs[0].ref; });
    var h = t.querySelector('.tbh'); if (h) { var b = h.querySelector('b'); if (b) b.innerHTML = esc(lab) + ' <span class="dim" style="font-weight:400;font-size:12px">' + esc(rs[0].ver) + '</span>'; var mb = h.querySelector('[data-t="min"]'); if (mb) mb.textContent = tbMin ? 'Formatting' : 'Less'; }
    var first = t.querySelector('.tbs.first'); if (first) first.classList.remove('first');
    var A = function (x, icn, l, on) { return '<button data-x="' + x + '" class="' + (on ? 'on' : '') + '">' + ic(icn, 17) + '<span>' + l + '</span></button>'; };
    var acts = '<div class="tbs first"><div class="acts">' + A('copy', 'copy', 'Copy') + A('bm', allBm ? 'bmkf' : 'bmk', allBm ? 'Saved' : 'Bookmark', allBm) + A('note', 'pen', 'Note') + A('cmp', 'cols2', 'Compare') +
      A('rel', 'link', 'Related') + A('mem', 'brain', memd ? 'Memorising' : 'Memorise', memd) + '<button data-t="study">' + ic('bulb', 17) + '<span>Study</span></button><button data-t="jr">' + ic('note', 17) + '<span>Journal</span></button></div></div>' +
      '<div class="tbs first"><div class="hlrow">' + PAL.slice(0, 8).map(function (c) { return '<i class="sw" data-t="g" data-c="' + c + '" style="background:' + c + '" title="Highlight"></i>'; }).join('') + '<button data-t="g0">No highlight</button></div></div>';
    if (h) h.insertAdjacentHTML('afterend', acts);
  };
  $('#tb').addEventListener('click', function (e) {
    var b = e.target.closest('[data-x]'); if (!b) return; e.stopPropagation();
    var rs = selRefs(), x = b.dataset.x; if (!rs.length) return;
    if (x === 'copy') { var ver = rs[0].ver; copyTxt(rs.map(function (r) { return vtext(r.ref, ver); }).join(' ') + ' — ' + rangeLabel(rs) + ' (' + (ver === 'HEB' ? 'KJV' : ver) + ')'); return; }
    if (x === 'bm') { var all = rs.every(function (r) { return FAV.includes(r.ref); }); rs.forEach(function (r) { FAV = FAV.filter(function (f) { return f !== r.ref; }); if (!all) FAV.unshift(r.ref); }); store.s('fav', FAV); toast(all ? 'Bookmark removed' : 'Bookmarked ' + rangeLabel(rs)); render(); return; }
    var p = parse(rs[0].ref); if (p) { cur.b = p.b; cur.c = p.c; cur.v = p.v; }
    if (x === 'note') { sel = []; drawer = true; dtab = 'n'; sv(); render(); var n = $('#nt'); if (n) n.focus(); return; }
    if (x === 'rel') { sel = []; drawer = true; dtab = 'v'; sv(); render(); return; }
    if (x === 'cmp') { SL.cref = rangeLabel(rs); SL.tool = 'compare'; SL.cmpTab = 'ver'; sel = []; view = 'study'; slsv(); sv(); render(); return; }
    if (x === 'mem') { var r0 = rs[0].ref, i = MEM.findIndex(function (m) { return m.ref === r0; }); if (i >= 0) { MEM.splice(i, 1); toast('Removed from memory verses'); } else { MEM.unshift({ ref: rangeLabel(rs), ver: rs[0].ver === 'HEB' ? 'KJV' : rs[0].ver, added: Date.now(), best: 0 }); toast('Added to memory verses — practise in Library › Saved'); } msv(); tbDraw(); }
  }, true);

  /* ============ 4. Saved Scripture + memorise (Library) ============ */
  var lib0 = libraryHtml;
  libraryHtml = function () {
    var tabs = '<div class="ltabs" role="tablist"><button class="' + (LIBT === 'bibles' ? 'on' : '') + '" data-act="libt" data-t="bibles">Bibles</button><button class="' + (LIBT === 'saved' ? 'on' : '') + '" data-act="libt" data-t="saved">Saved Scripture</button></div>';
    if (LIBT !== 'saved') return lib0().replace('<h1>Library</h1>', '<h1>Library</h1>' + tabs);
    return '<div class="home lib"><div class="top" style="border:0;background:none;padding:0"><button class="ib" data-act="side">' + ic('menu') + '</button></div><h1>Library</h1>' + tabs + savedHtml() + '</div>';
  };
  function savedHtml() {
    var q = SVQ.trim().toLowerCase(), match = function (ref, txt) { return !q || (ref + ' ' + txt).toLowerCase().indexOf(q) >= 0; };
    var row = function (ref, txt, btns) { return '<div class="svrow"><a data-r="' + esc(ref.split('–')[0].split(',')[0]) + '">' + esc(ref) + '</a><p>' + esc(txt) + '</p><div class="acts2">' + (btns || '') + '</div></div>'; };
    var sec = function (title, n, body, empty) { return '<section class="svsec"><h3>' + title + ' <small>' + n + '</small></h3>' + (body || '<div class="svempty">' + empty + '</div>') + '</section>'; };
    var bms = FAV.filter(function (r) { return match(r, vtext(r)); });
    var notes = Object.keys(NT).filter(function (r) { return match(r, NT[r]); });
    var hl = {}; Object.keys(M).forEach(function (k) { var p = k.split('|'); if (p.length >= 2 && parse(p[1])) { var m = M[k]; if (m.g || m.c || m.b || m.u || m.x) hl[p[1]] = p[0]; } });
    var hls = Object.keys(hl).filter(function (r) { return match(r, vtext(r, hl[r])); }).sort(function (a, b) { var pa = parse(a), pb = parse(b); return (BOOKS.indexOf(pa.b) - BOOKS.indexOf(pb.b)) || pa.c - pb.c || pa.v - pb.v; });
    var mems = MEM.filter(function (m) { return match(m.ref, memText(m)); });
    return '<div class="sbox lsb" style="max-width:520px">' + ic('search', 16) + '<input id="svq" placeholder="Filter bookmarks, notes, highlights and memory verses" value="' + esc(SVQ) + '"></div>' +
      sec('Memory verses', mems.length, mems.map(function (m) { return row(m.ref, memText(m), '<button class="pri" data-act="mprac" data-r="' + esc(m.ref) + '">Practise</button><button data-act="mdel" data-r="' + esc(m.ref) + '" aria-label="Remove">' + ic('x', 13) + '</button>') + (m.best ? '' : ''); }).join(''), 'Tap a verse in the reader and choose Memorise.') +
      sec('Bookmarks', bms.length, bms.map(function (r) { return row(r, vtext(r), '<button data-act="bdel" data-r="' + esc(r) + '" aria-label="Remove bookmark">' + ic('x', 13) + '</button>'); }).join(''), 'Tap a verse and choose Bookmark, or press B while reading.') +
      sec('Notes', notes.length, notes.map(function (r) { return row(r, NT[r]); }).join(''), 'Notes you write on verses appear here.') +
      sec('Highlights', hls.length, hls.slice(0, 200).map(function (r) { return row(r, vtext(r, hl[r])); }).join(''), 'Verses you highlight or format appear here.');
  }
  function memText(m) { var p = parse(m.ref); if (!p) return ''; var vs = String(m.ref).match(/:(\d+)(?:–(\d+))?/), a = vs ? +vs[1] : p.v, z = vs && vs[2] ? +vs[2] : a, out = []; for (var v = a; v <= z; v++) out.push(vtext(refStr(p.b, p.c, v), m.ver)); return out.join(' '); }
  function practise(ref) {
    var m = MEM.find(function (x) { return x.ref === ref; }); if (!m) return;
    var words = memText(m).split(/\s+/), lvl = 1, box = document.createElement('div'); box.id = 'mm';
    var levels = [[1, 'Read it'], [2, 'Every third word'], [3, 'First letters'], [4, 'From memory']];
    function show() {
      var body;
      if (lvl === 1) body = esc(words.join(' '));
      else if (lvl === 2) body = words.map(function (w, i) { return i % 3 === 1 ? '<span class="gap">' + esc(w) + '</span>' : esc(w); }).join(' ');
      else if (lvl === 3) body = words.map(function (w) { var m2 = w.match(/^([^A-Za-z]*)([A-Za-z])(.*?)([^A-Za-z]*)$/); return m2 ? esc(m2[1] + m2[2]) + '<span style="opacity:.25">' + '_'.repeat(Math.min(6, m2[3].length)) + '</span>' + esc(m2[4]) : esc(w); }).join(' ');
      else body = '<textarea id="mtype" placeholder="Type the verse from memory"></textarea><div class="row" style="margin-top:8px"><button class="pri" id="mchk">Check</button><span id="mres"></span></div>';
      box.innerHTML = '<div class="box" role="dialog" aria-label="Memorise ' + esc(m.ref) + '"><div class="row" style="justify-content:space-between"><b style="font:700 20px var(--ff)">' + esc(m.ref) + ' <span class="dim" style="font:400 13px system-ui">' + esc(m.ver) + '</span></b><button class="ib" id="mx" aria-label="Close">' + ic('x', 16) + '</button></div>' +
        '<div class="lv">' + levels.map(function (l) { return '<button data-l="' + l[0] + '" class="' + (lvl === l[0] ? 'pri' : '') + '">' + l[1] + '</button>'; }).join('') + '</div><div class="mtext">' + body + '</div>' + (m.best ? '<small class="dim">Best recall so far: ' + m.best + '%</small>' : '') + '</div>';
      box.querySelector('#mx').onclick = close;
      $$('[data-l]', box).forEach(function (b) { b.onclick = function () { lvl = +b.dataset.l; show(); }; });
      var ck = box.querySelector('#mchk'); if (ck) { box.querySelector('#mtype').focus(); ck.onclick = function () {
        var norm = function (s) { return s.toLowerCase().replace(/[^a-z\s']/g, ' ').split(/\s+/).filter(Boolean); }, a = norm(words.join(' ')), b = norm(box.querySelector('#mtype').value);
        var L = Array.from({ length: a.length + 1 }, function () { return new Uint16Array(b.length + 1); });
        for (var i = a.length - 1; i >= 0; i--) for (var j = b.length - 1; j >= 0; j--) L[i][j] = a[i] === b[j] ? L[i + 1][j + 1] + 1 : Math.max(L[i + 1][j], L[i][j + 1]);
        var pct = Math.round(L[0][0] / Math.max(1, a.length) * 100); if (pct > (m.best || 0)) { m.best = pct; msv(); }
        box.querySelector('#mres').innerHTML = '<span class="score">' + pct + '% recalled</span>' + (pct === 100 ? ' — word perfect.' : ' — compare with the verse, then try again.');
      }; }
    }
    function close() { box.remove(); document.removeEventListener('keydown', esck); }
    function esck(e) { if (e.key === 'Escape') close(); }
    box.addEventListener('click', function (e) { if (e.target === box) close(); });
    document.addEventListener('keydown', esck); document.body.appendChild(box); show();
  }
  document.addEventListener('input', function (e) {
    if (e.target.id === 'svq') { SVQ = e.target.value; render(); var i = $('#svq'); if (i) { i.focus(); i.setSelectionRange(SVQ.length, SVQ.length); } }
  });

  /* ============ 5. Reading plans ============ */
  var PLANS = [
    { id: 'year', name: 'The Bible in a year', blurb: 'Every chapter from Genesis to Revelation, about three or four a day.', days: 365, books: null },
    { id: 'nt90', name: 'New Testament in 90 days', blurb: 'Matthew to Revelation, about three chapters a day.', days: 90, books: 'NT' },
    { id: 'gospels30', name: 'The four Gospels in 30 days', blurb: 'Matthew, Mark, Luke and John — about three chapters a day.', days: 30, books: ['Matthew', 'Mark', 'Luke', 'John'] },
    { id: 'psalms30', name: 'Psalms in 30 days', blurb: 'All 150 psalms, five a day.', days: 30, books: ['Psalms'] },
    { id: 'proverbs31', name: 'Proverbs in a month', blurb: 'One chapter of wisdom for each day of the month.', days: 31, books: ['Proverbs'] }
  ];
  function planChapters(pl) { return chapters.filter(function (x) { var i = BOOKS.indexOf(x[0]); return pl.books === null ? true : pl.books === 'NT' ? i >= 39 : pl.books.indexOf(x[0]) >= 0; }); }
  function planDays(pl) { var ch = planChapters(pl), d = []; for (var i = 0; i < pl.days; i++) d.push(ch.slice(Math.round(i * ch.length / pl.days), Math.round((i + 1) * ch.length / pl.days))); return d; }
  var dayNum = function (start) { var a = new Date(start + 'T12:00'), b = new Date(day() + 'T12:00'); return Math.max(1, Math.floor((b - a) / 864e5) + 1); };
  var ckey = function (x) { return x[0] + ' ' + x[1]; };
  function planState(pl) {
    var A = PLN.active[pl.id]; if (!A) return null;
    var days = planDays(pl), total = days.reduce(function (s, d) { return s + d.length; }, 0), done = Object.keys(A.done || {}).length;
    var dn = Math.min(pl.days, dayNum(A.start)), expected = days.slice(0, dn).reduce(function (s, d) { return s + d.length; }, 0);
    var next = null; for (var i = 0; i < days.length && next === null; i++) if (days[i].some(function (x) { return !A.done[ckey(x)]; })) next = i;
    return { A: A, days: days, total: total, done: done, dn: dn, behind: Math.max(0, expected - done), next: next };
  }
  function planBar() {
    var out = ''; PLANS.forEach(function (pl) {
      var s = planState(pl); if (!s || out) return; var k = cur.b + ' ' + cur.c;
      var inPlan = s.days.some(function (d) { return d.some(function (x) { return ckey(x) === k; }); }); if (!inPlan) return;
      out = '<div class="planbar"><span>' + esc(pl.name) + '</span>' + (s.A.done[k] ? '<span class="done">' + ic('check', 14) + ' ' + esc(k) + ' read</span><button data-act="plmark" data-p="' + pl.id + '" data-k="' + esc(k) + '">Undo</button>' : '<button class="pri" data-act="plmark" data-p="' + pl.id + '" data-k="' + esc(k) + '">Mark ' + esc(k) + ' as read</button>') + '<button data-act="plans">Plan</button></div>';
    }); return out;
  }
  function plansHtml() {
    if (!chapters.length) return '<div class="load">Loading the Bible…</div>';
    var act0 = PLANS.filter(function (p) { return PLN.active[p.id]; });
    var actHtml = act0.map(function (pl) {
      var s = planState(pl), di = s.next == null ? s.days.length - 1 : s.next, d = s.days[di] || [];
      return '<div class="plday"><div class="row" style="justify-content:space-between"><div><b style="font-size:18px">' + esc(pl.name) + '</b><div class="dim" style="font-size:13px">Day ' + s.dn + ' of ' + pl.days + ' · ' + s.done + ' of ' + s.total + ' chapters' + (s.behind ? ' · ' + s.behind + ' behind — no pressure, just pick up where you left off' : s.done >= s.total ? ' · complete' : ' · on track') + '</div></div><button data-act="plstop" data-p="' + pl.id + '">Stop plan</button></div><div class="bar2" style="margin:12px 0"><i style="width:' + (s.done / s.total * 100) + '%"></i></div>' +
        (s.next == null ? '<p><b>Plan complete.</b> "Thy word is a lamp unto my feet, and a light unto my path." <span class="dim">Psalm 119:105</span></p>' : '<h5 style="margin:6px 0">Reading ' + (di + 1) + '</h5>' + d.map(function (x) { var k = ckey(x), ok = s.A.done[k]; return '<div class="ch ' + (ok ? 'ok' : '') + '"><input type="checkbox" data-plck="' + pl.id + '" data-k="' + esc(k) + '" ' + (ok ? 'checked' : '') + ' aria-label="Mark ' + esc(k) + ' read"><a data-r="' + esc(k) + ':1">' + esc(k) + '</a></div>'; }).join('')) + '</div>';
    }).join('');
    return '<div class="home plans"><div class="top" style="border:0;background:none;padding:0"><button class="ib" data-act="side">' + ic('menu') + '</button></div><h1>Reading plans</h1><p class="dim">Read through Scripture a little each day. Progress is saved on this device. Missed a day? Just carry on from where you stopped.</p>' + actHtml +
      '<h3 style="margin-top:26px">' + (act0.length ? 'Start another plan' : 'Choose a plan') + '</h3><div class="plgrid">' + PLANS.filter(function (p) { return !PLN.active[p.id]; }).map(function (pl) { var n = planChapters(pl).length; return '<div class="plc"><b>' + esc(pl.name) + '</b><span>' + esc(pl.blurb) + '</span><small>' + n + ' chapters · ' + pl.days + ' days</small><button class="pri" data-act="plstart" data-p="' + pl.id + '" style="margin-top:8px">Start today</button></div>'; }).join('') + '</div></div>';
  }
  function homePlan() {
    var pl = PLANS.find(function (p) { return PLN.active[p.id]; });
    if (!pl) return '<div class="homeplan"><div><b>Read a little every day</b><br><small>Five reading plans, from Proverbs in a month to the whole Bible in a year.</small></div><button class="pri" data-act="plans">Choose a plan</button></div>';
    var s = planState(pl); if (s.next == null) return '<div class="homeplan"><div><b>' + esc(pl.name) + ' — complete</b><br><small>Well done. Start another plan any time.</small></div><button data-act="plans">Plans</button></div>';
    var d = s.days[s.next].filter(function (x) { return !s.A.done[ckey(x)]; });
    return '<div class="homeplan"><div><small>' + esc(pl.name) + ', reading ' + (s.next + 1) + '</small><br><b>' + d.map(ckey).join(', ') + '</b><br><small>' + s.done + ' of ' + s.total + ' chapters read</small></div><button class="pri" data-r="' + esc(ckey(d[0])) + ':1">Read now</button></div>';
  }
  document.addEventListener('change', function (e) {
    var t = e.target; if (!t.dataset || !t.dataset.plck) return;
    var A = PLN.active[t.dataset.plck]; if (!A) return; if (t.checked) A.done[t.dataset.k] = day(); else delete A.done[t.dataset.k]; psv(); render();
  });

  /* ============ 6. Search, verse of the day, nav, shortcuts ============ */
  function headSearch(q) {
    q = (q || '').trim(); if (!q) return;
    if (/^[HG]\d+$/i.test(q)) { act('lab', { k: q.toUpperCase() }); return; }
    var p = /\d/.test(q) && parse(q); if (p) { go(p, true); return; }
    SL.q = q; SL.mode = SL.mode === 'orig' ? 'all' : SL.mode; SL.tool = 'search'; SL.page = 0; SL._k = 0; view = 'study'; slsv(); sv(); render();
  }
  document.addEventListener('keydown', function (e) { if (e.key === 'Enter' && e.target.id === 'hq') { e.preventDefault(); headSearch(e.target.value); } });
  var DV = ['Psalm 119:105', 'Proverbs 3:5', 'Joshua 1:9', 'Philippians 4:13', 'Psalm 46:10', 'Matthew 11:28', 'James 1:5', 'Micah 6:8', 'Isaiah 41:10', 'John 14:6', 'Proverbs 15:1', 'Ephesians 4:32', 'Hebrews 11:1', 'Psalm 27:14', '1 John 4:19', 'Romans 12:12', 'Proverbs 16:9', 'Lamentations 3:22', 'John 15:13', 'Psalm 23:1', 'Isaiah 40:31', 'Romans 8:28', 'John 3:16', 'Matthew 5:9', 'Galatians 5:22', 'Psalm 34:8', 'Colossians 3:23', '2 Timothy 1:7', 'Psalm 121:1', 'Matthew 6:33', 'Romans 15:13', 'Psalm 37:4', 'Hebrews 13:8', 'John 8:12', '1 Corinthians 16:14', 'Psalm 51:10', 'Isaiah 26:3', 'Matthew 5:16', 'Psalm 90:12', 'John 11:25'];
  dailyVerse = function () { if (Object.keys(KJV).length < 10) return null; var r = DV[(+day().replace(/-/g, '')) % DV.length], p = parse(r.replace('Psalm ', 'Psalms ')); if (!p) return null; var ref = refStr(p.b, p.c, p.v), t = vtext(ref); return t ? { ref: ref, t: t } : null; };
  var home0 = homeHtml;
  homeHtml = function () {
    var h = home0(), bm = FAV.slice(0, 3);
    var extra = homePlan() + (bm.length ? '<h3>Bookmarks</h3><div class="card" style="padding:4px 14px">' + bm.map(function (r) { return '<div class="svrow" style="grid-template-columns:130px 1fr"><a data-r="' + esc(r) + '">' + esc(r) + '</a><p style="font-size:15px">' + esc(vtext(r)) + '</p></div>'; }).join('') + '<div style="padding:8px 0"><a data-act="libsaved">All saved Scripture</a></div></div>' : '');
    return h.replace('<h3>Your Bibles</h3>', extra + '<h3>Your Bibles</h3>');
  };
  var side0 = sideHtml;
  sideHtml = function () { return side0().replace(/<button data-act="games"[^>]*>[\s\S]*?<\/button>/, '').replace('<button data-act="library"', '<button data-act="plans" class="' + (view === 'plans' ? 'on' : '') + '" title="Reading plans">' + ic('cal') + '<span class="lb">Reading plans</span></button><button data-act="library"'); };
  function kbdHelp() {
    var b = document.createElement('div'); b.id = 'kbd';
    b.innerHTML = '<div class="box" role="dialog" aria-label="Keyboard shortcuts"><div class="row" style="justify-content:space-between"><b style="font-size:18px">Keyboard shortcuts</b><button class="ib" aria-label="Close">' + ic('x', 16) + '</button></div><div class="k">' + [['← →', 'Previous / next chapter'], ['G', 'Go to a passage'], ['/', 'Search'], ['B', 'Bookmark the current verse'], ['T', 'Text settings'], ['F', 'Focus mode'], ['S', 'Study panel'], ['Esc', 'Close or clear selection'], ['?', 'This list']].map(function (x) { return '<kbd>' + x[0] + '</kbd><span>' + x[1] + '</span>'; }).join('') + '</div></div>';
    b.onclick = function (e) { if (e.target === b || e.target.closest('button')) b.remove(); }; document.body.appendChild(b);
  }
  document.addEventListener('keydown', function (e) {
    if (e.ctrlKey || e.metaKey || e.altKey) { if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k' && view === 'read') { e.preventDefault(); var i = $('#hq'); if (i && i.offsetParent) i.focus(); else act('nav', {}); } return; }
    if (/INPUT|TEXTAREA|SELECT/.test(e.target.tagName) || e.target.isContentEditable) return;
    if ($('#mm') || $('#kbd') || (nv && $('#nav').style.display === 'flex') || $('#modal').style.display === 'flex') { if (e.key === 'Escape') { var k = $('#kbd'); if (k) k.remove(); } return; }
    if (e.key === 'Escape' && AA) { AA = false; render(); return; }
    if (view !== 'read') { if (e.key === '?') kbdHelp(); return; }
    var k2 = e.key;
    if (k2 === 'ArrowLeft') { e.preventDefault(); act('pc', {}); }
    else if (k2 === 'ArrowRight') { e.preventDefault(); act('nc', {}); }
    else if (k2 === 'g' || k2 === 'G') { e.preventDefault(); act('nav', {}); }
    else if (k2 === '/') { e.preventDefault(); var q = $('#hq'); if (q && q.offsetParent) q.focus(); else act('nav', {}); }
    else if (k2 === 'b' || k2 === 'B') act('bmk', {});
    else if (k2 === 't' || k2 === 'T') act('aa', {});
    else if (k2 === 'f' || k2 === 'F') act('focus', {});
    else if (k2 === 's' || k2 === 'S') act('drawer', {});
    else if (k2 === '?') kbdHelp();
  });
  document.addEventListener('click', function (e) { if (AA && !e.target.closest('#aa') && !e.target.closest('[data-act="aa"]')) { AA = false; var a = $('#aa'); if (a) a.remove(); var b = $('[data-act="aa"]'); if (b) b.classList.remove('on'); } }, true);

  /* ============ 7. Journal ============ */
  var REFRX = /\b((?:[1-3]\s?)?(?:Song of Solomon|[A-Z][a-z]+))\.?\s(\d{1,3}):(\d{1,3})(?:\s?[-–]\s?(\d{1,3}))?/g;
  function validRef(bk, c, v) { var p = parse(bk + ' ' + c + ':' + v); if (!p || p.c !== +c || p.v !== +v) return null; var b0 = bk.toLowerCase().replace(/\s/g, ''), nm = p.b.toLowerCase().replace(/\s/g, ''); if (nm.indexOf(b0.replace(/^(\d)/, '$1')) !== 0 && !(b0 === 'psalm' && p.b === 'Psalms')) return null; return KJV[p.b] && KJV[p.b][p.c] && KJV[p.b][p.c][p.v - 1] ? p : null; }
  function findRefs(t) { var out = [], seen = {}, m; REFRX.lastIndex = 0; while ((m = REFRX.exec(t))) { var p = validRef(m[1], m[2], m[3]); if (p) { var r = refStr(p.b, p.c, p.v); if (!seen[r]) { seen[r] = 1; out.push(r); } } } return out; }
  var diary0 = diaryHtml;
  diaryHtml = function () {
    var h = diary0(), q = JQ.trim().toLowerCase();
    var box = '<div class="jsearch"><input id="jsq" placeholder="Search all journals" value="' + esc(JQ) + '" aria-label="Search all journals"></div>';
    if (q) {
      var res = []; JR.list.forEach(function (j) { j.pages.forEach(function (p) { var hay = (p.title + '\n' + p.body); var i = hay.toLowerCase().indexOf(q); if (i >= 0) res.push({ j: j, p: p, snip: hay.slice(Math.max(0, i - 40), i + q.length + 60) }); }); });
      var mk = function (s) { return esc(s).replace(new RegExp(q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi'), function (x) { return '<mark>' + x + '</mark>'; }); };
      var c1 = '<div class="dcol c1"><div class="dh"><b>Search</b></div>' + box + (res.length ? res.map(function (r) { return '<button class="jres" data-act="jres" data-j="' + r.j.id + '" data-p="' + r.p.id + '"><b>' + esc(r.p.title || 'Untitled page') + '</b><small>' + esc(r.j.name) + ', page ' + r.p.n + '</small><span style="font-size:13px">…' + mk(r.snip) + '…</span></button>'; }).join('') : '<p class="dim pad">No pages contain "' + esc(JQ) + '".</p>') + '</div>';
      h = h.replace(/<div class="dcol c1">[\s\S]*?(?=<div class="dcol c2">)/, c1);
    } else h = h.replace(/(<div class="dcol c1"><div class="dh">[\s\S]*?<\/div>)/, '$1' + box);
    var p = curP();
    if (p) { var rs = findRefs(p.title + ' ' + p.body); h = h.replace(/(<textarea id="pb"[\s\S]*?<\/textarea>)/, '$1<div class="jrefs" id="jrefs">' + jrefsInner(rs) + '</div>'); h = h.replace('<span class="sp"></span><button data-act="pverse">', '<span class="jsaved" id="jsaved">Saved on this device</span><span class="sp"></span><button data-act="pverse">'); }
    return h;
  };
  function jrefsInner(rs) { return rs.length ? 'Scripture in this page: ' + rs.map(function (r) { return '<a class="chip qref" data-qr="' + esc(r) + '">' + esc(r) + '</a>'; }).join('') : 'Type a reference like John 3:16 and it will be recognised here.'; }
  var jT;
  document.addEventListener('input', function (e) {
    var t = e.target;
    if (t.id === 'jsq') { JQ = t.value; render(); var i = $('#jsq'); if (i) { i.focus(); i.setSelectionRange(JQ.length, JQ.length); } return; }
    if ((t.id === 'pb' || t.id === 'pt') && view === 'diary') { clearTimeout(jT); jT = setTimeout(function () { var p = curP(), r = $('#jrefs'), s = $('#jsaved'); if (p && r) r.innerHTML = jrefsInner(findRefs(p.title + ' ' + p.body)); if (s) { s.textContent = 'Saved'; setTimeout(function () { if (s) s.textContent = 'Saved on this device'; }, 1500); } }, 400); }
  });

  /* ============ 8. AI reference checks ============ */
  // Any Scripture reference in an AI answer is checked against the Bible text: real ones become previewable links,
  // ones that do not exist are marked so the reader knows to verify them.
  function checkAI(el) {
    if (!el || el.dataset.ckd === el.textContent.length + '') return;
    var walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT), nodes = [], n, bad = 0, good = 0;
    while ((n = walker.nextNode())) if (!n.parentNode.closest('.qref,.refbad,.aicheck')) nodes.push(n);
    nodes.forEach(function (tn) {
      var t = tn.nodeValue; REFRX.lastIndex = 0; if (!REFRX.test(t)) return; REFRX.lastIndex = 0;
      var frag = document.createDocumentFragment(), last = 0, m;
      while ((m = REFRX.exec(t))) {
        frag.appendChild(document.createTextNode(t.slice(last, m.index)));
        var p = validRef(m[1], m[2], m[3]), looksBook = BOOKS.some(function (b) { return b.toLowerCase().indexOf(m[1].toLowerCase().replace(/^psalm$/, 'psalms')) === 0; }) || /^psalm$/i.test(m[1]);
        if (p) { var a = document.createElement('a'); a.className = 'qref'; a.dataset.qr = refStr(p.b, p.c, p.v); a.textContent = m[0]; frag.appendChild(a); good++; }
        else if (looksBook) { var s = document.createElement('span'); s.className = 'refbad'; s.title = 'This reference was not found in the Bible text. Check it before relying on it.'; s.textContent = m[0]; frag.appendChild(s); bad++; }
        else frag.appendChild(document.createTextNode(m[0]));
        last = REFRX.lastIndex;
      }
      frag.appendChild(document.createTextNode(t.slice(last))); tn.parentNode.replaceChild(frag, tn);
    });
    var note = el.querySelector('.aicheck'); if (note) note.remove();
    if (good || bad) el.insertAdjacentHTML('beforeend', '<div class="aicheck">' + good + ' reference' + (good === 1 ? '' : 's') + ' checked against the Bible text' + (bad ? '; <span class="refbad">' + bad + ' not found</span> — verify before relying on ' + (bad === 1 ? 'it' : 'them') : '') + '. Hover a reference to read it.</div>');
    el.dataset.ckd = el.textContent.length + '';
  }
  var aiT; new MutationObserver(function (ms) { if (!ms.some(function (m) { var e = m.target.nodeType === 1 ? m.target : m.target.parentNode; return e && e.closest && e.closest('.aiout'); })) return; clearTimeout(aiT); aiT = setTimeout(function () { $$('.aiout').forEach(checkAI); }, 700); }).observe(document.body, { childList: true, subtree: true, characterData: true });


  /* ============ 10. One home for games: Kingdom Games ============ */
  // The Games catalogue now lives inside Kingdom Games. Games that belong to this app (Bible Quest, the Kids Bible
  // games and colouring) still run here, with a bar that returns to Kingdom Games; the Rebus Challenge runs inside it.
  var FROMKG = false, KGHASH = '', KGFORCE = false; var KGV = (function () { try { var m = /[?&]v=(\d+)/.exec((document.currentScript && document.currentScript.src) || ''); return m ? m[1] : '1'; } catch (e) { return '1'; } })();
  kingdomHtml = function () {
    var src = 'kingdom-games.html?v=' + KGV + (KGHASH ? '#' + KGHASH : ''); KGHASH = '';
    return '<div class="rebus"><div class="rbar"><b>Kingdom Games</b><span class="dim" style="font-size:12px">Play. Learn. Discern. Grow.</span></div><iframe id="kgf" src="' + src + '" title="Kingdom Games" style="flex:1;border:0;width:100%;min-height:0;background:#0E1626" allow="fullscreen"></iframe></div>';
  };
  function openKG(hash) { KGHASH = hash || ''; KGFORCE = true; FROMKG = false; view = 'kingdom'; side = false; KGOK = false; sv(); render(); }
  var gamesBar = function () { return '<div class="rbar kgback"><button data-act="kgback">' + ic('back', 16) + ' Kingdom Games</button><span class="dim" style="font-size:12px">All games live in Kingdom Games</span></div>'; };
  /* ============ actions + views ============ */
  var actU = act;
  act = function (a, d) {
    d = d || {};
    switch (a) {
      case 'kgopen': FROMKG = true; if (d.t === 'game') { view = 'game'; QR = null; } else if (d.t === 'kidsgames') { view = 'kids'; KV.tab = 'games'; KV.game = null; KV.sid = null; } else if (d.t === 'kidscolour') { view = 'kids'; KV.tab = 'colour'; KV.game = null; } if (innerWidth <= 800) side = false; sv(); render(); return;
      case 'kgback': openKG('games'); return;
      case 'games': openKG('games'); return;
      case 'rebus': openKG('rebus'); return;
      case 'kingdom': openKG(''); return;
      case 'game': case 'kidsgames': case 'kidscolour': FROMKG = true; break;
      case 'kids': case 'home': case 'read': case 'study': case 'library': case 'diary': case 'analyze': FROMKG = false; break;
      case 'aa': AA = !AA; render(); return;
      case 'tools': U.tools = !U.tools; usv(); render(); return;
      case 'mw': U.mw = +d.w; usv(); render(); return;
      case 'sz': S.size = Math.min(34, Math.max(14, S.size + +d.d)); sv(); render(); return;
      case 'msearch': SL.tool = 'search'; view = 'study'; slsv(); sv(); render(); setTimeout(function () { var i = $('#slq'); if (i) i.focus(); }, 50); return;
      case 'kbd': AA = false; render(); kbdHelp(); return;
      case 'bmk': { var r = refStr(cur.b, cur.c, cur.v), has = FAV.includes(r); FAV = has ? FAV.filter(function (x) { return x !== r; }) : [r].concat(FAV); store.s('fav', FAV); toast(has ? 'Bookmark removed' : 'Bookmarked ' + r); render(); return; }
      case 'libt': LIBT = d.t; render(); return;
      case 'libsaved': LIBT = 'saved'; view = 'library'; sv(); render(); return;
      case 'bdel': FAV = FAV.filter(function (x) { return x !== d.r; }); store.s('fav', FAV); render(); return;
      case 'mdel': MEM = MEM.filter(function (m) { return m.ref !== d.r; }); msv(); render(); return;
      case 'mprac': practise(d.r); return;
      case 'plans': view = 'plans'; if (innerWidth <= 800) side = false; sv(); render(); return;
      case 'plstart': PLN.active[d.p] = { start: day(), done: {} }; psv(); toast('Plan started — today\'s reading is ready'); render(); return;
      case 'plstop': { var pn = (PLANS.find(function (x) { return x.id === d.p; }) || {}).name; ask('Stop "' + pn + '"? Your progress in this plan will be cleared. Type STOP to confirm.', '', function (v) { if ((v || '').toUpperCase() === 'STOP') { delete PLN.active[d.p]; psv(); render(); } }); return; }
      case 'plmark': { var A = PLN.active[d.p]; if (A) { if (A.done[d.k]) delete A.done[d.k]; else { A.done[d.k] = day(); toast(d.k + ' marked as read'); } psv(); render(); } return; }
      case 'jres': D.j = d.j; D.p = d.p; D.step = 'e'; JQ = ''; JR.last = d.j; jsv(); render(); return;
      case 'nav': case 'side': case 'theme': case 'focus': case 'pc': case 'nc': case 'drawer': if (a !== 'theme') AA = false; break;
    }
    return actU(a, d);
  };
  var renderU = render;
  render = function () {
    document.documentElement.style.setProperty('--mw', (U.mw || 40) + 'em');
    document.body.classList.toggle('tools-on', !!U.tools);
    if (view === 'games' || view === 'rebus') { KGHASH = view === 'rebus' ? 'rebus' : 'games'; view = 'kingdom'; KGOK = false; }
    // Keep Kingdom Games alive through background redraws (a Bible finishing loading, the KJV repair, etc.).
    // Rebuilding the iframe reloads it, which wiped anything being typed and dropped focus. It is only rebuilt
    // when you actually navigate to Kingdom Games (openKG) or to a specific page inside it.
    var keep = null, dummy = null, kf = $('#kgf');
    if (view === 'kingdom' && !KGFORCE && !KGHASH && kf && kf.closest('#main')) {
      keep = $('#main'); keep.id = 'main-kg'; dummy = document.createElement('div'); dummy.id = 'main'; dummy.hidden = true; keep.parentNode.insertBefore(dummy, keep);
    }
    KGFORCE = false;
    try { renderU(); } finally { if (keep) { dummy.remove(); keep.id = 'main'; } }
    if (FROMKG && (view === 'game' || (view === 'kids' && (KV.tab === 'games' || KV.tab === 'colour')))) { var mn = $('#main'); if (mn && !mn.querySelector('.kgback')) mn.insertAdjacentHTML('afterbegin', gamesBar()); }
    if (view === 'plans') { $('#main').innerHTML = plansHtml(); $('#drawer').classList.remove('open'); $('#tb').style.display = 'none'; }
  };
  /* ============ 11. Kingdom look: one theme family across the Bible and Kingdom Games ============ */
  // Inspired by the user's reference boards (Dissected Bible, Olive Tree, Berean, Biblia do Pregador, Accordance):
  // navy and gold chrome, Caslon type, a verse-of-the-day dashboard, original-language cards, boxed reader controls.
  (function fonts() {
    if (document.getElementById('kgfonts')) return;
    var l = document.createElement('link'); l.id = 'kgfonts'; l.rel = 'stylesheet';
    l.href = 'https://fonts.googleapis.com/css2?family=Libre+Caslon+Display&family=Libre+Caslon+Text:ital,wght@0,400;0,700;1,400&family=Instrument+Sans:wght@400;500;600&family=Gentium+Book+Plus:ital@0;1&family=Noto+Serif+Hebrew:wght@400;600&display=swap';
    document.head.appendChild(l);
  })();
  THEMES.kingdom = 'Kingdom'; THEMES.vellum = 'Vellum';
  ['Libre Caslon Text', 'Gentium Book Plus'].forEach(function (f) { if (FONTS.indexOf(f) < 0) FONTS.unshift(f); });
  if (!U.k16) { // one-time move to the shared Kingdom look; readers can still pick any theme under Aa
    S.theme = ['black', 'blue', 'forest'].indexOf(S.theme) >= 0 ? 'kingdom' : 'vellum';
    if (S.font === 'Lora') S.font = 'Libre Caslon Text';
    U.k16 = true; usv(); sv();
  }
  var KMARK = '<img src="brand/icon-96.png" width="40" height="40" alt="" class="dove bicon">';
  var side1 = sideHtml;
  sideHtml = function () { return side1().replace(/<span class="logo">[\s\S]*?<\/svg><\/span>/, '<span class="logo k">' + KMARK + '</span>').replace('<b class="lb">Scripture</b>', '<b class="lb kword">Scripture<small class="motto"><span class="mch m1">Attend</span><span class="mch m2">Affirm</span><span class="mch m3">Matter</span></small><em class="mline">God will keep you in UPSHIFTS</em></b>'); };

  /* --- Dashboard --- */
  var SKIPPOS = /particle|preposition|conjunction|pronoun|article|adverb|interjection/i, COMMON = { H853: 1, H3588: 1, H834: 1, H3605: 1, H413: 1, H5921: 1, H1961: 1, H559: 1, G2532: 1, G3588: 1, G1161: 1, G846: 1, G1510: 1, G3739: 1, G3756: 1 };
  function wordOfDay(ref) {
    var p = parse(ref); if (!p || !KJV[p.b] || !KJV[p.b][p.c]) return null;
    var t = KJV[p.b][p.c][p.v - 1] || '', out = [], seen = {};
    t.replace(/([^\s{}]+)((?:\{[HG]\d+\})+)/g, function (m, w, tags) { (tags.match(/[HG]\d+/g) || []).forEach(function (k) { var e = LEX[k]; if (!e || seen[k] || COMMON[k]) return; seen[k] = 1; if (SKIPPOS.test(e[6] || '')) return; out.push({ k: k, w: w.replace(/[^\w'-]/g, ''), e: e }); }); return m; });
    if (!out.length) return null;
    out.sort(function (a, b) { return (/noun/i.test(b.e[6] || '') ? 1 : 0) - (/noun/i.test(a.e[6] || '') ? 1 : 0); });
    return { main: out[0], more: out.slice(1, 5) };
  }
  function dcardOrig(dv) {
    var w = dv && wordOfDay(dv.ref);
    if (!w) return '<div class="dcard"><h4>Original language</h4><p class="dim">' + (dv ? 'Loading the Hebrew and Greek dictionary…' : 'Open a verse to see its Hebrew or Greek words.') + '</p></div>';
    var e = w.main.e, H = w.main.k[0] === 'H';
    if (H && !e[0] && !HB) { // Hebrew spelling comes from the Hebrew Bible data; load it, then redraw Home once
      if (!window.__kHB) { window.__kHB = 1; try { loadHB(); } catch (x) {} }
      if (!window.__kHBt) window.__kHBt = setInterval(function () { if (HB) { clearInterval(window.__kHBt); window.__kHBt = 0; if (view === 'home') render(); } }, 400);
    }
    return '<div class="dcard"><h4>Original language <span class="dim">from ' + esc(dv.ref) + '</span></h4><div class="lem ' + (H ? 'heb' : 'grk') + '" lang="' + (H ? 'he' : 'grc') + '">' + esc(e[0] || (H && HEBL[w.main.k]) || '') + '</div><div class="xl">' + esc(e[1] || '') + ' <span class="sn">' + w.main.k + '</span></div><p class="gl">“' + esc(e[7] || (e[4] || '').split(/[,;]/)[0] || w.main.w) + '”</p><p class="dim small">Translated “' + esc(w.main.w) + '” in this verse.</p>' +
      '<div class="row" style="flex-wrap:wrap;gap:6px;margin-top:10px"><button class="pri sm" data-act="lab" data-k="' + w.main.k + '">Word study</button>' + w.more.map(function (m) { return '<button class="chip" data-act="lab" data-k="' + m.k + '" title="' + esc(m.e[1] || '') + '">' + esc(m.w) + '</button>'; }).join('') + '</div></div>';
  }
  function dcardRefs(dv) {
    var x = dv && XREF[dv.ref];
    var body = x ? '<p class="dim small">From ' + esc(dv.ref) + '</p><div class="xrl">' + x.map(function (r) { return '<a data-r="' + esc(r) + '"><b>' + esc(r) + '</b><span>' + esc((vtext(r) || '').slice(0, 90)) + (vtext(r).length > 90 ? '…' : '') + '</span></a>'; }).join('') + '</div>'
      : '<p class="dim small">Find verses that share Hebrew and Greek words with ' + (dv ? esc(dv.ref) : 'today\'s verse') + '.</p>' + (dv ? '<button data-act="xrel" data-r="' + esc(dv.ref) + '">Find related verses</button>' : '');
    return '<div class="dcard"><h4>Cross-references</h4>' + body + '</div>';
  }
  function dcardSaved() {
    var bm = FAV.slice(0, 3);
    return '<div class="dcard"><h4>Saved verses</h4>' + (bm.length ? '<div class="xrl">' + bm.map(function (r) { return '<a data-r="' + esc(r) + '"><b>' + esc(r) + '</b><span>' + esc((vtext(r) || '').slice(0, 90)) + '</span></a>'; }).join('') + '</div><button data-act="libsaved" style="margin-top:8px">All saved Scripture</button>' : '<p class="dim small">Tap the bookmark in the reader, or below today\'s verse, to keep a verse here.</p>') + '</div>';
  }
  var home1 = homeHtml;
  homeHtml = function () {
    var h = home1(), i = h.indexOf('<h3>Your Bibles</h3>'); if (i < 0) return h;
    var dv = dailyVerse(), nm = P ? P.name : '', fav = dv && FAV.includes(dv.ref), n = KJV[cur.b] ? Object.keys(KJV[cur.b]).length : 0;
    var hr = new Date().getHours(), greet = hr < 12 ? 'Good morning' : hr < 18 ? 'Good afternoon' : 'Good evening';
    var top = '<div class="home kd"><div class="greet"><button class="ib mobm" data-act="side" aria-label="Menu">' + ic('menu') + '</button><div><small>' + new Date().toLocaleDateString(undefined, { weekday: 'long', day: 'numeric', month: 'long' }) + '</small><h1>' + greet + (nm ? ', ' + esc(nm) : '') + '</h1></div></div>' +
      '<div class="kgrid"><section class="votd"><div class="lbl">Verse of the day</div>' + (dv ? '<blockquote>' + esc(dv.t) + '</blockquote><a class="ref" data-r="' + esc(dv.ref) + '">' + esc(dv.ref) + ' · ' + esc(mainV() === 'HEB' ? 'KJV' : mainV()) + '</a><div class="acts"><button class="pri" data-r="' + esc(dv.ref) + '">' + ic('book', 15) + ' Read the chapter</button><button data-act="favr" data-r="' + esc(dv.ref) + '" class="' + (fav ? 'on' : '') + '">' + ic(fav ? 'bmkf' : 'bmk', 15) + (fav ? ' Saved' : ' Save') + '</button><button data-act="cpyr" data-r="' + esc(dv.ref) + '">' + ic('copy', 15) + ' Copy</button></div>' : '<p class="dim">Loading the Bible…</p>') + '</section>' +
      '<div class="kcol"><button class="cont" data-act="read"><small>Continue reading</small><b>' + esc(cur.b) + ' <span>' + cur.c + '</span></b><span class="pg"><i style="width:' + (n ? Math.round(cur.c / n * 100) : 0) + '%"></i></span><small>Chapter ' + cur.c + (n ? ' of ' + n : '') + ' · ' + esc(LAY.join(' + ')) + '</small></button>' + homePlan() + '</div></div>' +
      '<h3>One layer deeper</h3><div class="deeper">' + dcardOrig(dv) + dcardRefs(dv) + dcardSaved() + '</div>';
    return top + h.slice(i);
  };

  /* --- Reader: Accordance-style chapter numeral --- */
  var read1 = readHtml;
  readHtml = function () { var h = read1(); return h.replace('<h1 class="ct">' + esc(cur.b) + ' ' + cur.c + '</h1>', '<h1 class="ct"><span class="bk">' + esc(cur.b) + '</span> <span class="num">' + cur.c + '</span></h1>'); };

  /* --- Text settings: theme swatches --- */
  var TSW = [['vellum', '#FBF8F1', '#1F1B16'], ['kingdom', '#0F1828', '#ECE3CF'], ['paper', '#FFFDF8', '#24211C'], ['snow', '#FFFFFF', '#222'], ['sepia', '#ece0c8', '#3b2f20'], ['blue', '#10203a', '#e3ecff'], ['forest', '#12251c', '#e1f0e6'], ['black', '#000', '#e8e8ea']];
  var aa1 = aaHtml;
  aaHtml = function () { return aa1().replace(/<div><h6>Theme<\/h6>[\s\S]*?<\/div><\/div>/, '<div><h6>Theme</h6><div class="tsw">' + TSW.map(function (t) { return '<button data-act="theme" data-v="' + t[0] + '" class="' + (S.theme === t[0] ? 'on' : '') + '" style="--sb:' + t[1] + ';--si:' + t[2] + '" aria-label="' + THEMES[t[0]] + ' theme"><span class="sw"><b>A</b><i></i><i></i><i></i></span>' + THEMES[t[0]] + '</button>'; }).join('') + '</div></div>'); };

  /* --- Back to the Bible from every games screen --- */
  var kh1 = kingdomHtml;
  kingdomHtml = function () { return kh1().replace('<div class="rbar"><b>Kingdom Games</b>', '<div class="rbar"><button class="tobible" data-act="read" aria-label="Back to the Bible">' + ic('back', 16) + ' Bible</button><b>Kingdom Games</b>'); };
  var gb1 = gamesBar;
  gamesBar = function () { return gb1().replace('<div class="rbar kgback">', '<div class="rbar kgback"><button class="tobible" data-act="read" aria-label="Back to the Bible">' + ic('back', 16) + ' Bible</button>'); };

  var actK = act;
  act = function (a, d) {
    d = d || {};
    if (a === 'favr') { var r = d.r, has = FAV.includes(r); FAV = has ? FAV.filter(function (x) { return x !== r; }) : [r].concat(FAV); store.s('fav', FAV); toast(has ? 'Removed from saved verses' : 'Saved ' + r); render(); return; }
    if (a === 'cpyr') { var tx = vtext(d.r) + ' — ' + d.r + ' (' + (mainV() === 'HEB' ? 'KJV' : mainV()) + ')'; try { navigator.clipboard.writeText(tx).then(function () { toast('Copied'); }, function () { toast('Copy is not available here'); }); } catch (e) { toast('Copy is not available here'); } return; }
    if (a === 'xrel') { var p = parse(d.r); if (p) { cur = { b: p.b, c: p.c, v: p.v }; view = 'read'; drawer = true; dtab = 'v'; sv(); render(); } return; }
    return actK(a, d);
  };
  var renderK = render;
  render = function () { renderK(); if (S.theme === 'kingdom' && !S.rc) document.documentElement.style.setProperty('--jesus', '#F08C7E'); };

  /* ============ 12. Passage analytics: every connection ============ */
  // Same word, word family, Hebrew->Greek bridges (from the dictionary's origin notes), shared meaning across
  // languages (from KJV renderings), shared English words and cross-references. All computed on the device.
  var LT = {
    same: { n: 'Same original word', c: '#D9A441', d: 'The same Hebrew or Greek word appears in both passages.' },
    fam: { n: 'Same word family', c: '#2FA39B', d: 'Different words that grow from the same root, according to the dictionary’s origin notes.' },
    bridge: { n: 'Hebrew ↔ Greek bridge', c: '#C8553D', d: 'A Greek word the dictionary traces back to a Hebrew word, linking the Old and New Testaments.' },
    concept: { n: 'Shared meaning', c: '#7C6BD6', d: 'Different words, often in different languages, that the KJV translates the same way.' },
    eng: { n: 'Shared English word', c: '#5B8DD6', d: 'The same English word in the KJV text (after removing very common words).' },
    xref: { n: 'Cross-reference', c: '#4E9A52', d: 'One passage is listed as a cross-reference of the other.' },
    common: { n: 'Common words', c: '#8D96A8', d: 'Shared, but very frequent — little weight on their own.' }
  };
  var STOPE = {}; ('the and of to in that for with unto is be he him his it a an as by from was were are not shall which they them their there this all thou thee thy thine ye you your me my we us our upon have had hath do did doth so but or at on one when then also what who whom will would should may might into out up no nor if even before after thing things made make let said say saith came come go went any every such than these those being been more most very own same other day lord god man men away down over through therefore because shalt wilt art hast dost hither thither yea behold compare idiom phrase self also great give take know see put set bring').split(' ').forEach(function (w) { STOPE[w] = 1; });
  function stemE(w) {
    w = (w || '').toLowerCase().replace(/[^a-z]/g, ''); if (w.length < 3) return '';
    if (w.length > 5 && /ings?$/.test(w)) w = w.replace(/ings?$/, '');
    else if (w.length > 5 && /(eth|est)$/.test(w)) w = w.slice(0, -3);
    else if (w.length > 4 && /ed$/.test(w)) w = w.slice(0, -2);
    else if (w.length > 4 && /ies$/.test(w)) w = w.slice(0, -3) + 'y';
    else if (w.length > 4 && /(ss|sh|ch|x)es$/.test(w)) w = w.slice(0, -2);
    else if (w.length > 3 && /s$/.test(w) && !/ss$/.test(w)) w = w.slice(0, -1);
    if (w.length > 4 && /e$/.test(w)) w = w.slice(0, -1);
    return w;
  }
  var GT = {}, GDF = null, GN = 1;
  function glossT(k) {
    if (GT[k]) return GT[k];
    var e = LEX[k], out = {}; if (!e) return (GT[k] = out);
    ((e[4] || '') + ' ' + (e[7] || '')).replace(/\[[^\]]*\]|\([^)]*\)|\d+/g, ' ').split(/[^A-Za-z]+/).forEach(function (w) { var lw = w.toLowerCase(); if (!lw || STOPE[lw]) return; var st = stemE(lw); if (st && !STOPE[st]) out[st] = out[st] || lw; });
    return (GT[k] = out);
  }
  var TT = {};
  function topT(k) { // a word's main meanings: its short definition and first five KJV renderings
    if (TT[k]) return TT[k]; var e = LEX[k], out = {}; if (!e) return (TT[k] = out);
    var first = (e[4] || '').replace(/\[[^\]]*\]|\([^)]*\)|\d+/g, ' ').split(/[,;.]/).slice(0, 5).join(' ');
    ((e[7] || '') + ' ' + first).split(/[^A-Za-z]+/).forEach(function (w) { var lw = w.toLowerCase(); if (!lw || STOPE[lw]) return; var st = stemE(lw); if (st && !STOPE[st]) out[st] = 1; });
    return (TT[k] = out);
  }
  function gdf() { if (GDF) return GDF; GDF = {}; GN = 0; Object.keys(LEX).forEach(function (k) { GN++; Object.keys(glossT(k)).forEach(function (t) { GDF[t] = (GDF[t] || 0) + 1; }); }); return GDF; }
  function hebRefs(g) { var e = LEX[g]; if (!e || g[0] !== 'G') return []; var o = e[5] || ''; if (!/hebrew|chaldee|aramaic/i.test(o)) return []; return (o.match(/\b\d{1,4}\b/g) || []).map(function (n) { return 'H' + n; }).filter(function (h) { return LEX[h]; }); }
  function freq(k) { return CI && CI[k] ? CI[k].n : 0; }
  function idf(k) { return Math.log(31102 / Math.max(1, freq(k) || 1)); }
  function isCommon(k) { var e = LEX[k]; return freq(k) >= 2500 || (e && SKIPPOS.test(e[6] || '')); }
  function famKey(k) { try { return rootOf(k); } catch (x) { return k; } }
  function relatedFam(a, b) { if (a[0] !== b[0]) return false; if (famKey(a) === famKey(b)) return true; var pa = PA[a] || [], pb = PA[b] || []; return pa.indexOf(b) >= 0 || pb.indexOf(a) >= 0 || pa.some(function (x) { return pb.indexOf(x) >= 0; }); }
  var ANSTATE = { pair: '' };
  anCompute = function () {
    ensureCI();
    var ps = AN.refs.map(parseRng).filter(Boolean).slice(0, 8);
    ps.forEach(function (p) {
      p.vs = []; for (var v = p.v1; v <= p.v2; v++) p.vs.push([v, KJV[p.b][p.c][v - 1] || '']);
      p.nums = {}; p.surf = {}; p.eng = {};
      p.vs.forEach(function (x) {
        x[1].replace(/([^\s{}]+)((?:\{[HG]\d+\})+)/g, function (m, w, tags) { (tags.match(/[HG]\d+/g) || []).forEach(function (k) { p.nums[k] = 1; if (!p.surf[k]) p.surf[k] = w.replace(/[^\w'-]/g, ''); }); return m; });
        plain(x[1]).split(/[^A-Za-z]+/).forEach(function (w) { var lw = w.toLowerCase(); if (!lw || STOPE[lw]) return; var st = stemE(lw); if (st && !STOPE[st] && st.length > 2) p.eng[st] = p.eng[st] || w; });
      });
    });
    var L = [], n = ps.length, df = gdf();
    // 1. same word (multi-passage)
    var by = {}; ps.forEach(function (p, i) { Object.keys(p.nums).forEach(function (k) { (by[k] = by[k] || []).push(i); }); });
    Object.keys(by).forEach(function (k) { var s = by[k]; if (s.length < 2) return; var c = isCommon(k); L.push({ t: c ? 'common' : 'same', ks: [k], ps: s, w: c ? .15 : Math.min(9, idf(k)), label: lab(k) }); });
    // pairwise links between different words
    for (var i = 0; i < n; i++) for (var j = i + 1; j < n; j++) {
      var A = Object.keys(ps[i].nums), B = Object.keys(ps[j].nums), seenC = {};
      A.forEach(function (a) {
        B.forEach(function (b) {
          if (a === b || !LEX[a] || !LEX[b]) return;
          // 2. family
          if (a[0] === b[0] && !isCommon(a) && !isCommon(b) && relatedFam(a, b)) { var r = famKey(a); L.push({ t: 'fam', ks: [a, b], ps: [i, j], w: .8 * (idf(a) + idf(b)) / 2, label: lab(r), root: r }); return; }
          // 3. Hebrew <-> Greek bridge
          var g = a[0] === 'G' ? a : b[0] === 'G' ? b : null, h = g === a ? b : a;
          if (g && h[0] === 'H') { var hr = hebRefs(g), vx = hr.filter(function (x) { return x === h || famKey(x) === famKey(h) || relatedFam(x, h); })[0]; if (vx) { L.push({ t: 'bridge', ks: g === a ? [a, b] : [b, a], ps: g === a ? [i, j] : [j, i], w: vx === h ? 5 : 3, label: lab(g) + ' ← ' + lab(h), via: vx }); return; } }
          // 4. shared meaning
          if (isCommon(a) || isCommon(b)) return;
          // grounded in the verses: what the KJV actually says for each word here
          var ta = topT(a), tb = topT(b), sa = stemE(ps[i].surf[a]), sb = stemE(ps[j].surf[b]), best = null;
          if (sa && !STOPE[sa] && (sa === sb || tb[sa])) best = sa; else if (sb && !STOPE[sb] && ta[sb]) best = sb;
          if (best) { var key = best + '|' + i + '|' + j, bw = Math.log(GN / Math.max(1, df[best] || 1)); if (seenC[key]) { seenC[key].ks.push(a, b); return; } seenC[key] = { t: 'concept', ks: [a, b], ps: [i, j], w: Math.max(2, bw * .6), label: (best === sa ? ps[i].surf[a] : ps[j].surf[b]).toLowerCase() }; L.push(seenC[key]); }
        });
      });
      // 5. shared English words
      Object.keys(ps[i].eng).forEach(function (st) { if (ps[j].eng[st]) L.push({ t: 'eng', ks: [], ps: [i, j], w: .5, label: ps[i].eng[st].toLowerCase(), st: st }); });
      // 6. cross-references (either direction, any verse in range)
      var xr = false; ps[i].vs.forEach(function (x) { (XREF[ps[i].b + ' ' + ps[i].c + ':' + x[0]] || []).forEach(function (r) { var q = parse(r); if (q && q.b === ps[j].b && q.c === ps[j].c && q.v >= ps[j].v1 && q.v <= ps[j].v2) xr = true; }); });
      ps[j].vs.forEach(function (x) { (XREF[ps[j].b + ' ' + ps[j].c + ':' + x[0]] || []).forEach(function (r) { var q = parse(r); if (q && q.b === ps[i].b && q.c === ps[i].c && q.v >= ps[i].v1 && q.v <= ps[i].v2) xr = true; }); });
      if (xr) L.push({ t: 'xref', ks: [], ps: [i, j], w: 5, label: 'cross-reference' });
    }
    // dedupe concept word lists
    L.forEach(function (l) { l.ks = l.ks.filter(function (k, x, arr) { return arr.indexOf(k) === x; }); });
    // edges per pair
    var ed = {}, pairs = {};
    L.forEach(function (l) { for (var a = 0; a < l.ps.length; a++) for (var b = a + 1; b < l.ps.length; b++) { var x = Math.min(l.ps[a], l.ps[b]), y = Math.max(l.ps[a], l.ps[b]), k = x + '-' + y; ed[k] = (ed[k] || 0) + l.w; (pairs[k] = pairs[k] || []).push(l); } });
    // word colours for highlighting (strongest link type wins)
    var rank = { bridge: 6, xref: 5, same: 4, fam: 3, concept: 2, eng: 1, common: 0 }, col = {}, cr = {};
    L.forEach(function (l) { l.ks.forEach(function (k) { if (col[k] == null || rank[l.t] > cr[k]) { col[k] = LT[l.t].c; cr[k] = rank[l.t]; } }); });
    var sh = Object.keys(col).filter(function (k) { return cr[k] > 0; }).map(function (k) { return { n: k, c: col[k], s: ps.map(function (p, i) { return p.nums[k] ? i : -1; }).filter(function (i) { return i >= 0; }) }; });
    L.sort(function (a, b) { return b.w - a.w; });
    return { ps: ps, sh: sh, ed: ed, L: L, pairs: pairs };
  };
  function wordChip(k, p) { var e = LEX[k], H = k[0] === 'H', sc = (e && e[0]) || (H && HEBL[k]) || ''; return '<a class="awc" data-k="' + k + '" title="' + esc(mean(k)) + '"><b class="' + (H ? 'hebw' : 'grk') + '">' + esc(sc.split(',')[0]) + '</b><span>' + esc(lab(k)) + '</span><small>' + k + (p && p.surf[k] ? ' · “' + esc(p.surf[k]) + '”' : '') + '</small></a>'; }
  function linkRow(l, R) {
    var T = LT[l.t], L4 = l.ps.map(function (i) { return '<span class="lp">' + 'ABCD'[i] + '</span>'; }).join('');
    var words = l.ks.map(function (k) { var pi = R.ps.findIndex(function (p) { return p.nums[k]; }); return wordChip(k, R.ps[pi]); }).join('<span class="arw">' + (l.t === 'bridge' ? '←' : '≈') + '</span>');
    var why = l.t === 'same' || l.t === 'common' ? esc(mean(l.ks[0]))
      : l.t === 'fam' ? 'Root: ' + esc(lab(l.root)) + ' <span class="dim">' + l.root + '</span>'
      : l.t === 'bridge' ? (l.via === l.ks[1] ? 'Greek word taken from this Hebrew word' : 'Greek word from Hebrew ' + esc(scriptOf(l.via) || '') + ' ' + esc(lab(l.via)) + ' <span class="dim">' + l.via + '</span>, of the same word family') + ' <span class="dim">(dictionary: ' + esc((LEX[l.ks[0]][5] || '').replace(/;$/, '')) + ')</span>'
      : l.t === 'concept' ? 'Both rendered “' + esc(l.label) + '” in the KJV'
      : l.t === 'eng' ? '“' + esc(l.label) + '” in the KJV text'
      : 'Listed as a cross-reference';
    return '<div class="alr" style="--c:' + T.c + '"><div class="alw">' + (words || '<b class="alt">' + esc(l.label) + '</b>') + '</div><div class="alm"><span>' + why + '</span><span class="lps">' + L4 + '</span></div></div>';
  }
  function anGraph2(R) {
    var n = R.ps.length, W = 420, Hh = 270, cx = W / 2, cy = Hh / 2;
    var P = R.ps.map(function (_, i) { var a = i / n * Math.PI * 2 - Math.PI / 2 + (n === 2 ? Math.PI / 2 : 0); return [cx + Math.cos(a) * 140, cy + Math.sin(a) * 105]; });
    var mx = Math.max.apply(null, [1].concat(Object.keys(R.ed).map(function (k) { return R.ed[k]; })));
    var edges = Object.keys(R.ed).map(function (k) {
      var ab = k.split('-').map(Number), a = P[ab[0]], b = P[ab[1]], ls = R.pairs[k].filter(function (l) { return l.t !== 'common'; }), top = ls.slice().sort(function (x, y) { return y.w - x.w; });
      var t0 = top[0] || R.pairs[k][0], col = LT[t0.t].c, mxp = [a[0] + (b[0] - a[0]) * .36, a[1] + (b[1] - a[1]) * .36], lbl = top.slice(0, 2).map(function (l) { return l.label; }).join(' · ');
      var on = !ANSTATE.pair || ANSTATE.pair === k;
      return '<g class="age' + (on ? '' : ' dimm') + '" data-act="anpair" data-p="' + k + '"><line x1="' + a[0] + '" y1="' + a[1] + '" x2="' + b[0] + '" y2="' + b[1] + '" stroke="' + col + '" stroke-width="' + (1.5 + R.ed[k] / mx * 9).toFixed(1) + '" stroke-linecap="round" class="anl"/>' +
        (lbl ? '<text x="' + mxp[0] + '" y="' + (mxp[1] - 6) + '" text-anchor="middle" class="agl" paint-order="stroke">' + esc(lbl.length > 30 ? lbl.slice(0, 29) + '…' : lbl) + '</text>' : '') + '</g>';
    }).join('');
    var nodes = R.ps.map(function (p, i) { return '<g><rect x="' + (P[i][0] - 66) + '" y="' + (P[i][1] - 16) + '" width="132" height="32" rx="10" class="agn"/><text x="' + (P[i][0] - 55) + '" y="' + (P[i][1] + 5) + '" class="agk">' + 'ABCD'[i] + '</text><text x="' + (P[i][0] + 7) + '" y="' + (P[i][1] + 5) + '" text-anchor="middle" class="agt">' + esc(p.label) + '</text></g>'; }).join('');
    return '<svg viewBox="0 0 ' + W + ' ' + Hh + '" class="angr2" role="img" aria-label="Connection network">' + edges + nodes + '</svg>';
  }
  function anMatrix(R) {
    var n = R.ps.length, mx = Math.max.apply(null, [1].concat(Object.keys(R.ed).map(function (k) { return R.ed[k]; })));
    var h = '<table class="amx"><tr><th></th>' + R.ps.map(function (p, i) { return '<th title="' + esc(p.label) + '">' + 'ABCD'[i] + '</th>'; }).join('') + '</tr>';
    for (var i = 0; i < n; i++) { h += '<tr><th title="' + esc(R.ps[i].label) + '">' + 'ABCD'[i] + '</th>'; for (var j = 0; j < n; j++) { if (i === j) { h += '<td class="self"></td>'; continue; } var k = Math.min(i, j) + '-' + Math.max(i, j), v = R.ed[k] || 0, c = (R.pairs[k] || []).filter(function (l) { return l.t !== 'common'; }).length; h += '<td class="' + (ANSTATE.pair === k ? 'on' : '') + '" data-act="anpair" data-p="' + k + '" style="--a:' + (v / mx).toFixed(2) + '"><b>' + c + '</b><small>' + (v ? Math.round(v) : 0) + '</small></td>'; } h += '</tr>'; }
    return h + '</table><p class="dim small" style="margin:6px 0 0">Number of links, and a strength score underneath. Tap a square to show only that pair.</p>';
  }
  analyzeHtml = function () {
    var R = anCompute(), n = R.ps.length;
    var L = ANSTATE.pair ? R.L.filter(function (l) { var ab = ANSTATE.pair.split('-').map(Number); return l.ps.indexOf(ab[0]) >= 0 && l.ps.indexOf(ab[1]) >= 0; }) : R.L;
    var counts = {}; L.forEach(function (l) { counts[l.t] = (counts[l.t] || 0) + 1; });
    var order = ['bridge', 'xref', 'same', 'fam', 'concept', 'eng', 'common'];
    var head = '<div class="top" style="border:0;background:none;padding:12px 16px 0"><button class="ib" data-act="side">' + ic('menu') + '</button><h2 class="lt">' + ic('target', 20) + ' Analyze passages</h2></div><div class="labv"><div class="dash" style="max-width:1140px">' +
      '<div class="cd s12"><p class="dim" style="margin:0 0 8px">Enter two to four passages. The app traces every connection between them: the same Hebrew or Greek word, word families, Hebrew-to-Greek bridges, shared meanings across languages, shared English words and cross-references.</p><div class="anin">' + [0, 1, 2, 3].map(function (i) { return '<input id="an' + i + '" placeholder="Passage ' + 'ABCD'[i] + ' — e.g. John 3:14" value="' + esc(AN.refs[i] || '') + '">'; }).join('') + '</div><div class="row"><button class="pri" data-act="anrun">Analyze</button>' + ANEX.map(function (x, i) { return '<button class="chip" data-act="anex" data-i="' + i + '">' + x[0] + '</button>'; }).join('') + '</div></div>';
    if (n < 2) return head + '<div class="cd s12 dim">Add at least two valid passages to compare.</div></div></div>';
    var total = R.L.filter(function (l) { return l.t !== 'common'; }).length;
    var legend = '<div class="alg">' + order.filter(function (t) { return counts[t]; }).map(function (t) { return '<span style="--c:' + LT[t].c + '"><i></i>' + LT[t].n + ' <b>' + counts[t] + '</b></span>'; }).join('') + '</div>';
    var groups = order.filter(function (t) { return counts[t]; }).map(function (t) {
      var ls = L.filter(function (l) { return l.t === t; }), rows = ls.slice(0, t === 'eng' || t === 'common' ? 40 : 60).map(function (l) { return linkRow(l, R); }).join('');
      var body = '<p class="dim small" style="margin:0 0 8px">' + LT[t].d + '</p>' + rows + (ls.length > 60 ? '<p class="dim small">Showing 60 of ' + ls.length + '.</p>' : '');
      return t === 'common' || t === 'eng' ? '<details class="alg2" style="--c:' + LT[t].c + '"><summary><i></i>' + LT[t].n + ' <b>' + ls.length + '</b></summary>' + body + '</details>' : '<section class="alg2" style="--c:' + LT[t].c + '"><h5><i></i>' + LT[t].n + ' <b>' + ls.length + '</b></h5>' + body + '</section>';
    }).join('');
    var pairNote = ANSTATE.pair ? '<p class="small" style="margin:0 0 10px">Showing links between <b>' + 'ABCD'[+ANSTATE.pair[0]] + '</b> and <b>' + 'ABCD'[+ANSTATE.pair[2]] + '</b> · <a data-act="anpair" data-p="">Show all pairs</a></p>' : '';
    return head +
      '<div class="cd s7"><h4>' + ic('link', 16) + ' How they connect <span class="dim" style="font-weight:400">' + total + ' links</span></h4>' + anGraph2(R) + legend + '</div>' +
      '<div class="cd s5"><h4>' + ic('chart', 16) + ' Connection strength</h4>' + anMatrix(R) + '</div>' +
      '<div class="cd s12"><h4>' + ic('spark', 16) + ' Every connection</h4>' + pairNote + (L.length ? groups : '<p class="dim">No links found between these passages.</p>') + '</div>' +
      R.ps.map(function (p, i) { return anCard(p, i, R); }).join('') +
      '<div class="cd s12"><h4>' + ic('bulb', 16) + ' AI synthesis</h4><div class="row"><button data-act="anai">Write a synthesis</button></div><div id="anai" class="aiout">' + (AN.ai || '<p class="dim">How do these passages relate? Claude can summarise the links and contrasts.</p>') + '</div></div></div></div>';
  };
  var actA = act;
  act = function (a, d) {
    if (a === 'anpair') { ANSTATE.pair = ANSTATE.pair === d.p ? '' : (d.p || ''); render(); return; }
    if (a === 'anrun' || a === 'anex') ANSTATE.pair = '';
    if ((a === 'study' || a === 'lab' || a === 'analyze' || a === 'anrel') && innerWidth <= 800 && SL.wb) { SL.wb = false; try { slsv(); } catch (x) {} } // on phones the Workbench sheet covered the whole page
    return actA(a, d);
  };
  if (innerWidth <= 800 && SL.wb) { SL.wb = false; try { slsv(); } catch (x) {} }

  /* ============ 13. Reading Plans library (66 plans, custom plans, progress, reader integration) ============ */
  // Plan schedules are stored data (plans.json, built and validated by plans/build.py). Progress and custom plans
  // are kept on this device (localStorage 'rp'); the app has no accounts, so nothing leaves the browser.
  var RPD = null, RPOK = {}, RPERR = '';
  var RP = store.g('rp', null) || { plans: {}, custom: [] };
  var rpsv = function () { store.s('rp', RP); };
  var PV = Object.assign({ tab: 'discover', q: '', cat: 'all', len: 'any', pace: 'any', open: null, mk: null }, store.g('rpv', {}));
  var pvsv = function () { store.s('rpv', { tab: PV.tab, open: PV.open }); };
  var RPR = store.g('rpr', null); // the reading you are on: { p: planId, d: dayIndex }
  var rprsv = function () { store.s('rpr', RPR); };
  var RPCAT = { daily: 'Daily & balanced', bible: 'Whole Bible', testament: 'Old & New Testament', wisdom: 'Psalms, wisdom & prayer', jesus: 'Jesus & growth', topics: 'Topics', people: 'People of the Bible', custom: 'My own plans' };
  var RPCOL = { daily: ['#22396B', '#101C3A'], bible: ['#4A3517', '#161B33'], testament: ['#1E4A3E', '#0D1F1B'], wisdom: ['#45305E', '#1A1230'], jesus: ['#5A2222', '#1E0E12'], topics: ['#3E4A24', '#161C0E'], people: ['#5A4022', '#22180C'], custom: ['#2A3549', '#0F1828'] };
  var RX = /^(.+?) (\d+)(?::(\d+)(?:-(\d+))?|-(\d+))?$/;
  function vcnt(b, c) { return KJV[b] && KJV[b][c] ? KJV[b][c].length : 0; }
  function runits(ref) { // "Book C" | "Book C-C2" | "Book C:V-V2" -> [{b,c,v1,v2}] or null if invalid
    var m = RX.exec(ref || ''); if (!m || BOOKS.indexOf(m[1]) < 0) return null;
    var b = m[1], c = +m[2], nc = KJV[b] ? Object.keys(KJV[b]).length : 0; if (c < 1 || c > nc) return null;
    if (m[5]) { var c2 = +m[5]; if (c2 < c || c2 > nc) return null; var o = []; for (var x = c; x <= c2; x++) o.push({ b: b, c: x, v1: 1, v2: vcnt(b, x) }); return o; }
    if (m[3]) { var v1 = +m[3], v2 = +(m[4] || m[3]), n = vcnt(b, c); if (v1 < 1 || v2 < v1 || v2 > n) return null; return [{ b: b, c: c, v1: v1, v2: v2 }]; }
    return [{ b: b, c: c, v1: 1, v2: vcnt(b, c) }];
  }
  function rlabel(ref) { var m = RX.exec(ref || ''); if (!m) return esc(ref); var b = m[1] === 'Psalms' && !m[5] ? 'Psalm' : m[1]; return esc(b + ' ' + m[2] + (m[3] ? ':' + m[3] + (m[4] && m[4] !== m[3] ? '–' + m[4] : '') : m[5] ? '–' + m[5] : '')); }
  function kjvReady() { return Object.keys(KJV).length >= 66 && KJV.Revelation && KJV.Revelation[22]; }
  function rpValidate(p) { return p.days.length > 0 && p.days.every(function (d) { return d.length && d.every(function (r) { return !!runits(r); }); }); }
  function allPlans() { return (RPD ? RPD.plans : []).concat(RP.custom || []).filter(function (p) { return RPOK[p.id]; }); }
  function getPlan(id) { var all = (RPD ? RPD.plans : []).concat(RP.custom || []); for (var i = 0; i < all.length; i++) if (all[i].id === id) return all[i]; return null; }
  function rpCheck() { if (!RPD || !kjvReady()) return false; (RPD.plans.concat(RP.custom || [])).forEach(function (p) { if (RPOK[p.id] == null) RPOK[p.id] = rpValidate(p); }); return true; }
  fetch('plans.json').then(function (r) { if (!r.ok) throw 0; return r.json(); }).then(function (j) { RPD = j; rpMigrate(); if (view === 'plans' || view === 'home') render(); }).catch(function () { RPERR = 'The reading plans could not be loaded. Check your connection and reopen the app.'; if (view === 'plans') render(); });
  var rpPoll = setInterval(function () { if (RPD && kjvReady()) { clearInterval(rpPoll); rpCheck(); if (view === 'plans' || view === 'home' || view === 'read') render(); } }, 400);

  // carry over progress from the earlier five plans (chapter ticks) into the new day-based records
  function rpMigrate() {
    if (RP.mig || !PLN || !PLN.active) { RP.mig = 1; rpsv(); return; }
    var map = { year: 'gen-rev', nt90: 'nt-90', gospels30: 'gospels-30', psalms30: 'psalms-30', proverbs31: 'proverbs-31' };
    var tryIt = function () {
      if (!kjvReady()) { setTimeout(tryIt, 500); return; }
      Object.keys(PLN.active).forEach(function (old) {
        var id = map[old], p = getPlan(id), A = PLN.active[old]; if (!p || RP.plans[id]) return;
        var st = { start: A.start || day(), items: {}, done: {} };
        p.days.forEach(function (d, i) { var all = true; d.forEach(function (r, k) { var us = runits(r) || [], ok = us.length && us.every(function (u) { return A.done[u.b + ' ' + u.c]; }); if (ok) st.items[i + '.' + k] = A.done[us[0].b + ' ' + us[0].c] || day(); else all = false; }); if (all) st.done[i] = day(); });
        RP.plans[id] = st;
      });
      RP.mig = 1; rpsv(); if (view === 'plans' || view === 'home') render();
    }; tryIt();
  }

  /* ---- progress ---- */
  function dayDone(S2, i, p) { return !!S2.done[i] || p.days[i].every(function (r, k) { return S2.items[i + '.' + k]; }); }
  function dAdd(iso, n) { var t = new Date(iso + 'T12:00:00Z'); t.setUTCDate(t.getUTCDate() + n); return t.toISOString().slice(0, 10); }
  function dDiff(a, b) { return Math.round((new Date(b + 'T12:00:00Z') - new Date(a + 'T12:00:00Z')) / 864e5); }
  function fmtD(iso) { try { return new Date(iso + 'T12:00:00Z').toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' }); } catch (e) { return iso; } }
  function prog(p) {
    var S2 = RP.plans[p.id]; if (!S2) return null;
    var n = p.days.length, done = 0, next = null, dates = {};
    for (var i = 0; i < n; i++) { if (dayDone(S2, i, p)) done++; else if (next === null) next = i; }
    Object.keys(S2.items).forEach(function (k) { dates[S2.items[k]] = 1; }); Object.keys(S2.done).forEach(function (k) { dates[S2.done[k]] = 1; });
    var t = day(), streak = 0, cur2 = dates[t] ? t : dAdd(t, -1); while (dates[cur2]) { streak++; cur2 = dAdd(cur2, -1); }
    var paused = !!S2.paused, elapsed = Math.max(0, dDiff(S2.start, S2.paused ? S2.pausedAt : t) - (S2.pausedDays || 0)) + 1;
    var expected = Math.min(n, elapsed), remain = n - done;
    return { S: S2, n: n, done: done, next: next, pct: Math.round(done / n * 100), streak: streak, paused: paused, finished: done === n, expected: expected, diff: done - expected, est: remain ? dAdd(t, remain - 1) : (S2.finishedAt || t) };
  }
  function itemDone(id, d, k) { var S2 = RP.plans[id]; return !!(S2 && (S2.items[d + '.' + k] || S2.done[d])); }
  function setDay(id, d, on) {
    var S2 = RP.plans[id], p = getPlan(id); if (!S2 || !p) return;
    if (on) { S2.done[d] = day(); p.days[d].forEach(function (r, k) { if (!S2.items[d + '.' + k]) S2.items[d + '.' + k] = day(); }); }
    else { delete S2.done[d]; p.days[d].forEach(function (r, k) { delete S2.items[d + '.' + k]; }); }
    var pr = prog(p); if (pr.finished && !S2.finishedAt) { S2.finishedAt = day(); toast('Plan complete — well done!'); } if (!pr.finished) delete S2.finishedAt;
    rpsv();
  }
  function setItem(id, d, k, on) { var S2 = RP.plans[id], p = getPlan(id); if (!S2 || !p) return; if (on) S2.items[d + '.' + k] = day(); else { delete S2.items[d + '.' + k]; delete S2.done[d]; } if (dayDone(S2, d, p)) S2.done[d] = S2.done[d] || day(); var pr = prog(p); if (pr.finished && !S2.finishedAt) { S2.finishedAt = day(); toast('Plan complete — well done!'); } rpsv(); }

  /* ---- cover art ---- */
  var RPI = {
    harp: '<path d="M14 40V12c0-4 4-6 8-4l14 7c4 2 6 6 6 10v15"/><path d="M14 40h28M20 14v26M26 17v23M32 20v20M38 24v16"/>',
    scroll: '<path d="M14 10h22a6 6 0 0 1 6 6v24a6 6 0 0 1-6 6H18"/><path d="M14 10a5 5 0 0 0-5 5v4h10v-4a5 5 0 0 0-5-5zM18 46a5 5 0 0 1-5-5v-3h10v3"/><path d="M22 20h14M22 26h14M22 32h10"/>',
    bolt: '<path d="M28 6L12 30h12l-4 18 16-24H24z"/>', mountain: '<path d="M6 42l14-22 8 12 6-8 12 18z"/><path d="M20 20l4 6"/>',
    path: '<path d="M24 46c-8-6 10-10 2-16s10-10 4-18"/><circle cx="30" cy="10" r="3"/>', sunrise: '<path d="M8 36h32M14 36a10 10 0 0 1 20 0"/><path d="M24 12v6M12 20l4 4M36 20l-4 4M6 30h4M38 30h4"/>',
    books: '<path d="M10 40V12h7v28M19 40V8h7v32M28 40l6-28 7 2-6 28z"/><path d="M8 42h34"/>', cross: '<path d="M24 6v36M14 16h20"/>',
    tablets: '<path d="M8 40V16a7 7 0 0 1 14 0v24zM26 40V16a7 7 0 0 1 14 0v24z"/><path d="M12 24h6M12 30h6M30 24h6M30 30h6"/>', lamp: '<path d="M10 32c0-6 8-8 18-8s12 4 12 8-6 6-15 6-15-2-15-6z"/><path d="M40 30l5-4M24 24c-3-5 0-10 2-12 0 4 4 6 1 12"/>',
    hands: '<path d="M22 44V22l-6-10c-1-3 3-4 4-2l6 10M26 44V22l6-10c1-3-3-4-4-2l-4 8"/>', quote: '<path d="M12 34c0-8 2-14 10-18M28 34c0-8 2-14 10-18"/><path d="M12 34h8v-8M28 34h8v-8"/>',
    anchor: '<circle cx="24" cy="11" r="4"/><path d="M24 15v28M16 22h16M10 30c0 8 6 13 14 13s14-5 14-13"/>', flame: '<path d="M24 44c-8 0-12-6-12-12 0-8 8-12 8-22 6 4 6 10 4 14 4-2 6-6 6-8 4 4 6 10 6 16 0 6-4 12-12 12z"/>',
    dove: '<path d="M8 28c6 0 10-4 14-10 2-4 6-6 10-4l6-2-4 6c0 10-8 18-20 18-2 0-4-2-6-8z"/><path d="M22 18c-4-4-10-6-14-4 2 4 6 8 12 8"/>', shield: '<path d="M24 6l16 6v12c0 10-7 17-16 20-9-3-16-10-16-20V12z"/><path d="M24 14v22M16 22h16"/>',
    crown: '<path d="M8 36L6 14l10 8 8-12 8 12 10-8-2 22z"/><path d="M8 40h32"/>', heart: '<path d="M24 42S8 32 8 20a8 8 0 0 1 16-2 8 8 0 0 1 16 2c0 12-16 22-16 22z"/>',
    storm: '<path d="M14 26a8 8 0 0 1 2-16 10 10 0 0 1 19 3 7 7 0 0 1-1 13z"/><path d="M22 30l-4 8h6l-3 8"/>', candle: '<path d="M18 44V22h12v22M14 44h20"/><path d="M24 20c-3-3-2-7 0-10 2 3 3 7 0 10z"/>',
    sun: '<circle cx="24" cy="24" r="8"/><path d="M24 6v6M24 36v6M6 24h6M36 24h6M11 11l4 4M33 33l4 4M37 11l-4 4M15 33l-4 4"/>', hourglass: '<path d="M14 6h20M14 42h20M16 6c0 10 16 12 16 18s-16 8-16 18M32 6c0 10-16 12-16 18s16 8 16 18"/>',
    home: '<path d="M8 24L24 10l16 14M12 22v20h24V22"/><path d="M20 42V30h8v12"/>', coin: '<circle cx="24" cy="24" r="16"/><circle cx="24" cy="24" r="11"/><path d="M24 17v14M20 20h6a3 3 0 0 1 0 6h-6"/>',
    tools: '<path d="M10 38l16-16M26 22l4-10 8 8-10 4M8 36l4 4"/>', leaf: '<path d="M10 40C10 18 24 8 40 8c0 18-12 30-30 32z"/><path d="M10 40L30 18"/>',
    sword: '<path d="M34 8h6v6L20 34l-6-6zM14 28l-4 4 6 6 4-4M10 38l-2 2"/>', person: '<circle cx="24" cy="15" r="7"/><path d="M10 42c0-9 6-15 14-15s14 6 14 15"/>'
  };
  function cover(p, big) {
    var c = RPCOL[p.cat] || RPCOL.custom, n = p.days.length;
    var mark = p.cat === 'people' ? '<text x="148" y="62" text-anchor="end" font-family="Libre Caslon Display,Georgia,serif" font-size="54" fill="#E8CF94" opacity=".9">' + esc(p.title[0]) + '</text>' : '<g transform="translate(108 14) scale(.9)" fill="none" stroke="#E8CF94" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" opacity=".92">' + (RPI[p.icon] || RPI.scroll) + '</g>';
    return '<svg class="rpc' + (big ? ' big' : '') + '" viewBox="0 0 160 90" preserveAspectRatio="xMidYMid slice" aria-hidden="true"><defs><linearGradient id="rg-' + esc(p.id) + '" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="' + c[0] + '"/><stop offset="1" stop-color="' + c[1] + '"/></linearGradient></defs><rect width="160" height="90" fill="url(#rg-' + esc(p.id) + ')"/>' +
      '<path d="M0 72 Q40 60 80 70 T160 64 V90 H0z" fill="#000" opacity=".16"/><rect x="5" y="5" width="150" height="80" rx="4" fill="none" stroke="#E8CF94" stroke-opacity=".28"/>' + mark +
      '<text x="14" y="74" font-family="Libre Caslon Display,Georgia,serif" font-size="30" fill="#F3EBD8">' + n + '</text><text x="' + (16 + String(n).length * 15) + '" y="74" font-family="Instrument Sans,system-ui,sans-serif" font-size="9" fill="#E8CF94" letter-spacing=".5">' + (n === 1 ? 'day' : 'days') + '</text></svg>';
  }
  function pace(p) { var m = (p.stats && p.stats.minutes) || 10; return m <= 10 ? 'light' : m <= 25 ? 'moderate' : 'intensive'; }
  var PACEN = { light: 'Light', moderate: 'Moderate', intensive: 'Intensive' };
  function lenK(n) { return n <= 31 ? 'short' : n <= 92 ? 'month3' : n <= 185 ? 'month6' : 'long'; }
  function commit(p) { var s = p.stats || {}, perDay = s.chapters ? s.chapters / p.days.length : 0; return '~' + (s.minutes || '?') + ' min a day' + (perDay >= 1.2 ? ' · ' + (Math.round(perDay * 10) / 10) + ' chapters' : ''); }
  function card(p) {
    var pr = prog(p);
    return '<button class="rpcard" data-act="rpopen" data-p="' + esc(p.id) + '">' + cover(p) + '<span class="rpb"><small>' + esc(RPCAT[p.cat] || '') + '</small><b>' + esc(p.title) + '</b><span class="rpd">' + esc(p.desc) + '</span><span class="rpm">' + commit(p) + '</span>' +
      (pr ? '<span class="rpg"><i style="width:' + pr.pct + '%"></i></span><span class="rpm">' + (pr.finished ? 'Completed' : pr.paused ? 'Paused · ' + pr.done + ' of ' + pr.n : 'Day ' + (pr.next + 1) + ' · ' + pr.pct + '%') + '</span>' : '') + '</span></button>';
  }
  function filtered() {
    var q = PV.q.trim().toLowerCase();
    return allPlans().filter(function (p) {
      if (PV.cat !== 'all' && p.cat !== PV.cat) return false;
      if (PV.len !== 'any' && lenK(p.days.length) !== PV.len) return false;
      if (PV.pace !== 'any' && pace(p) !== PV.pace) return false;
      if (q && (p.title + ' ' + p.desc + ' ' + (p.tags || []).join(' ') + ' ' + (RPCAT[p.cat] || '')).toLowerCase().indexOf(q) < 0) return false;
      return true;
    });
  }
  function listHtml() { var L = filtered(); return L.length ? '<p class="dim small rpcount">' + L.length + ' plan' + (L.length === 1 ? '' : 's') + '</p><div class="rpgrid">' + L.map(card).join('') + '</div>' : '<div class="rpempty"><b>No plans match.</b><span>Try another word, or clear the filters.</span><button data-act="rpclear">Clear filters</button></div>'; }
  function chips(name, val, opts) { return '<div class="rpchips" role="group" aria-label="' + name + '">' + opts.map(function (o) { return '<button class="chip ' + (PV[name] === o[0] ? 'on' : '') + '" data-act="rpf" data-k="' + name + '" data-v="' + o[0] + '" aria-pressed="' + (PV[name] === o[0]) + '">' + o[1] + '</button>'; }).join('') + '</div>'; }
  function discoverHtml() {
    var all = allPlans(), feat = all.filter(function (p) { return p.featured; });
    var browse = !PV.q && PV.cat === 'all' && PV.len === 'any' && PV.pace === 'any';
    var tp = all.filter(function (p) { return p.cat === 'topics'; }), pp = all.filter(function (p) { return p.cat === 'people'; });
    var extraT = [['faith-trust', 'Faith'], ['prayer', 'Prayer'], ['holy-spirit', 'The Holy Spirit'], ['holiness', 'Holiness'], ['warfare', 'Spiritual warfare'], ['character-of-god', 'Who God is']];
    return '<div class="rpsearch"><label class="hsearch">' + ic('search', 16) + '<input id="rpq" placeholder="Search plans: love, Psalms, David, one year…" value="' + esc(PV.q) + '" aria-label="Search reading plans" autocomplete="off"></label></div>' +
      chips('cat', PV.cat, [['all', 'All']].concat(Object.keys(RPCAT).filter(function (k) { return k !== 'custom' || (RP.custom || []).length; }).map(function (k) { return [k, RPCAT[k]]; }))) +
      '<div class="rpf2">' + chips('len', PV.len, [['any', 'Any length'], ['short', 'Up to a month'], ['month3', '1–3 months'], ['month6', '3–6 months'], ['long', 'A year or more']]) + chips('pace', PV.pace, [['any', 'Any pace'], ['light', 'Light'], ['moderate', 'Moderate'], ['intensive', 'Intensive']]) + '</div>' +
      (browse ? '<h3>Featured</h3><div class="rpfeat">' + feat.map(card).join('') + '</div>' +
        '<h3>Read by topic</h3><div class="rptags">' + tp.map(function (p) { return '<button data-act="rpopen" data-p="' + p.id + '">' + esc(p.title) + '</button>'; }).join('') + extraT.map(function (x) { return getPlan(x[0]) ? '<button data-act="rpopen" data-p="' + x[0] + '">' + x[1] + '</button>' : ''; }).join('') + '</div>' +
        '<h3>Follow a life</h3><div class="rptags people">' + pp.map(function (p) { return '<button data-act="rpopen" data-p="' + p.id + '"><i>' + esc(p.title[0]) + '</i>' + esc(p.title) + ' <small>' + p.days.length + ' days</small></button>'; }).join('') + '</div><h3>All plans</h3>' : '') +
      '<div id="rplist">' + listHtml() + '</div>';
  }
  function progressHtml(p, pr) {
    var nd = pr.next, d = nd == null ? null : p.days[nd];
    var note = pr.finished ? '<p class="rpnote ok">You finished this plan on ' + fmtD(pr.S.finishedAt || day()) + '. “Thy word is a lamp unto my feet, and a light unto my path.” <span class="dim">Psalm 119:105</span></p>'
      : pr.paused ? '<p class="rpnote">Paused on ' + fmtD(pr.S.pausedAt) + '. Your progress is kept; resume whenever you are ready.</p>'
      : pr.diff < -1 ? '<p class="rpnote">You are ' + (-pr.diff) + ' readings behind the calendar. No pressure — carry on at your own pace, or <a data-act="rpread" data-p="' + p.id + '" data-d="' + nd + '">catch up now</a>.</p>'
      : pr.diff > 0 ? '<p class="rpnote ok">' + pr.diff + ' day' + (pr.diff === 1 ? '' : 's') + ' ahead of the calendar.</p>' : '';
    var ring = '<svg class="rpring" viewBox="0 0 80 80" aria-hidden="true"><circle cx="40" cy="40" r="34" fill="none" stroke="var(--bar)" stroke-width="7"/><circle cx="40" cy="40" r="34" fill="none" stroke="var(--gold)" stroke-width="7" stroke-linecap="round" stroke-dasharray="' + (2 * Math.PI * 34).toFixed(1) + '" stroke-dashoffset="' + (2 * Math.PI * 34 * (1 - pr.done / pr.n)).toFixed(1) + '" transform="rotate(-90 40 40)"/><text x="40" y="46" text-anchor="middle" font-family="Libre Caslon Display,Georgia,serif" font-size="20" fill="var(--ink)">' + pr.pct + '%</text></svg>';
    var today = d ? '<div class="rptoday"><small>' + (nd + 1 > pr.expected ? 'Next reading' : 'Today\'s reading') + ' · Day ' + (nd + 1) + (p.labels && p.labels[nd] ? ' · ' + esc(p.labels[nd]) : '') + '</small><b>' + d.map(rlabel).join(', ') + '</b><div class="row"><button class="pri" data-act="rpread" data-p="' + p.id + '" data-d="' + nd + '">' + ic('book', 15) + ' Read</button><button data-act="rpday" data-p="' + p.id + '" data-d="' + nd + '" data-on="1">' + ic('check', 15) + ' Mark complete</button></div></div>' : '';
    var cal = '<div class="rpcal" role="list" aria-label="Reading calendar">' + p.days.map(function (x, i) { var dn = dayDone(pr.S, i, p); return '<button role="listitem" class="' + (dn ? 'dn' : '') + (i === nd ? ' nx' : '') + (i < pr.expected && !dn ? ' due' : '') + '" data-act="rpjump" data-d="' + i + '" title="Day ' + (i + 1) + ': ' + esc(x.map(rlabel).join(', ')) + (dn ? ' (complete)' : '') + '" aria-label="Day ' + (i + 1) + (dn ? ', complete' : '') + '"></button>'; }).join('') + '</div>';
    var cf = PV.cf || '';
    return '<section class="rpprog"><div class="rpst">' + ring + '<div class="rpkv"><div><b>' + pr.done + '</b><span>of ' + pr.n + ' days</span></div><div><b>' + (pr.streak || 0) + '</b><span>day streak</span></div><div><b>' + fmtD(pr.S.start) + '</b><span>started</span></div><div><b>' + (pr.finished ? fmtD(pr.S.finishedAt || day()) : pr.paused ? '—' : fmtD(pr.est)) + '</b><span>' + (pr.finished ? 'finished' : 'estimated finish') + '</span></div></div></div>' + note + today +
      '<h4>Reading calendar</h4>' + cal + '<p class="dim small">Gold squares are complete. Tap a day to jump to it in the schedule.</p>' +
      '<div class="row rpacts">' + (pr.finished ? '' : pr.paused ? '<button data-act="rpresume" data-p="' + p.id + '">' + ic('cr', 15) + ' Resume</button>' : '<button data-act="rppause" data-p="' + p.id + '">Pause</button>') +
      '<button data-act="rprestart" data-p="' + p.id + '" class="' + (cf === 'restart' ? 'warn' : '') + '">' + (cf === 'restart' ? 'Tap again to restart from day 1' : 'Restart') + '</button>' +
      '<button data-act="rpabandon" data-p="' + p.id + '" class="' + (cf === 'abandon' ? 'warn' : '') + '">' + (cf === 'abandon' ? 'Tap again to remove this plan and its progress' : 'Leave plan') + '</button></div></section>';
  }
  function scheduleHtml(p, pr) {
    var blocks = [], n = p.days.length, size = n > 60 ? 30 : n;
    for (var s = 0; s < n; s += size) {
      var rows = '';
      for (var i = s; i < Math.min(n, s + size); i++) {
        var dn = pr && dayDone(pr.S, i, p);
        rows += '<li id="rpd-' + i + '" class="' + (dn ? 'dn' : '') + (pr && i === pr.next ? ' nx' : '') + '"><span class="dno">' + (i + 1) + '</span><span class="drf">' + (p.labels && p.labels[i] ? '<em>' + esc(p.labels[i]) + '</em>' : '') + p.days[i].map(function (r, k) { var idn = pr && itemDone(p.id, i, k); return '<a class="' + (idn ? 'dn' : '') + '" data-act="rpread" data-p="' + p.id + '" data-d="' + i + '" data-k="' + k + '">' + rlabel(r) + '</a>'; }).join('<span class="sep">·</span>') + '</span>' +
          (pr ? '<button class="dck ' + (dn ? 'on' : '') + '" data-act="rpday" data-p="' + p.id + '" data-d="' + i + '" data-on="' + (dn ? '' : '1') + '" aria-label="' + (dn ? 'Mark day ' + (i + 1) + ' as not read' : 'Mark day ' + (i + 1) + ' complete') + '">' + ic('check', 14) + '</button>' : '') + '</li>';
      }
      var open = !pr ? s === 0 : (pr.next == null ? s === 0 : pr.next >= s && pr.next < s + size) || PV.mk != null && PV.mk >= s && PV.mk < s + size;
      blocks.push(size === n ? '<ol class="rpsch" start="1">' + rows + '</ol>' : '<details class="rpblk"' + (open ? ' open' : '') + '><summary>Days ' + (s + 1) + '–' + Math.min(n, s + size) + (pr ? ' <span class="dim">' + p.days.slice(s, s + size).filter(function (x, j) { return dayDone(pr.S, s + j, p); }).length + ' complete</span>' : '') + '</summary><ol class="rpsch">' + rows + '</ol></details>');
    }
    return blocks.join('');
  }
  function previewHtml(p) {
    var pr = prog(p), s = p.stats || {}, diff = pace(p) === 'intensive' ? 'Advanced' : p.days.length > 200 ? 'Committed' : pace(p) === 'moderate' ? 'Intermediate' : 'Beginner friendly';
    return '<button class="rpback" data-act="rptab" data-t="' + (pr ? 'mine' : 'discover') + '">' + ic('back', 15) + ' ' + (pr ? 'My plans' : 'All plans') + '</button>' +
      '<div class="rphero">' + cover(p, true) + '<div><small>' + esc(RPCAT[p.cat] || '') + '</small><h1>' + esc(p.title) + '</h1><p>' + esc(p.desc) + '</p>' +
      '<div class="rpfacts"><span><b>' + p.days.length + '</b> days</span><span><b>' + (s.minutes || '?') + '</b> min a day</span><span><b>' + (s.readings || p.days.reduce(function (a, d) { return a + d.length; }, 0)) + '</b> readings</span>' + (s.chapters ? '<span><b>' + s.chapters + '</b> chapters</span>' : '') + '<span><b>' + PACEN[pace(p)] + '</b> pace</span><span><b>' + diff + '</b></span></div>' +
      '<div class="row">' + (pr ? '<button class="pri" data-act="rpread" data-p="' + p.id + '" data-d="' + (pr.next == null ? 0 : pr.next) + '">' + ic('book', 15) + (pr.finished ? ' Read again' : ' Continue · Day ' + (pr.next + 1)) + '</button>' : '<button class="pri" data-act="rpstart" data-p="' + p.id + '">Start plan</button><button data-act="rpread" data-p="' + p.id + '" data-d="0" data-k="0">Read day 1 first</button>') +
      (p.cat === 'custom' ? '<button data-act="rpedit" data-p="' + p.id + '">Edit</button><button data-act="rpdelc" data-p="' + p.id + '" class="' + (PV.cf === 'delc' ? 'warn' : '') + '">' + (PV.cf === 'delc' ? 'Tap again to delete' : 'Delete') + '</button>' : '') + '</div></div></div>' +
      (pr ? progressHtml(p, pr) : '') + '<h3>Complete schedule</h3>' + scheduleHtml(p, pr);
  }
  function mineHtml() {
    var mine = allPlans().filter(function (p) { return RP.plans[p.id]; }), act0 = [], paused = [], fin = [];
    mine.forEach(function (p) { var pr = prog(p); (pr.finished ? fin : pr.paused ? paused : act0).push(p); });
    var sec = function (t, L, e) { return '<h3>' + t + ' <span class="dim">' + L.length + '</span></h3>' + (L.length ? '<div class="rpgrid">' + L.map(card).join('') + '</div>' : '<p class="dim">' + e + '</p>'); };
    var own = (RP.custom || []).filter(function (p) { return RPOK[p.id] && !RP.plans[p.id]; });
    return sec('Active', act0, 'No active plans. <a data-act="rptab" data-t="discover">Find a plan</a> or <a data-act="rptab" data-t="create">create your own</a>.') + (paused.length ? sec('Paused', paused, '') : '') + (fin.length ? sec('Completed', fin, '') : '') + (own.length ? sec('My own plans, not started', own, '') : '');
  }

  /* ---- custom plan builder ---- */
  var SETS = { 'Whole Bible': BOOKS, 'Old Testament': BOOKS.slice(0, 39), 'New Testament': BOOKS.slice(39), 'Torah': BOOKS.slice(0, 5), 'History': BOOKS.slice(5, 17), 'Wisdom': BOOKS.slice(17, 22), 'Prophets': BOOKS.slice(22, 39), 'Gospels': BOOKS.slice(39, 43), 'Letters': BOOKS.slice(44, 65), 'Psalms': ['Psalms'], 'Proverbs': ['Proverbs'] };
  var CB = store.g('rpcb', null) || { name: '', desc: '', mode: 'books', days: 30, streams: [{ label: '', books: ['Psalms'], rate: 'spread', per: 2 }], text: '', edit: null };
  var cbsv = function () { store.s('rpcb', CB); };
  function chList(books) { var o = []; books.forEach(function (b) { if (!KJV[b]) return; Object.keys(KJV[b]).sort(function (x, y) { return x - y; }).forEach(function (c) { o.push({ b: b, c: +c, v1: 1, v2: vcnt(b, +c) }); }); }); return o; }
  function vc(u) { return u.v2 - u.v1 + 1; }
  function splitTo(us, n) { us = us.slice(); while (us.length < n) { var k = 0; us.forEach(function (u, i) { if (vc(u) > vc(us[k])) k = i; }); var u = us[k]; if (u.v2 === u.v1) break; var mid = Math.floor((u.v1 + u.v2) / 2); us.splice(k, 1, { b: u.b, c: u.c, v1: u.v1, v2: mid }, { b: u.b, c: u.c, v1: mid + 1, v2: u.v2 }); } return us; }
  function partitionJS(us, n) {
    us = splitTo(us, n); var L = us.length, cum = [0]; us.forEach(function (u) { cum.push(cum[cum.length - 1] + vc(u)); }); var tot = cum[L], b = [0];
    for (var k = 1; k < n; k++) { var t = tot * k / n, lo = b[k - 1] + 1, hi = L - (n - k), best = lo; for (var j = lo; j <= hi; j++) if (Math.abs(cum[j] - t) < Math.abs(cum[best] - t)) best = j; b.push(Math.max(lo, Math.min(hi, best))); }
    b.push(L); var o = []; for (var i = 0; i < n; i++) o.push(us.slice(b[i], b[i + 1])); return o;
  }
  function refsOf(us) {
    var out = [], i = 0;
    while (i < us.length) { var u = us[i], full = u.v1 === 1 && u.v2 === vcnt(u.b, u.c); if (full) { var j = i; while (j + 1 < us.length && us[j + 1].b === u.b && us[j + 1].c === us[j].c + 1 && us[j + 1].v1 === 1 && us[j + 1].v2 === vcnt(u.b, us[j + 1].c)) j++; out.push(j === i ? u.b + ' ' + u.c : u.b + ' ' + u.c + '-' + us[j].c); i = j + 1; } else { out.push(u.b + ' ' + u.c + ':' + u.v1 + (u.v2 > u.v1 ? '-' + u.v2 : '')); i++; } }
    return out;
  }
  function buildCustom() { // -> { days, labels, errors }
    var errs = [], days = [], labels = null, n = Math.max(1, Math.min(1500, +CB.days || 0));
    if (CB.mode === 'books') {
      var cols = CB.streams.map(function (s) {
        var ch = chList(s.books || []); if (!ch.length) { errs.push('Choose at least one book' + (CB.streams.length > 1 ? ' for each reading' : '') + '.'); return null; }
        if (s.rate === 'per') { var per = Math.max(1, Math.min(50, +s.per || 1)), o = []; for (var i = 0; i < n; i++) { var day2 = []; for (var k = 0; k < per; k++) day2.push(ch[(i * per + k) % ch.length]); o.push(day2); } return o; }
        return partitionJS(ch, n);
      });
      if (errs.length) return { errors: errs };
      for (var i = 0; i < n; i++) { var d = []; cols.forEach(function (col, si) { var r = refsOf(col[i] || []), lab = CB.streams[si].label; r.forEach(function (x) { d.push(x); }); if (lab && r.length) { labels = labels || []; } }); days.push(d); }
      if (labels) labels = days.map(function (d, i) { return CB.streams.map(function (s, si) { return s.label ? s.label + ': ' + refsOf(cols[si][i] || []).map(function (r) { return rlabel(r).replace(/&amp;/g, '&'); }).join(', ') : ''; }).filter(Boolean).join(' · '); });
    } else {
      labels = [];
      (CB.text || '').split('\n').map(function (l) { return l.trim(); }).filter(Boolean).forEach(function (l, i) {
        var parts = l.split('|'), lab = parts.length > 1 ? parts[0].trim() : '', refs = (parts.length > 1 ? parts.slice(1).join('|') : parts[0]).split(';').map(function (x) { return x.trim(); }).filter(Boolean), out = [];
        refs.forEach(function (r) { var p = parse(r), m = /:(\d+)\s*[-–]\s*(\d+)$/.exec(r), cr = /^\D*\d*\D+\s(\d+)\s*[-–]\s*(\d+)$/.exec(r); if (!p) { errs.push('Line ' + (i + 1) + ': “' + r + '” is not a Bible reference.'); return; } var ref = cr && !/:/.test(r) ? p.b + ' ' + cr[1] + '-' + cr[2] : /:/.test(r) ? p.b + ' ' + p.c + ':' + p.v + (m ? '-' + m[2] : '') : p.b + ' ' + p.c; if (!runits(ref)) { errs.push('Line ' + (i + 1) + ': “' + r + '” is outside the chapter or verse range.'); return; } out.push(ref); });
        if (out.length) { days.push(out); labels.push(lab); }
      });
      if (!days.length && !errs.length) errs.push('Add at least one line, for example: Psalm 23 or Courage | Joshua 1:1-9');
      if (labels.every(function (x) { return !x; })) labels = null;
    }
    return { days: days, labels: labels, errors: errs };
  }
  function bookPicker(si) {
    var s = CB.streams[si];
    return '<div class="cbbooks">' + Object.keys(SETS).map(function (k) { var on = SETS[k].every(function (b) { return s.books.indexOf(b) >= 0; }) && SETS[k].length === s.books.length; return '<button class="chip ' + (on ? 'on' : '') + '" data-act="cbset" data-s="' + si + '" data-v="' + k + '">' + k + '</button>'; }).join('') + '</div>' +
      '<details class="cbsel"><summary>Choose books (' + s.books.length + ' selected)</summary><div class="cbgrid">' + BOOKS.map(function (b) { return '<label><input type="checkbox" data-cbb="' + si + '" value="' + esc(b) + '"' + (s.books.indexOf(b) >= 0 ? ' checked' : '') + '>' + esc(b) + '</label>'; }).join('') + '</div></details>';
  }
  function createHtml() {
    var R = buildCustom(), ok = !R.errors.length && R.days.length;
    var streamsH = CB.streams.map(function (s, si) {
      return '<div class="cbstream"><div class="row" style="justify-content:space-between"><b>Reading ' + (si + 1) + '</b>' + (CB.streams.length > 1 ? '<button class="ib" data-act="cbrm" data-s="' + si + '" aria-label="Remove reading ' + (si + 1) + '">' + ic('x', 14) + '</button>' : '') + '</div>' +
        '<input data-cb="label" data-s="' + si + '" placeholder="Optional label, e.g. Morning or Evening" value="' + esc(s.label || '') + '">' + bookPicker(si) +
        '<div class="cbrate"><label><input type="radio" name="rate' + si + '" data-cb="rate" data-s="' + si + '" value="spread"' + (s.rate !== 'per' ? ' checked' : '') + '> Spread these books across the whole plan</label><label><input type="radio" name="rate' + si + '" data-cb="rate" data-s="' + si + '" value="per"' + (s.rate === 'per' ? ' checked' : '') + '> <input type="number" min="1" max="50" data-cb="per" data-s="' + si + '" value="' + (s.per || 1) + '" style="width:64px"> chapters a day (starts again when finished)</label></div></div>';
    }).join('');
    var prev = ok ? '<div class="cbprev"><b>' + R.days.length + ' days</b> · ' + R.days.reduce(function (a, d) { return a + d.length; }, 0) + ' readings<ol>' + R.days.slice(0, 7).map(function (d, i) { return '<li><span class="dno">' + (i + 1) + '</span>' + (R.labels && R.labels[i] ? '<em>' + esc(R.labels[i]) + '</em> ' : '') + d.map(rlabel).join(', ') + '</li>'; }).join('') + (R.days.length > 7 ? '<li class="dim">… and ' + (R.days.length - 7) + ' more days</li>' : '') + '</ol></div>' : '<div class="cbprev err">' + R.errors.map(esc).join('<br>') + '</div>';
    return '<p class="dim">Make a plan of your own. It is saved privately on this device.</p>' +
      '<div class="cbform"><label class="f">Plan name<input data-cb="name" value="' + esc(CB.name) + '" placeholder="e.g. Gospels in 60 days" maxlength="60"></label><label class="f">Short description (optional)<input data-cb="desc" value="' + esc(CB.desc) + '" maxlength="140"></label>' +
      '<div class="subt" role="tablist"><button class="' + (CB.mode === 'books' ? 'on' : '') + '" data-act="cbmode" data-v="books">Read through books</button><button class="' + (CB.mode === 'text' ? 'on' : '') + '" data-act="cbmode" data-v="text">Choose my own passages</button></div>' +
      (CB.mode === 'books' ? '<label class="f">Number of days<input type="number" min="1" max="1500" data-cb="days" value="' + CB.days + '" style="max-width:140px"></label>' + streamsH + (CB.streams.length < 3 ? '<button data-act="cbadd">' + ic('plus', 14) + ' Add another daily reading</button>' : '') +
        '<p class="dim small">Examples: Psalms with 2 chapters a day for 75 days; Proverbs 1 a day plus New Testament 2 a day; Old Testament (Morning) and New Testament (Evening) spread over a year; a single book in 30 days.</p>'
        : '<label class="f">One day per line. Add a theme before a bar if you like.<textarea data-cb="text" rows="10" placeholder="Psalm 23&#10;Courage | Joshua 1:1-9&#10;John 3:1-21; Romans 5:1-11">' + esc(CB.text) + '</textarea></label>') +
      '<h4>Preview</h4><div id="cbprev">' + prev + '</div><div class="row"><button class="pri" data-act="cbsave"' + (ok && CB.name.trim() ? '' : ' disabled') + '>' + (CB.edit ? 'Save changes' : 'Save plan') + '</button>' + (ok && !CB.name.trim() ? '<span class="dim small">Give your plan a name to save it.</span>' : '') + (CB.edit ? '<button data-act="cbcancel">Cancel</button>' : '') + '</div></div>';
  }

  /* ---- the view ---- */
  plansHtml = function () {
    var head = '<div class="home rpv"><div class="greet"><button class="ib mobm" data-act="side" aria-label="Menu">' + ic('menu') + '</button><div><h1>Reading plans</h1></div></div>';
    if (RPERR) return head + '<p class="rpnote">' + esc(RPERR) + '</p></div>';
    if (!RPD || !rpCheck()) return head + '<p class="dim">Loading and checking the plans…</p></div>';
    if (PV.open) { var p = getPlan(PV.open); if (p && RPOK[p.id]) return head.replace('<h1>Reading plans</h1>', '<span class="dim small">Reading plans</span>') + previewHtml(p) + '</div>'; PV.open = null; }
    var nMine = Object.keys(RP.plans).filter(function (id) { return getPlan(id); }).length;
    var tabs = '<div class="subt rptabs" role="tablist"><button class="' + (PV.tab === 'discover' ? 'on' : '') + '" data-act="rptab" data-t="discover">Discover</button><button class="' + (PV.tab === 'mine' ? 'on' : '') + '" data-act="rptab" data-t="mine">My plans' + (nMine ? ' <b>' + nMine + '</b>' : '') + '</button><button class="' + (PV.tab === 'create' ? 'on' : '') + '" data-act="rptab" data-t="create">' + ic('plus', 14) + ' Create</button></div>';
    return head + '<p class="dim">' + allPlans().length + ' plans to read Scripture at your own pace. Missed a day? Simply carry on.</p>' + tabs + (PV.tab === 'mine' ? mineHtml() : PV.tab === 'create' ? createHtml() : discoverHtml()) + '</div>';
  };
  function refreshList() { var el = $('#rplist'); if (el) el.innerHTML = listHtml(); }
  function refreshPrev() { var el = $('#cbprev'); if (!el) return; var R = buildCustom(), ok = !R.errors.length && R.days.length; var tmp = document.createElement('div'); tmp.innerHTML = createHtml(); var np = tmp.querySelector('#cbprev'); if (np) el.innerHTML = np.innerHTML; var sb = $('[data-act="cbsave"]'); if (sb) sb.disabled = !(ok && CB.name.trim()); }
  document.addEventListener('input', function (e) {
    var t = e.target;
    if (t.id === 'rpq') { PV.q = t.value; refreshList(); return; }
    if (t.dataset && t.dataset.cb) { var k = t.dataset.cb, si = +t.dataset.s; if (k === 'label' || k === 'per') CB.streams[si][k] = t.value; else if (k !== 'rate') CB[k] = t.value; cbsv(); refreshPrev(); }
  });
  document.addEventListener('change', function (e) {
    var t = e.target;
    if (t.dataset && t.dataset.cb === 'rate') { CB.streams[+t.dataset.s].rate = t.value; cbsv(); refreshPrev(); }
    if (t.dataset && t.dataset.cbb != null) { var s = CB.streams[+t.dataset.cbb], b = t.value, i = s.books.indexOf(b); if (t.checked && i < 0) s.books.push(b); if (!t.checked && i >= 0) s.books.splice(i, 1); s.books.sort(function (x, y) { return BOOKS.indexOf(x) - BOOKS.indexOf(y); }); cbsv(); render(); }
  });

  /* ---- reader integration ---- */
  function dayUnits(p, d) { var o = []; p.days[d].forEach(function (r, k) { (runits(r) || []).forEach(function (u) { o.push({ b: u.b, c: u.c, v1: u.v1, v2: u.v2, k: k, r: r }); }); }); return o; }
  function openUnit(u) { go({ b: u.b, c: u.c, v: u.v1 }, true); }
  function rpBar() {
    if (!RPR || !RPD) return '';
    var p = getPlan(RPR.p); if (!p || !p.days[RPR.d]) return '';
    var us = dayUnits(p, RPR.d), i = -1; us.forEach(function (u, j) { if (i < 0 && u.b === cur.b && u.c === cur.c) i = j; }); if (i < 0) return '';
    var u = us[i], last = i === us.length - 1, started = !!RP.plans[p.id], dn = started && dayDone(RP.plans[p.id], RPR.d, p);
    var part = u.v1 > 1 || u.v2 < vcnt(u.b, u.c) ? ' · read verses ' + u.v1 + '–' + u.v2 : '';
    return '<div class="planbar rpbar" role="region" aria-label="Reading plan"><div class="rpbt"><small>' + esc(p.title) + ' · Day ' + (RPR.d + 1) + ' of ' + p.days.length + (us.length > 1 ? ' · ' + (i + 1) + ' of ' + us.length : '') + '</small><b>' + p.days[RPR.d].map(function (r, k) { return '<span class="' + (k === u.k ? 'cur' : '') + (started && itemDone(p.id, RPR.d, k) ? ' dn' : '') + '">' + rlabel(r) + '</span>'; }).join(', ') + '</b>' + (part ? '<small>' + part.slice(3) + '</small>' : '') + '</div>' +
      '<div class="row"><button data-act="rpback">' + ic('back', 14) + ' Plan</button>' + (i > 0 ? '<button data-act="rpstep" data-i="' + (i - 1) + '" aria-label="Previous reading">' + ic('cl', 14) + '</button>' : '') +
      (!last ? '<button class="pri" data-act="rpstep" data-i="' + (i + 1) + '">Next ' + ic('cr', 14) + '</button>' : started ? (dn ? '<button data-act="rpnextday">Next day ' + ic('cr', 14) + '</button>' : '<button class="pri" data-act="rpfinish">' + ic('check', 14) + ' Complete day ' + (RPR.d + 1) + '</button>') : '<button class="pri" data-act="rpstart" data-p="' + p.id + '">Start this plan</button>') + '</div></div>';
  }
  planBar = function () { return ''; };
  var readRP = readHtml;
  readHtml = function () { var h = readRP(), b = rpBar(); return b ? h.replace('<header class="chead">', b + '<header class="chead">') : h; };
  homePlan = function () {
    if (!RPD || !rpCheck()) return '<div class="homeplan"><div><b>Reading plans</b><br><small>Loading…</small></div><button data-act="plans">Plans</button></div>';
    var act0 = allPlans().filter(function (p) { var pr = prog(p); return pr && !pr.paused && !pr.finished; }).slice(0, 2);
    if (!act0.length) return '<div class="homeplan"><div><b>Read a little every day</b><br><small>' + allPlans().length + ' reading plans: the whole Bible, Psalms, the life of Jesus, topics like hope and peace, and people like David and Ruth.</small></div><button class="pri" data-act="plans">Find a plan</button></div>';
    return act0.map(function (p) { var pr = prog(p), d = p.days[pr.next]; return '<div class="homeplan rph"><div><small>' + esc(p.title) + ' · Day ' + (pr.next + 1) + ' of ' + pr.n + '</small><br><b>' + d.map(rlabel).join(', ') + '</b><span class="rpg"><i style="width:' + pr.pct + '%"></i></span></div><button class="pri" data-act="rpread" data-p="' + p.id + '" data-d="' + pr.next + '">Read</button></div>'; }).join('');
  };

  var actR = act;
  act = function (a, d) {
    d = d || {};
    var p = d.p ? getPlan(d.p) : null, cfKeep = false;
    switch (a) {
      case 'plans': view = 'plans'; if (innerWidth <= 800) side = false; PV.cf = null; sv(); render(); return;
      case 'rptab': PV.tab = d.t; PV.open = null; PV.cf = null; pvsv(); view = 'plans'; render(); return;
      case 'rpopen': PV.open = d.p; PV.cf = null; PV.mk = null; pvsv(); view = 'plans'; render(); var m0 = $('#main'); if (m0) m0.scrollTop = 0; return;
      case 'rpf': PV[d.k] = d.v; render(); return;
      case 'rpclear': PV.q = ''; PV.cat = 'all'; PV.len = 'any'; PV.pace = 'any'; render(); return;
      case 'rpstart': if (!p) return; RP.plans[p.id] = { start: day(), items: {}, done: {} }; rpsv(); toast('“' + p.title + '” started. Day 1 is ready.'); if (view === 'read') render(); else { PV.open = p.id; pvsv(); render(); } return;
      case 'rppause': if (RP.plans[d.p]) { RP.plans[d.p].paused = true; RP.plans[d.p].pausedAt = day(); rpsv(); toast('Plan paused'); } render(); return;
      case 'rpresume': { var S2 = RP.plans[d.p]; if (S2) { S2.pausedDays = (S2.pausedDays || 0) + Math.max(0, dDiff(S2.pausedAt || day(), day())); S2.paused = false; delete S2.pausedAt; rpsv(); toast('Welcome back'); } render(); return; }
      case 'rprestart': if (PV.cf !== 'restart') { PV.cf = 'restart'; render(); return; } RP.plans[d.p] = { start: day(), items: {}, done: {} }; rpsv(); PV.cf = null; toast('Restarted from day 1'); render(); return;
      case 'rpabandon': if (PV.cf !== 'abandon') { PV.cf = 'abandon'; render(); return; } delete RP.plans[d.p]; if (RPR && RPR.p === d.p) { RPR = null; rprsv(); } rpsv(); PV.cf = null; PV.open = null; PV.tab = 'mine'; pvsv(); toast('Plan removed'); render(); return;
      case 'rpday': setDay(d.p, +d.d, !!d.on); render(); return;
      case 'rpjump': PV.mk = +d.d; render(); setTimeout(function () { var el = document.getElementById('rpd-' + d.d); if (el) { el.scrollIntoView({ block: 'center' }); el.classList.add('flash'); } }, 30); return;
      case 'rpread': { if (!p) return; var di = +d.d || 0, us = dayUnits(p, di), k = d.k != null ? +d.k : 0, u = us.filter(function (x) { return x.k === k; })[0] || us[0]; if (!u) return; RPR = { p: p.id, d: di }; rprsv(); openUnit(u); return; }
      case 'rpstep': { var pp = RPR && getPlan(RPR.p); if (!pp) return; var us2 = dayUnits(pp, RPR.d), to = us2[+d.i], from = us2[+d.i - 1]; if (to && from && from.k !== to.k && RP.plans[pp.id]) setItem(pp.id, RPR.d, from.k, true); if (to) openUnit(to); return; }
      case 'rpfinish': { var p2 = RPR && getPlan(RPR.p); if (!p2) return; setDay(p2.id, RPR.d, true); var pr2 = prog(p2); toast(pr2.finished ? 'Plan complete — well done!' : 'Day ' + (RPR.d + 1) + ' complete'); render(); return; }
      case 'rpnextday': { var p3 = RPR && getPlan(RPR.p); if (!p3) return; var nd = RPR.d + 1 < p3.days.length ? RPR.d + 1 : RPR.d; RPR = { p: p3.id, d: nd }; rprsv(); openUnit(dayUnits(p3, nd)[0]); return; }
      case 'rpback': { if (RPR) { PV.open = RPR.p; PV.mk = RPR.d; pvsv(); } view = 'plans'; sv(); render(); setTimeout(function () { if (RPR) { var el = document.getElementById('rpd-' + RPR.d); if (el) el.scrollIntoView({ block: 'center' }); } }, 30); return; }
      case 'cbmode': CB.mode = d.v; cbsv(); render(); return;
      case 'cbadd': CB.streams.push({ label: '', books: ['Matthew', 'Mark', 'Luke', 'John'], rate: 'spread', per: 2 }); cbsv(); render(); return;
      case 'cbrm': CB.streams.splice(+d.s, 1); cbsv(); render(); return;
      case 'cbset': CB.streams[+d.s].books = SETS[d.v].slice(); cbsv(); render(); return;
      case 'cbcancel': CB = { name: '', desc: '', mode: 'books', days: 30, streams: [{ label: '', books: ['Psalms'], rate: 'spread', per: 2 }], text: '', edit: null }; cbsv(); PV.tab = 'mine'; render(); return;
      case 'cbsave': {
        var R = buildCustom(); if (R.errors.length || !R.days.length || !CB.name.trim()) { toast('Check the plan first'); return; }
        var id = CB.edit || 'c-' + Date.now().toString(36), w = R.days.reduce(function (a2, dd) { return a2 + dd.reduce(function (b2, r) { return b2 + (runits(r) || []).reduce(function (c2, u) { return c2 + vc(u); }, 0); }, 0); }, 0);
        var plan = { id: id, title: CB.name.trim(), cat: 'custom', desc: CB.desc.trim() || 'My own reading plan.', days: R.days, labels: R.labels, icon: 'path', tags: ['custom'], stats: { readings: R.days.reduce(function (a2, dd) { return a2 + dd.length; }, 0), minutes: Math.max(1, Math.round(w * 25 / R.days.length / 200)) }, spec: JSON.parse(JSON.stringify(CB)) };
        var i = (RP.custom || []).findIndex(function (x) { return x.id === id; }); RP.custom = RP.custom || []; if (i >= 0) RP.custom[i] = plan; else RP.custom.push(plan);
        RPOK[id] = rpValidate(plan); if (!RPOK[id]) { toast('This plan has an invalid reference'); return; }
        if (CB.edit && RP.plans[id]) { var S3 = RP.plans[id]; Object.keys(S3.done).forEach(function (k) { if (+k >= plan.days.length) delete S3.done[k]; }); Object.keys(S3.items).forEach(function (k) { var a3 = k.split('.'); if (+a3[0] >= plan.days.length || +a3[1] >= plan.days[+a3[0]].length) delete S3.items[k]; }); }
        rpsv(); CB = { name: '', desc: '', mode: 'books', days: 30, streams: [{ label: '', books: ['Psalms'], rate: 'spread', per: 2 }], text: '', edit: null }; cbsv(); PV.open = id; pvsv(); toast('Plan saved'); render(); return;
      }
      case 'rpedit': if (p && p.spec) { CB = JSON.parse(JSON.stringify(p.spec)); CB.edit = p.id; cbsv(); PV.open = null; PV.tab = 'create'; render(); } return;
      case 'rpdelc': if (PV.cf !== 'delc') { PV.cf = 'delc'; render(); return; } RP.custom = (RP.custom || []).filter(function (x) { return x.id !== d.p; }); delete RP.plans[d.p]; rpsv(); PV.cf = null; PV.open = null; PV.tab = 'mine'; toast('Plan deleted'); render(); return;
    }
    if (a !== 'rptab' && a !== 'plans') PV.cf = cfKeep ? PV.cf : null;
    return actR(a, d);
  };

  /* ============ 14. Save online: private per-person sync through the `db` capability ============ */
  // Each signed-in person's data lives at data/users/<their id>/<key>, a subtree nobody else can read (not even
  // the artifact's owner). localStorage stays the working copy; changes upload a few seconds later, and newer
  // data from another device is pulled when the app opens or comes back into view. Last change wins, per item.
  var SYNC_KEYS = ['set', 'lay', 'tpl', 'marks', 'notes', 'pal', 'prs', 'profile', 'cur', 'fav', 'mem', 'plans', 'rp', 'rpcb', 'u15', 'wb', 'pl', 'jr', 'kids', 'qh', 'qcfg', 'hist', 'kingdomgames.v1'];
  var CH = 60000; // characters per stored chunk (keeps each record well under the 256 KiB limit, even for Hebrew/Greek text)
  var SY = { db: null, uid: null, state: 'starting', last: store.g('sync.last', 0), err: '', meta: store.g('sync.meta', {}), sent: {}, dirty: {}, timer: 0, busy: false, first: !store.g('sync.meta', null), pending: false };
  function syMeta() { try { localStorage.setItem('sync.meta', JSON.stringify(SY.meta)); localStorage.setItem('sync.last', JSON.stringify(SY.last)); } catch (e) {} }
  function raw(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
  function syStatus(st, err) { SY.state = st; if (err != null) SY.err = err; var el = document.getElementById('synst'); if (el) el.outerHTML = syPill(); }
  function syPill() {
    var t = { starting: ['cloud', 'Connecting…'], ok: ['cloud', 'Saved online'], saving: ['cloud', 'Saving…'], local: ['cloudoff', 'On this device only'], error: ['cloudoff', 'Not saved online yet'] }[SY.state] || ['cloud', ''];
    return '<button id="synst" class="synst ' + SY.state + '" data-act="syncinfo" title="' + esc(t[1]) + '">' + (t[0] === 'cloud' ? '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M7 18h10a4 4 0 0 0 .5-8A6 6 0 0 0 6 9.5 4.3 4.3 0 0 0 7 18z"/>' + (SY.state === 'ok' ? '<path d="M9.5 13.5l2 2 3.5-4"/>' : '') + '</svg>' : '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" aria-hidden="true"><path d="M7 18h10a4 4 0 0 0 .5-8A6 6 0 0 0 6 9.5 4.3 4.3 0 0 0 7 18z"/><path d="M4 4l16 16"/></svg>') + '<span class="lb">' + t[1] + '</span></button>';
  }
  var side2 = sideHtml;
  sideHtml = function () { return side2().replace(/(<button class="prof"[\s\S]*?<\/button>)/, '$1' + syPill()); };

  // every local save goes through store.s; Kingdom Games (in its frame) writes localStorage directly, which reaches us as a storage event
  var storeS0 = store.s;
  store.s = function (k, v) { if (SY.frozen) return; storeS0.call(store, k, v); syMark(k); }; // frozen while newer data is being loaded, so old in-memory copies cannot overwrite it
  window.addEventListener('storage', function (e) { if (e.key && !SY.frozen) syMark(e.key); });
  // baseline: what each item held when the app opened, so re-saving an unchanged value is not mistaken for an edit
  SY.base = {}; SYNC_KEYS.forEach(function (k) { SY.base[k] = raw(k) || ''; });
  function syMark(k) {
    if (SYNC_KEYS.indexOf(k) < 0) return;
    var r = raw(k) || ''; if (r === SY.base[k]) return;
    SY.base[k] = r; SY.meta[k] = Date.now(); SY.dirty[k] = 1; syMeta();
    if (!SY.db) return; clearTimeout(SY.timer); SY.timer = setTimeout(syPush, 2500); if (SY.state === 'ok') syStatus('saving');
  }
  function col() { return SY.db.collection('data/users/' + SY.uid); }
  function retry(fn) { return fn().catch(function (e) { if (e && e.code === 'unavailable') return new Promise(function (r) { setTimeout(r, 800 + Math.random() * 1200); }).then(fn); throw e; }); }
  // the last value this device and the online copy agreed on, per item: the base for a three-way merge
  SY.bv = store.g('sync.bv', {});
  function bvSave() { try { localStorage.setItem('sync.bv', JSON.stringify(SY.bv)); } catch (e) { /* too large for this browser: merges fall back to combining */ } }
  function readKey(k) { // -> stored string, or null if there is no online copy
    var c = col();
    return retry(function () { return c.doc(k).get(); }).then(function (d) {
      if (!d.exists) return null; var b = d.data() || {}, n = b.n || 1, v = b.c || '', w = Promise.resolve();
      for (var i = 1; i < n; i++) (function (i) { w = w.then(function () { return retry(function () { return c.doc(k + '~' + i).get(); }).then(function (x) { v += (x.exists && x.data().c) || ''; }); }); })(i);
      return w.then(function () { (SY.parts = SY.parts || {})[k] = n; return v; });
    });
  }
  function writeKey(k, v) {
    var n = Math.max(1, Math.ceil(v.length / CH)), old = (SY.parts && SY.parts[k]) || 1, c = col(), w = Promise.resolve();
    for (var i = 1; i < n; i++) (function (i) { w = w.then(function () { return retry(function () { return c.doc(k + '~' + i).set({ c: v.slice(i * CH, (i + 1) * CH) }); }); }); })(i);
    for (var j = n; j < old; j++) (function (j) { w = w.then(function () { return retry(function () { return c.doc(k + '~' + j).delete(); }); }); })(j);
    return w.then(function () { return retry(function () { return c.doc(k).set({ t: Date.now(), n: n, c: v.slice(0, CH) }); }); }).then(function () { (SY.parts = SY.parts || {})[k] = n; });
  }
  function syPush() {
    if (!SY.db || SY.busy) { if (SY.db) { clearTimeout(SY.timer); SY.timer = setTimeout(syPush, 1500); } return Promise.resolve(); }
    var keys = Object.keys(SY.dirty); if (!keys.length) { if (SY.state === 'saving') syStatus('ok'); return Promise.resolve(); }
    SY.busy = true; syStatus('saving');
    var chain = Promise.resolve();
    keys.forEach(function (k) {
      chain = chain.then(function () {
        var L = raw(k) || '';
        return readKey(k).then(function (R) {
          var B = SY.bv[k], out = L;
          if (R != null && R !== L && R !== B) out = B == null ? (syMerge(L, R) || L) : (syMerge3(B, L, R) || L); // the online copy changed elsewhere too: combine both
          return (R === out ? Promise.resolve() : writeKey(k, out)).then(function () {
            if ((raw(k) || '') === L) delete SY.dirty[k];
            if (out === L) { SY.bv[k] = L; } else { SY.pendingData = (SY.pendingData || []).filter(function (x) { return x.k !== k; }).concat([{ k: k, v: out, t: Date.now(), merged: true }]); }
            bvSave();
          });
        });
      });
    });
    return chain.then(function () {
      SY.busy = false; SY.last = Date.now(); syMeta(); syStatus(Object.keys(SY.dirty).length ? 'saving' : 'ok', '');
      if (SY.pendingData && SY.pendingData.length) { if (SY.starting && syCanReload()) { syApply(SY.pendingData); return; } syBanner(); }
      if (Object.keys(SY.dirty).length) { clearTimeout(SY.timer); SY.timer = setTimeout(syPush, 1500); }
    }).catch(function (e) {
        SY.busy = false; var code = e && e.code;
        if (code === 'quota_exceeded') { syStatus('error', 'Online storage is full. Your data is still saved on this device.'); return; }
        if (code === 'revoked' || code === 'not_granted' || code === 'capability_disabled' || code === 'capability_removed') { SY.db = null; syStatus('local', 'Saving online is not available in this view. Your data is saved on this device.'); return; }
        if (code === 'invalid_argument') { syStatus('error', 'Your account cannot save data to this app. Ask its owner for Contributor access. Your data is saved on this device.'); return; }
        syStatus('error', 'Could not reach the online save. Trying again shortly. Your data is saved on this device.'); clearTimeout(SY.timer); SY.timer = setTimeout(syPush, 20000);
      });
  }
  function syCanReload() { var recent = 0; try { recent = +(sessionStorage.getItem('sync.reload') || 0); } catch (e) {} if (Date.now() - recent < 60000) return false; try { sessionStorage.setItem('sync.reload', String(Date.now())); } catch (e) {} return true; }
  function syPull(atStart) {
    if (!SY.db) return Promise.resolve();
    SY.starting = !!atStart;
    var done = false, timer = setTimeout(function () { if (!done) syStatus('error', 'The online save is taking a while to answer. Your data is saved on this device.'); }, 10000);
    return retry(function () { return col().get(); }).then(function (snap) {
      done = true; clearTimeout(timer);
      var R = {}, P = {};
      snap.docs.forEach(function (d) { var b = d.data() || {}, id = d.id, m = /^(.*)~(\d+)$/.exec(id); if (m) (P[m[1]] = P[m[1]] || {})[+m[2]] = b.c || ''; else R[id] = b; });
      var apply = [];
      SYNC_KEYS.forEach(function (k) {
        var r = R[k], L = raw(k) || '', B = SY.bv[k];
        if (!r) { if (L) SY.dirty[k] = 1; return; } // never uploaded yet
        var v = r.c || ''; for (var i = 1; i < (r.n || 1); i++) v += (P[k] && P[k][i]) || '';
        (SY.parts = SY.parts || {})[k] = r.n || 1;
        if (v === L) { SY.bv[k] = v; return; }
        if (!L || (B != null && L === B)) { apply.push({ k: k, v: v, t: r.t || Date.now() }); return; } // only the online copy changed
        SY.dirty[k] = 1; // this device changed it (perhaps both did): the upload step combines them
      });
      bvSave(); SY.last = Date.now(); syMeta();
      if (apply.length) { // at start these are applied together with any merges below, in a single reload
        SY.pendingData = (SY.pendingData || []).filter(function (x) { return !apply.some(function (y) { return y.k === x.k; }); }).concat(apply);
        if (!atStart) syBanner();
      }
      syStatus('ok', '');
      return syPush().then(function () { SY.starting = false; });
    }, function (e) {
      done = true; clearTimeout(timer); SY.starting = false;
      var code = e && e.code;
      if (code === 'not_granted' || code === 'capability_disabled' || code === 'capability_removed' || code === 'revoked') { SY.db = null; syStatus('local', 'Saving online is not available in this view. Your data is saved on this device.'); return; }
      syStatus('error', 'Could not reach the online save. Your data is saved on this device.');
    });
  }
  function syApply(list) { // write newer data and reload; nothing else may save in between
    SY.frozen = true; clearTimeout(SY.timer);
    list.forEach(function (x) { try { if (x.v) localStorage.setItem(x.k, x.v); else localStorage.removeItem(x.k); } catch (e) {} SY.bv[x.k] = x.v; });
    bvSave(); syMeta(); location.reload();
  }
  function syMerge3(b, l, r) { // three-way merge of JSON strings: keeps both sides' additions, edits and removals
    try { var B = JSON.parse(b), Lv = JSON.parse(l), Rv = JSON.parse(r); } catch (e) { return null; }
    var J = JSON.stringify, eq = function (x, y) { return J(x) === J(y); };
    function isO(x) { return x && typeof x === 'object' && !Array.isArray(x); }
    function idArr(a) { return Array.isArray(a) && a.every(function (it) { return it && typeof it === 'object' && it.id != null; }); }
    function m3(bb, ll, rr) {
      if (eq(ll, rr)) return ll; if (eq(bb, ll)) return rr; if (eq(bb, rr)) return ll;
      if (isO(ll) && isO(rr)) { var bo = isO(bb) ? bb : {}, o = {}; Object.keys(ll).concat(Object.keys(rr)).forEach(function (k2) { if (k2 in o) return; var inL = k2 in ll, inR = k2 in rr; if (inL && inR) o[k2] = m3(bo[k2], ll[k2], rr[k2]); else if (inL) { if (!(k2 in bo) || !eq(bo[k2], ll[k2])) o[k2] = ll[k2]; } else { if (!(k2 in bo) || !eq(bo[k2], rr[k2])) o[k2] = rr[k2]; } }); return o; }
      if (idArr(ll) && idArr(rr)) { var bm = {}; (idArr(bb) ? bb : []).forEach(function (it) { bm[it.id] = it; }); var lm = {}, rm = {}, ord = []; ll.forEach(function (it) { lm[it.id] = it; ord.push(it.id); }); rr.forEach(function (it) { rm[it.id] = it; if (!(it.id in lm)) ord.push(it.id); }); var out = []; ord.forEach(function (id) { var x = m3(bm[id], lm[id], rm[id]); if (lm[id] && rm[id]) out.push(x); else if (lm[id]) { if (!bm[id] || !eq(bm[id], lm[id])) out.push(lm[id]); } else { if (!bm[id] || !eq(bm[id], rm[id])) out.push(rm[id]); } }); return out; }
      if (Array.isArray(ll) && Array.isArray(rr)) { var bs = {}; (Array.isArray(bb) ? bb : []).forEach(function (it) { bs[J(it)] = 1; }); var ls = {}, rs = {}; ll.forEach(function (it) { ls[J(it)] = 1; }); rr.forEach(function (it) { rs[J(it)] = 1; }); var out2 = [], seen = {}; ll.concat(rr).forEach(function (it) { var s2 = J(it); if (seen[s2]) return; seen[s2] = 1; var gone = bs[s2] && (!ls[s2] || !rs[s2]); if (!gone) out2.push(it); }); return out2; }
      return ll; // the same single value changed on both devices: keep this device's
    }
    return J(m3(B, Lv, Rv));
  }
  function syMerge(a, b) { // local a, remote b (JSON strings). Objects merge key by key (remote wins a clash), arrays combine.
    try { var A = JSON.parse(a), B = JSON.parse(b); } catch (e) { return null; }
    function m(x, y) {
      if (Array.isArray(x) && Array.isArray(y) && x.concat(y).every(function (it) { return it && typeof it === 'object' && it.id != null; })) { var byId = {}, ord = []; x.concat(y).forEach(function (it) { if (!(it.id in byId)) ord.push(it.id); byId[it.id] = it.id in byId ? m(byId[it.id], it) : it; }); return ord.map(function (id) { return byId[id]; }); }
      if (Array.isArray(x) && Array.isArray(y)) { var seen = {}, out = []; y.concat(x).forEach(function (it) { var s2 = JSON.stringify(it); if (!seen[s2]) { seen[s2] = 1; out.push(it); } }); return out; }
      if (x && y && typeof x === 'object' && typeof y === 'object' && !Array.isArray(x) && !Array.isArray(y)) { var o = {}; Object.keys(x).forEach(function (k2) { o[k2] = x[k2]; }); Object.keys(y).forEach(function (k2) { o[k2] = k2 in x ? m(x[k2], y[k2]) : y[k2]; }); return o; }
      return y;
    }
    return JSON.stringify(m(A, B));
  }
  function syBanner() {
    if (document.getElementById('synbn')) return;
    var b = document.createElement('div'); b.id = 'synbn'; b.setAttribute('role', 'status');
    b.innerHTML = '<span>Newer data from your other device is ready.</span><button class="pri" data-act="syncreload">Load it</button><button data-act="syncclose" aria-label="Later">Later</button>';
    document.body.appendChild(b);
  }
  function syStart() {
    var cl = window.claude;
    if (!cl || typeof cl.use !== 'function') { syStatus('local', 'This copy of the app is not signed in to claude.ai, so it saves on this device only.'); return; }
    Promise.all([cl.use('db'), cl.use('user')]).then(function (r) {
      var db = r[0], user = r[1];
      if (!db || !user) { syStatus('local', 'Saving online needs you to be signed in to claude.ai. Your data is saved on this device.'); return; }
      return user.id().then(function (id) {
        if (!id) { syStatus('local', 'Saving online needs you to be signed in to claude.ai. Your data is saved on this device.'); return; }
        SY.db = db; SY.uid = id; return syPull(true);
      });
    }).catch(function () { syStatus('local', 'Saving online is not available right now. Your data is saved on this device.'); });
  }
  setTimeout(syStart, 0);
  document.addEventListener('visibilitychange', function () { if (document.visibilityState === 'visible' && SY.db && !SY.busy) syPull(false); else if (document.visibilityState === 'hidden' && SY.db) { clearTimeout(SY.timer); syPush(); } });
  window.__sync = SY;

  var actS = act;
  act = function (a, d) {
    if (a === 'syncreload') { if (SY.pendingData && SY.pendingData.length) syApply(SY.pendingData); else location.reload(); return; }
    if (a === 'syncclose') { var b = document.getElementById('synbn'); if (b) b.remove(); return; }
    if (a === 'syncnow') { if (SY.db) { syStatus('saving'); syPull(false).then(function () { toast(SY.state === 'ok' ? 'Everything is saved online' : 'Not saved online yet'); var m = document.getElementById('syninfo'); if (m) m.remove(); }); } else toast('Saving online is not available here'); return; }
    if (a === 'syncinfo') {
      var old = document.getElementById('syninfo'); if (old) { old.remove(); return; }
      var m = document.createElement('div'); m.id = 'syninfo'; m.setAttribute('role', 'dialog'); m.setAttribute('aria-label', 'Saving online');
      var when = SY.last ? new Date(SY.last).toLocaleString(undefined, { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }) : 'not yet';
      m.innerHTML = '<div class="box"><div class="row" style="justify-content:space-between"><b style="font-size:18px">Saving online</b><button class="ib" data-act="syncinfo" aria-label="Close">' + ic('x', 16) + '</button></div>' +
        (SY.db ? '<p>Your highlights, notes, saved verses, journal, reading plans, settings and Kingdom Games progress are saved to your claude.ai account and appear on any device where you open this app signed in.</p><p class="dim small">Stored privately for you: other people who open this app cannot see it, and neither can its owner. Last saved: ' + esc(when) + '.</p>' + (SY.err ? '<p class="small" style="color:#C0504D">' + esc(SY.err) + '</p>' : '') + '<div class="row"><button class="pri" data-act="syncnow">Sync now</button></div>'
          : '<p>' + esc(SY.err || 'Your data is saved on this device.') + '</p><p class="dim small">Imported Bibles stay on each device because of their size.</p>') + '</div>';
      document.body.appendChild(m); return;
    }
    return actS(a, d);
  };

  /* ============ 15. Sermon & Study Workshop (Parts 1-17 of the user's directive) ============ */
  // A structured preparation environment, not a blank editor. Every field autosaves (localStorage 'sermons',
  // synced online through section 14). Key words come from the app's own Strong's data; references are verified
  // against the Bible text; nothing is generated for the preacher.
  SYNC_KEYS.push('sermons', 'illus');
  var SM = store.g('sermons', null) || { list: [] }, ILL = store.g('illus', null) || { list: [] };
  var smT = 0, smsv = function () { clearTimeout(smT); smT = setTimeout(function () { store.s('sermons', SM); }, 400); }, illsv = function () { store.s('illus', ILL); };
  var SW = Object.assign({ open: null, stage: 'found', q: '', st: 'all', newk: null, cf: null, sel: null, cmp: [], xr: null, kwc: null, pt: 0 }, store.g('smv', {}));
  var swsv = function () { store.s('smv', { open: SW.open, stage: SW.stage }); };
  var SEEDS = [['passage', 'A Scripture passage', 'e.g. John 15:1-17'], ['topic', 'A topic', 'e.g. Forgiveness'], ['character', 'A biblical character', 'e.g. Joseph'], ['doctrine', 'A doctrine', 'e.g. Justification by faith'], ['event', 'A biblical event', 'e.g. The crossing of the Red Sea'], ['question', 'A question', 'e.g. Why does God allow suffering?'], ['burden', 'A spiritual burden', 'What is on your heart?'], ['word', 'A word or theme', 'e.g. Abide']];
  var TYPES = ['Expository', 'Topical', 'Doctrinal', 'Evangelistic', 'Devotional', 'Prophetic exhortation', 'Character study', 'Biblical narrative', 'Teaching series'];
  var CATS = ['Faith', 'Salvation', 'Repentance', 'Holiness', 'Prayer', 'Christ', 'The Kingdom of God', 'The Holy Spirit', 'Spiritual warfare', 'Discipleship', 'Wisdom', 'Love', 'Grace', 'Sin', 'Obedience', 'Eternity', 'Other'];
  var STATUS = ['Idea', 'Studying', 'Outlining', 'Developing', 'Ready to preach', 'Preached'];
  var EVID = [['explicit', 'Explicit biblical statement'], ['strong', 'Strong textual conclusion'], ['interp', 'Interpretation'], ['personal', 'Personal observation'], ['app', 'Application']];
  var SRC = [['bible', 'The Bible says'], ['hist', 'Verifiable history'], ['infer', 'Inference']];
  var IXTYPES = ['Biblical illustration', 'Biblical character', 'Nature', 'Everyday life', 'Historical', 'Personal experience', 'Analogy or comparison'];
  var STRUCT = { two: ['2-point sermon', ['Point 1', 'Point 2']], three: ['3-point sermon', ['Point 1', 'Point 2', 'Point 3']], four: ['4-point sermon', ['Point 1', 'Point 2', 'Point 3', 'Point 4']], verse: ['Verse-by-verse exposition', null], narr: ['Narrative progression', ['The setting', 'The tension', 'The turning point', 'The resolution']], ptr: ['Problem → Truth → Response', ['The problem', 'The truth', 'The response']], qaa: ['Question → Answer → Application', ['The question', 'The answer', 'The application']], dep: ['Doctrine → Explanation → Practice', ['The doctrine', 'The explanation', 'The practice']], custom: ['Custom structure', ['Point 1']] };
  var PFIELDS = [['title', 'Point title', 'A short, memorable statement'], ['ref', 'Scripture', 'The exact supporting passage, e.g. John 15:4-5'], ['says', 'What the text says', 'Explain the passage accurately'], ['means', 'What it means', 'Develop the interpretation'], ['rev', 'The revelation', 'The deeper biblical truth being communicated'], ['evid', 'The evidence', 'Additional Scripture where necessary'], ['jesus', 'The Jesus connection', 'Where appropriate: Christ and his teaching'], ['paul', 'The Paul connection', 'Where appropriate: apostolic doctrine or reasoning'], ['ill', 'Illustration', 'A real-life illustration, biblical example, analogy or picture'], ['heart', 'Heart examination', 'What must the listener confront?'], ['app', 'Application', 'What should the listener do?'], ['mem', 'Memorable statement', 'A short statement that captures the point'], ['trans', 'Transition', 'A natural connection to the next point'], ['big', 'How this supports the big idea', 'Every point serves the central message']];
  // stage definitions: [id, number, title, blocks]. Block: [kind, key, label, help, extra]
  var Q = function (key, label, help, src) { return ['ta', key, label, help, src ? { src: 1 } : null]; };
  var STAGES = [
    ['found', '01', 'Sermon foundation', 'Set up the message and write what is on your heart.'],
    ['text', '02', 'The text', 'Establish the Scripture before anything else.'],
    ['ctx', '03', 'Understand the context', 'Author, audience, history, book and literary setting.'],
    ['obs', '04', 'What does the text actually say?', 'Observe carefully before interpreting.'],
    ['int', '05', 'What does the text mean?', 'Interpretation, and Scripture interpreting Scripture.'],
    ['theo', '06', 'What truth is being revealed?', 'The theological foundation.'],
    ['christ', '07', 'How does this reveal Christ?', 'A Christ-centred lens, kept honest to the text.'],
    ['aud', '08', 'Who am I preaching to?', 'The heart and spiritual condition of the hearers.'],
    ['big', '09', 'The big idea', 'One clear central message.'],
    ['outline', '10', 'Build the sermon outline', 'Choose a structure and shape the points.'],
    ['jesus', '11', 'Teach with clarity, depth and revelation', 'The teaching patterns of Jesus.'],
    ['paul', '12', 'Build sound doctrinal reasoning', 'The teaching patterns of Paul.'],
    ['mode', '13', 'Jesus + Paul sermon builder', 'Choose how to combine both approaches.'],
    ['intro', '14', 'Build the introduction', 'Capture attention and lead to the text.'],
    ['points', '15', 'Develop every point', 'Full development of each sermon point.'],
    ['illus', '16', 'Illustration builder', 'Your library of illustrations and imagery.'],
    ['review', '17', 'Review the sermon', 'The whole message on one page.']
  ];
  var BLOCKS = {
    ctx: [['h', 'A. Author'], Q('a_who', 'Who wrote the passage?', '', 1), Q('a_known', 'What can be established about the author?', '', 1), Q('a_rel', 'What is the author\'s relationship to the audience?', '', 1),
      ['h', 'B. Audience'], Q('b_who', 'Who was the original audience?', '', 1), Q('b_exp', 'What were they experiencing?', '', 1), Q('b_und', 'What did they understand?', '', 1),
      ['h', 'C. Historical background'], Q('c_hap', 'What was happening historically?', '', 1), Q('c_circ', 'What circumstances surrounded the text?', '', 1), Q('c_ver', 'What historical details are verifiable?', 'Only facts you can point to a source for.', 1),
      ['h', 'D. Book context'], ['bookctx'], Q('d_purp', 'What is the purpose of the biblical book?', '', 1), Q('d_fit', 'Where does this passage fit?', '', 1), Q('d_before', 'What happens before it?', '', 1), Q('d_after', 'What happens after it?', '', 1),
      ['h', 'E. Literary context'], ['chips1', 'genre', 'What kind of writing is it?', '', ['Narrative', 'Poetry', 'Prophecy', 'Wisdom', 'Epistle', 'Parable', 'Apocalyptic literature', 'Law', 'Gospel']],
      ['h', 'F. Original situation'], Q('f_prob', 'What problem was being addressed?', '', 1), Q('f_q', 'What question was being answered?', '', 1), Q('f_circ', 'What circumstances prompted the message?', '', 1),
      ['h', 'G. Contextual summary'], Q('g_sum', 'Summarise the context in your own words', '')],
    obs: [['note', 'Observe first. Write only what the text itself says; interpretation comes in the next stage.'],
      Q('o_speak', 'Who is speaking?'), Q('o_to', 'Who is being spoken to?'), Q('o_hap', 'What is happening?'), Q('o_cmd', 'What commands are given?'), Q('o_prom', 'What promises are made?'), Q('o_warn', 'What warnings are given?'), ['repeats'], Q('o_rep', 'What words are repeated?'), Q('o_con', 'What contrasts are present?'), Q('o_cond', 'What conditions are present? (if… then…)'), Q('o_cause', 'What cause-and-effect relationships appear?'), Q('o_q', 'What questions are asked?'), Q('o_a', 'What answers are given?'), Q('o_chg', 'What changes occur?'), Q('o_emph', 'What is emphasised?'), Q('o_surp', 'What surprises me?'), Q('o_over', 'What is easily overlooked?'), Q('o_god', 'What does the passage explicitly reveal about God?'), Q('o_man', 'What does the passage reveal about humanity?'),
      ['h', 'Key words & phrases'], ['keywords']],
    int: [Q('i_intent', 'What did the author intend to communicate?'), Q('i_aud', 'What did the original audience understand?'), Q('i_central', 'What is the central truth?'), Q('i_rev', 'What does the passage reveal?'), Q('i_not', 'What does the passage not mean?'), Q('i_avoid', 'What misunderstandings must be avoided?'), Q('i_theo', 'What theological truths are present?'), Q('i_sur', 'How do the surrounding verses clarify it?'), Q('i_other', 'How do other Scriptures confirm, explain or expand it?'),
      ['h', 'Scripture interprets Scripture'], ['note', 'Gather passages that genuinely bear on this text. Each reference is checked against the Bible; mark how strong the link is. Don\'t force a connection where none exists.'], ['xrefs']],
    theo: [['themes'], ['h', 'The central theological truth'], Q('t_central', 'What is the foundational biblical truth that the message is built upon?'), ['h', 'The truth that must not be compromised'], Q('t_keep', 'What essential truth must remain intact throughout the sermon?')],
    christ: [['note', 'Where the connection is direct, establish it. Where it is indirect, explain the biblical reasoning. Where no strong connection exists, say so rather than invent one.'],
      ['chips1', 'c_link', 'How does this passage connect to Christ?', '', ['Directly: the passage speaks of him', 'Indirectly: a principle fulfilled in him', 'Through the wider gospel story', 'No strong connection in this text']],
      Q('c_rel', 'How does this passage relate to Jesus Christ?'), Q('c_mention', 'Does the passage directly mention him?'), Q('c_principle', 'Does it reveal a principle fulfilled in Christ? Explain the biblical reasoning.'), Q('c_gospel', 'Is there a legitimate connection to the gospel?'), Q('c_help', 'How does this passage help us understand Christ?'), Q('c_demand', 'What does Christ demand of the hearer?'),
      ['h', 'Aspects of Christ in view'], ['aspects']],
    aud: [['chipsN', 'a_prof', 'Who will be listening?', 'Choose all that apply. Do not assume every audience has the same spiritual condition.', ['Believers', 'New believers', 'Unbelievers', 'Religious but spiritually disconnected', 'Discouraged people', 'People suffering', 'People living in disobedience', 'People seeking direction', 'Young people', 'Families', 'Leaders']],
      Q('a_desc', 'Describe this audience in your own words'), Q('a_bel', 'What do people believe?'), Q('a_mis', 'What do they misunderstand?'), Q('a_str', 'What are they struggling with?'), Q('a_fear', 'What are they afraid of?'), Q('a_trust', 'What are they trusting?'), Q('a_avoid', 'What are they avoiding?'), Q('a_sin', 'What sins may need confronting?'), Q('a_wound', 'What wounds need biblical comfort?'), Q('a_negl', 'What truths have they neglected?'), Q('a_chg', 'What needs to change?'), Q('a_call', 'What is God calling them to?')],
    big: [['note', 'Everything in the sermon should serve this one message. If a point does not support it, it belongs in another sermon.'], Q('b_subj', 'Text subject', 'What is the passage primarily about?'), Q('b_truth', 'Central truth', 'What is the one truth the passage is communicating?'), Q('b_idea', 'Sermon big idea', 'Summarise the entire sermon in one memorable sentence.'), Q('b_purp', 'Sermon purpose', 'What should the audience understand, believe, change or do?'), Q('b_burden', 'The burden', 'What is the urgency of this message?'), Q('b_one', 'The message in one sentence', 'If people remember only one thing, what must it be?')],
    jesus: [['note', 'An optional lens. Use what serves the text; leave the rest blank. Don\'t force a parable or contrast into every sermon.'], Q('j_q', 'A. The opening question', 'Can the sermon begin with a question that exposes a spiritual issue?'), Q('j_pic', 'B. The picture', 'An understandable picture, comparison, object or biblical image'), Q('j_par', 'C. The parable or illustration', 'Would a simple story or comparison clarify the truth?'), Q('j_heart', 'D. The heart', 'What does this truth reveal about the heart?'), Q('j_rev', 'E. The revelation', 'What profound truth is hidden in plain sight in the passage?'),
      ['chipsN', 'j_contr', 'F. The contrast', 'Only where the text supports it', ['Flesh and Spirit', 'Faith and fear', 'Truth and deception', 'Pride and humility', 'Appearance and reality', 'Hearing and obeying', 'Religion and relationship']], Q('j_contrn', 'Describe the contrast'), Q('j_mem', 'G. The memorable statement', 'Short, memorable and accurate to the text'), Q('j_conv', 'H. The conviction', 'What should this truth cause the listener to confront?'), Q('j_resp', 'I. The response', 'What is the listener being called to do?')],
    paul: [['note', 'An optional lens. Every argument must rest on Scripture; don\'t build a conclusion the text does not support.'], Q('p_found', 'A. The foundation', 'What is the foundational biblical truth?'), ['refsfield', 'p_evid', 'B. The evidence', 'Which Scriptures establish this truth? One reference per line; each is checked.'], Q('p_reason', 'C. The reasoning', 'How do the Scriptures lead to this conclusion?'), Q('p_expl', 'D. The explanation', 'Explain the truth progressively and logically'), Q('p_obj', 'E. The objection', 'What might the listener misunderstand, question or resist?'), Q('p_corr', 'F. The correction', 'What does Scripture correct?'), Q('p_impl', 'G. The implication', 'If this truth is real, what does it mean for our lives?'), Q('p_prac', 'H. The practice', 'How should believers live in light of this truth?'), Q('p_exh', 'I. The exhortation', 'What should the hearer be urged to do?'), Q('p_cons', 'J. The consequence', 'Biblical consequences of obedience or disobedience, where the text establishes them')],
    intro: [['chips1', 'n_kind', 'How will you open?', '', ['A question', 'A problem', 'A surprising truth', 'A biblical situation', 'A personal observation', 'A contrast', 'A short story', 'A statement of urgency', 'A real-life experience']], Q('n_hook', 'The opening', 'Capture attention'), Q('n_tension', 'The central tension', 'What problem or question does the sermon resolve?'), Q('n_conn', 'Connect to the audience', 'Why does this matter to these people?'), Q('n_why', 'Why the message matters', ''), Q('n_lead', 'Lead into the Scripture', 'How does the introduction arrive at the main text?'), ['intrometer']]
  };
  var SMTH = ['The doctrine', 'The biblical truth', 'The nature of God', 'The nature of Christ', 'The work of the Holy Spirit', 'The nature of humanity', 'Sin', 'Grace', 'Faith', 'Salvation', 'The Kingdom', 'Covenant', 'Judgment', 'Redemption', 'Obedience'];
  var ASPECTS = ['Christ\'s identity', 'Christ\'s teachings', 'Christ\'s work', 'Christ\'s sacrifice', 'Christ\'s resurrection', 'Christ\'s authority', 'Christ\'s Kingdom', 'Christ\'s fulfilment of Scripture', 'Christ\'s relationship to the passage'];
  var COMBINED = [['An understandable, powerful opening', 'intro'], ['A question or spiritual tension', 'intro'], ['The biblical text', 'text'], ['Context', 'ctx'], ['Careful observation', 'obs'], ['Deep explanation', 'int'], ['Sound doctrinal foundation', 'theo'], ['Biblical reasoning', 'paul'], ['A revelation or memorable truth', 'jesus'], ['An illustration where appropriate', 'illus'], ['Heart examination', 'jesus'], ['Practical application', 'points'], ['Conviction', 'jesus'], ['A call to respond', 'jesus']];

  /* ---- helpers ---- */
  function cur2() { return SM.list.filter(function (s) { return s.id === SW.open; })[0] || null; }
  function smF(s, k) { return (s.f && s.f[k]) || ''; }
  function normRef(r) { // free text -> canonical "Book C", "Book C-C2", "Book C:V-V2" or null
    r = (r || '').trim().replace(/[–—]/g, '-'); if (!r) return null;
    var p = parse(r); if (!p) return null;
    var cr = /\s(\d+)\s*-\s*(\d+)$/.exec(r), vr = /:(\d+)\s*-\s*(\d+)$/.exec(r), out;
    if (/:/.test(r)) out = p.b + ' ' + p.c + ':' + p.v + (vr ? '-' + vr[2] : '');
    else if (cr) out = p.b + ' ' + cr[1] + '-' + cr[2]; else out = p.b + ' ' + p.c;
    return runits(out) ? out : null;
  }
  function passageVerses(ref, ver) { // -> [{b,c,v,t}]
    var us = runits(ref) || [], o = [];
    us.forEach(function (u) { for (var v = u.v1; v <= u.v2; v++) { var t = gv(ver, u.b, u.c, v); if (!t && ver !== 'KJV') t = gv('KJV', u.b, u.c, v); o.push({ b: u.b, c: u.c, v: v, t: t ? plain(t).replace(/\s+/g, ' ').trim() : '' }); } });
    return o;
  }
  function stageFill(s, id) { // [filled, total] for progress dots
    var f = s.f || {}, n = 0, t = 0;
    var cnt = function (k) { t++; if (f[k] && String(f[k]).trim()) n++; };
    if (id === 'found') { ['title', 'main', 'type', 'cat', 'burden'].forEach(cnt); }
    else if (id === 'text') { t = 2; if (normRef(f.main)) n++; if ((s.obsv || '').trim() || Object.keys(s.vn || {}).length) n++; }
    else if (BLOCKS[id]) BLOCKS[id].forEach(function (b) { if (b[0] === 'ta' || b[0] === 'chips1' || b[0] === 'chipsN' || b[0] === 'refsfield') cnt(b[1]); });
    else if (id === 'outline') { t = 1; n = (s.points || []).length ? 1 : 0; }
    else if (id === 'points') { (s.points || []).forEach(function (p) { PFIELDS.forEach(function (x) { t++; if (p[x[0]] && String(p[x[0]]).trim()) n++; }); }); }
    else if (id === 'mode') { t = 1; n = f.mode ? 1 : 0; }
    else if (id === 'illus') { t = 1; n = (s.ills || []).length ? 1 : 0; }
    else if (id === 'review') { t = 1; n = f.status === 'Ready to preach' || f.status === 'Preached' ? 1 : 0; }
    return [n, t];
  }
  function overall(s) { var n = 0, t = 0; STAGES.forEach(function (st) { var x = stageFill(s, st[0]); if (x[1]) { n += Math.min(1, x[0] / x[1]); t++; } }); return Math.round(n / t * 100); }
  function needsText(id) { return ['found', 'text', 'illus'].indexOf(id) < 0; }
  function esca(s) { return esc(s || '').replace(/"/g, '&quot;'); }

  /* ---- field renderers ---- */
  function srcTag(s, k) { var v = (s.src || {})[k] || ''; return '<span class="smsrc" role="group" aria-label="Source of this answer">' + SRC.map(function (x) { return '<button class="' + (v === x[0] ? 'on' : '') + '" data-act="smsrc" data-k="' + k + '" data-v="' + x[0] + '">' + x[1] + '</button>'; }).join('') + '</span>'; }
  function taField(s, k, label, help, src) { return '<label class="smf"><span class="sml">' + esc(label) + (src ? srcTag(s, k) : '') + '</span>' + (help ? '<small>' + esc(help) + '</small>' : '') + '<textarea data-sf="' + k + '" rows="' + (smF(s, k).length > 160 ? 5 : 2) + '">' + esc(smF(s, k)) + '</textarea></label>'; }
  function smChips(s, k, label, help, opts, multi) {
    var v = smF(s, k), on = multi ? (v ? v.split('|') : []) : [v];
    return '<div class="smf"><span class="sml">' + esc(label) + '</span>' + (help ? '<small>' + esc(help) + '</small>' : '') + '<div class="smchips">' + opts.map(function (o) { return '<button class="chip ' + (on.indexOf(o) >= 0 ? 'on' : '') + '" data-act="smchip" data-k="' + k + '" data-v="' + esca(o) + '" data-m="' + (multi ? 1 : '') + '" aria-pressed="' + (on.indexOf(o) >= 0) + '">' + esc(o) + '</button>'; }).join('') + '</div></div>';
  }
  function refList(lines) { return (lines || '').split('\n').map(function (l) { return l.trim(); }).filter(Boolean).map(function (l) { var n = normRef(l); return '<span class="smref ' + (n ? 'ok' : 'bad') + '">' + (n ? '<a data-act="smgo" data-r="' + esca(n) + '">' + rlabel(n) + '</a>' : esc(l) + ' — not found') + '</span>'; }).join(''); }
  function blockHtml(s, b) {
    var k = b[0];
    if (k === 'h') return '<h4 class="smh">' + esc(b[1]) + '</h4>';
    if (k === 'note') return '<p class="smnote">' + esc(b[1]) + '</p>';
    if (k === 'ta') return taField(s, b[1], b[2], b[3], b[4] && b[4].src);
    if (k === 'chips1') return smChips(s, b[1], b[2], b[3], b[4], false);
    if (k === 'chipsN') return smChips(s, b[1], b[2], b[3], b[4], true);
    if (k === 'refsfield') return '<label class="smf"><span class="sml">' + esc(b[2]) + '</span><small>' + esc(b[3]) + '</small><textarea data-sf="' + b[1] + '" data-refs="1" rows="3">' + esc(smF(s, b[1])) + '</textarea><span class="smrefs" id="rf-' + b[1] + '">' + refList(smF(s, b[1])) + '</span></label>';
    if (k === 'bookctx') return bookCtx(s);
    if (k === 'repeats') return repeats(s);
    if (k === 'keywords') return keywords(s);
    if (k === 'xrefs') return xrefs(s);
    if (k === 'themes') return themes(s, 'th', 'Which truths are in view?', 'Only include what is relevant to the passage.', SMTH);
    if (k === 'aspects') return themes(s, 'asp', '', 'Tick only what the text justifies, and say how.', ASPECTS);
    if (k === 'intrometer') { var w = ['n_hook', 'n_tension', 'n_conn', 'n_why', 'n_lead'].map(function (x) { return smF(s, x); }).join(' ').split(/\s+/).filter(Boolean).length; return '<p class="smmeter ' + (w > 350 ? 'warn' : '') + '">' + w + ' words · ' + (w > 350 ? 'This introduction may be long. Keep it to what captures attention and leads to the text.' : 'About ' + Math.max(1, Math.round(w / 130)) + ' minute' + (w > 195 ? 's' : '') + ' spoken. Don\'t reveal every point yet.') + '</p><ul class="smcheck"><li>Captures attention</li><li>Introduces the central tension</li><li>Connects the audience to the subject</li><li>Establishes why the message matters</li><li>Leads naturally to the main Scripture</li></ul>'; }
    return '';
  }
  function themes(s, key, label, help, list) {
    var on = s[key] || {};
    return '<div class="smf">' + (label ? '<span class="sml">' + esc(label) + '</span>' : '') + '<small>' + esc(help) + '</small><div class="smchips">' + list.map(function (t) { return '<button class="chip ' + (on[t] != null ? 'on' : '') + '" data-act="smtheme" data-g="' + key + '" data-v="' + esca(t) + '">' + esc(t) + '</button>'; }).join('') + '</div>' +
      Object.keys(on).map(function (t) { return '<label class="smf sub"><span class="sml">' + esc(t) + '</span><textarea data-sg="' + key + '" data-t="' + esca(t) + '" rows="2">' + esc(on[t]) + '</textarea></label>'; }).join('') + '</div>';
  }
  function bookCtx(s) {
    var r = normRef(smF(s, 'main')); if (!r) return '';
    var u = (runits(r) || [])[0], bi = BOOKS.indexOf(u.b), grp = (typeof CLS !== 'undefined' && CLS && (CLS.books.find(function (x) { return x.name === u.b; }) || {}).group) || '', n = Object.keys(KJV[u.b] || {}).length;
    var prev = u.c > 1 ? u.b + ' ' + (u.c - 1) : bi > 0 ? BOOKS[bi - 1] + ' ' + Object.keys(KJV[BOOKS[bi - 1]] || {}).length : null, us = runits(r), last = us[us.length - 1], next = last.c < n ? u.b + ' ' + (last.c + 1) : bi < 65 ? BOOKS[bi + 1] + ' 1' : null;
    return '<div class="smfact"><b>From the Bible itself</b><ul><li>' + esc(u.b) + ' is book ' + (bi + 1) + ' of 66' + (grp ? ', in the ' + esc(grp) : '') + ', with ' + n + ' chapters (' + (bi < 39 ? 'Old' : 'New') + ' Testament).</li><li>Your passage is in chapter ' + u.c + (last.c !== u.c ? '–' + last.c : '') + ' of ' + n + '.</li>' + (prev ? '<li>Before it: <a data-act="smgo" data-r="' + esca(prev) + '">' + rlabel(prev) + '</a></li>' : '') + (next ? '<li>After it: <a data-act="smgo" data-r="' + esca(next) + '">' + rlabel(next) + '</a></li>' : '') + '</ul><small>These facts are drawn from the Bible text. Anything about authorship or history that is not in the text is your research: mark it as history or inference.</small></div>';
  }
  function repeats(s) {
    var r = normRef(smF(s, 'main')); if (!r) return '';
    var vs = passageVerses(r, 'KJV'), c = {};
    vs.forEach(function (x) { x.t.toLowerCase().split(/[^a-z']+/).forEach(function (w) { if (w.length < 4 || STOPE[w]) return; c[w] = (c[w] || 0) + 1; }); });
    var L = Object.keys(c).filter(function (w) { return c[w] > 1; }).sort(function (a, b) { return c[b] - c[a]; }).slice(0, 14);
    return L.length ? '<div class="smfact"><b>Repeated in this passage (KJV)</b><div class="smchips">' + L.map(function (w) { return '<span class="chip">' + esc(w) + ' ×' + c[w] + '</span>'; }).join('') + '</div></div>' : '';
  }
  function kwCandidates(s) {
    var r = normRef(smF(s, 'main')); if (!r) return [];
    var us = runits(r) || [], seen = {}, out = [];
    us.forEach(function (u) { for (var v = u.v1; v <= u.v2; v++) { var t = (KJV[u.b] && KJV[u.b][u.c] && KJV[u.b][u.c][v - 1]) || ''; t.replace(/([^\s{}]+)((?:\{[HG]\d+\})+)/g, function (m, w, tags) { (tags.match(/[HG]\d+/g) || []).forEach(function (k) { var e = LEX[k]; if (!e || COMMON[k] || SKIPPOS.test(e[6] || '')) return; if (seen[k]) { seen[k].n++; return; } seen[k] = { k: k, w: w.replace(/[^\w'-]/g, ''), n: 1, v: u.b + ' ' + u.c + ':' + v }; out.push(seen[k]); }); return m; }); } });
    return out.sort(function (a, b) { return b.n - a.n; });
  }
  function keywords(s) {
    var kw = s.kw || [], cands = SW.kwc === s.id ? kwCandidates(s).filter(function (c) { return !kw.some(function (x) { return x.strong === c.k; }); }).slice(0, 24) : null;
    return '<div class="smkw">' + (kw.length ? kw.map(function (x, i) {
      var e = x.strong && LEX[x.strong], H = x.strong && x.strong[0] === 'H';
      return '<div class="smkwr"><div class="smkwh"><b>' + esc(x.word || '') + '</b>' + (x.strong ? '<span class="' + (H ? 'hebw' : 'grk') + '">' + esc((e && e[0]) || (H && HEBL[x.strong]) || '') + '</span><i>' + esc(e ? e[1] : '') + '</i><a data-act="lab" data-k="' + x.strong + '">' + x.strong + '</a>' : '<i>No Strong\'s number</i>') + '<button class="ib" data-act="smkwdel" data-i="' + i + '" aria-label="Remove ' + esca(x.word) + '">' + ic('x', 14) + '</button></div>' +
        (e ? '<p class="smdict"><b>Dictionary range</b> (all possible senses, not all apply here): ' + esc((e[7] || '') + (e[4] ? ' · KJV renders: ' + e[4] : '')) + '</p>' : '') +
        '<div class="smkwg"><label>Word<input data-kw="' + i + '" data-f="word" value="' + esca(x.word) + '"></label><label>Meaning in this context<input data-kw="' + i + '" data-f="meaning" value="' + esca(x.meaning) + '" placeholder="What it means here, not every dictionary sense"></label><label>Usage in this passage<input data-kw="' + i + '" data-f="usage" value="' + esca(x.usage) + '"></label><label>Related Scriptures<input data-kw="' + i + '" data-f="rel" value="' + esca(x.rel) + '" placeholder="e.g. John 15:4; 1 John 2:6"></label></div></div>';
    }).join('') : '<p class="dim small">No key words yet.</p>') +
      '<div class="row" style="gap:8px;flex-wrap:wrap"><button data-act="smkwsug">' + ic('spark', 14) + ' Suggest from the original language</button><button data-act="smkwadd">' + ic('plus', 14) + ' Add a word or phrase</button></div>' +
      (cands ? (cands.length ? '<div class="smcands"><small>Words in the passage with a Strong\'s entry (from the KJV tagging). Tap to add.</small>' + cands.map(function (c) { var e = LEX[c.k], H = c.k[0] === 'H'; return '<button class="smcand" data-act="smkwpick" data-k="' + c.k + '" data-w="' + esca(c.w) + '" data-v="' + esca(c.v) + '"><b>' + esc(c.w) + '</b><span class="' + (H ? 'hebw' : 'grk') + '">' + esc((e && e[0]) || (H && HEBL[c.k]) || '') + '</span><small>' + c.k + (c.n > 1 ? ' · ×' + c.n : '') + '</small></button>'; }).join('') + '</div>' : '<p class="dim small">No tagged words found (the dictionary may still be loading).</p>') : '') + '</div>';
  }
  var XCAT = [['par', 'Parallel passages'], ['xref', 'Cross-references'], ['sup', 'Supporting passages'], ['ot', 'Old Testament connections'], ['nt', 'New Testament connections'], ['proph', 'Prophetic connections'], ['jesus', 'Related teachings of Jesus'], ['paul', 'Related teachings of Paul']];
  function xrefs(s) {
    var L = s.refs || [], r = normRef(smF(s, 'main')), sug = [];
    if (r && SW.xr === s.id) { var seen = {}; (runits(r) || []).forEach(function (u) { for (var v = u.v1; v <= u.v2; v++) (XREF[u.b + ' ' + u.c + ':' + v] || []).forEach(function (x) { if (!seen[x]) { seen[x] = 1; sug.push([x, 'Listed cross-reference of ' + u.b + ' ' + u.c + ':' + v]); } }); }); try { var u0 = (runits(r) || [])[0]; related(u0.b, u0.c, u0.v1, 6).forEach(function (o) { var k2 = o.r[0] + ' ' + o.r[1] + ':' + o.r[2]; if (!seen[k2]) { seen[k2] = 1; sug.push([k2, 'Shares Hebrew/Greek words: ' + o.sh.slice(0, 3).map(lab).join(', ')]); } }); } catch (e) {} }
    return '<div class="smx">' + XCAT.map(function (c) {
      var items = L.map(function (x, i) { return [x, i]; }).filter(function (p) { return p[0].cat === c[0]; });
      return '<div class="smxc"><div class="row" style="justify-content:space-between"><b>' + c[1] + ' <span class="dim">' + items.length + '</span></b><button class="ib" data-act="smxadd" data-c="' + c[0] + '" aria-label="Add to ' + c[1] + '">' + ic('plus', 14) + '</button></div>' +
        items.map(function (p) { var x = p[0], i = p[1], n = normRef(x.ref), us = n && runits(n), t = n ? (vtext(us[0].b + ' ' + us[0].c + ':' + us[0].v1) || '') : ''; return '<div class="smxi"><div class="row" style="gap:6px;flex-wrap:nowrap"><input data-xr="' + i + '" data-f="ref" value="' + esca(x.ref) + '" placeholder="Reference, e.g. Isaiah 53:7" aria-label="Reference"><select data-xr="' + i + '" data-f="ev" aria-label="Strength">' + EVID.map(function (e) { return '<option value="' + e[0] + '"' + (x.ev === e[0] ? ' selected' : '') + '>' + e[1] + '</option>'; }).join('') + '</select><button class="ib" data-act="smxdel" data-i="' + i + '" aria-label="Remove">' + ic('x', 14) + '</button></div>' + (x.ref ? (n ? '<a class="smxt" data-act="smgo" data-r="' + esca(n) + '"><b>' + rlabel(n) + '</b> ' + esc(t.slice(0, 140)) + (t.length > 140 ? '…' : '') + '</a>' : '<span class="smbad">Reference not found — check the book, chapter and verse.</span>') : '') + '<input data-xr="' + i + '" data-f="note" value="' + esca(x.note) + '" placeholder="How does it bear on the text?" aria-label="Note"></div>'; }).join('') + '</div>';
    }).join('') + '</div>' + '<div class="row" style="margin-top:10px"><button data-act="smxsug">' + ic('link', 14) + ' Show verifiable connections</button></div>' +
      (sug.length ? '<div class="smcands"><small>From the app\'s cross-reference list and shared original-language words. Read each before adding; tap to add as a cross-reference.</small>' + sug.slice(0, 16).map(function (x) { return '<button class="smcand" data-act="smxpick" data-r="' + esca(x[0]) + '"><b>' + esc(x[0]) + '</b><small>' + esc(x[1]) + '</small></button>'; }).join('') + '</div>' : (SW.xr === s.id ? '<p class="dim small">No listed connections for this passage. Add your own above.</p>' : ''));
  }

  /* ---- stages ---- */
  function foundHtml(s) {
    var sel = function (k, label, opts) { return '<label class="smf half"><span class="sml">' + label + '</span><select data-sf="' + k + '"><option value="">Choose…</option>' + opts.map(function (o) { return '<option' + (smF(s, k) === o ? ' selected' : '') + '>' + esc(o) + '</option>'; }).join('') + '</select></label>'; };
    var inp = function (k, label, ph, type) { return '<label class="smf half"><span class="sml">' + label + '</span><input data-sf="' + k + '" value="' + esca(smF(s, k)) + '"' + (ph ? ' placeholder="' + esca(ph) + '"' : '') + (type ? ' type="' + type + '"' : '') + '></label>'; };
    var mr = normRef(smF(s, 'main'));
    return '<div class="smburden"><label class="smf"><span class="sml">What is the burden of this message?</span><small>Write what is on your heart before the structured study begins.</small><textarea data-sf="burden" rows="4">' + esc(smF(s, 'burden')) + '</textarea></label></div>' +
      '<div class="smgrid">' + inp('title', 'Sermon title', 'Working title') +
      '<label class="smf half"><span class="sml">Main Scripture</span><input data-sf="main" data-main="1" value="' + esca(smF(s, 'main')) + '" placeholder="e.g. John 15:1-17"><span class="smrefs" id="rf-main">' + (smF(s, 'main') ? (mr ? '<span class="smref ok">' + rlabel(mr) + ' ✓</span>' : '<span class="smref bad">Not found yet: use Book Chapter:Verse-Verse</span>') : '') + '</span></label>' +
      '<label class="smf"><span class="sml">Supporting Scriptures</span><small>One per line. Each is checked against the Bible.</small><textarea data-sf="support" data-refs="1" rows="3">' + esc(smF(s, 'support')) + '</textarea><span class="smrefs" id="rf-support">' + refList(smF(s, 'support')) + '</span></label>' +
      sel('type', 'Sermon type', TYPES) + sel('cat', 'Sermon category', CATS) + inp('date', 'Date', '', 'date') + inp('aud', 'Target audience', 'e.g. Sunday congregation') + sel('dur', 'Expected duration', ['10 minutes', '20 minutes', '30 minutes', '40 minutes', '45 minutes', '60 minutes', 'Longer']) + inp('occ', 'Occasion', 'e.g. Sunday service, youth camp') + inp('lang', 'Language', 'English') + sel('style', 'Preaching style', ['Jesus teaching approach', 'Paul teaching approach', 'Combined approach']) + sel('status', 'Status', STATUS) + '</div>';
  }
  function textStage(s) {
    var mr = normRef(smF(s, 'main'));
    if (!mr) return '<div class="smlock"><b>Set the main Scripture first.</b><span>Type it below or in 01 Sermon foundation. Everything else is built on the text.</span><input data-sf="main" data-main="1" value="' + esca(smF(s, 'main')) + '" placeholder="e.g. Romans 8:28-39"></div>';
    var vers = VL.filter(function (v) { return v !== 'HEB'; }), cmp = SW.cmp.length ? SW.cmp : [];
    var cmpH = cmp.length ? '<div class="smcmp"><table><thead><tr><th></th>' + [s.ver || 'KJV'].concat(cmp).map(function (v) { return '<th>' + esc(v) + '</th>'; }).join('') + '</tr></thead><tbody>' + passageVerses(mr, 'KJV').map(function (x) { return '<tr><td class="vn2">' + x.v + '</td>' + [s.ver || 'KJV'].concat(cmp).map(function (v) { return '<td>' + esc((passageVerses(x.b + ' ' + x.c + ':' + x.v, v)[0] || {}).t || '') + '</td>'; }).join('') + '</tr>'; }).join('') + '</tbody></table></div>' : '';
    var sel = SW.sel && SW.sel.s === s.id ? SW.sel.k : null;
    return '<div class="smtext"><div class="row" style="gap:8px;flex-wrap:wrap;align-items:center"><b class="smtref">' + rlabel(mr) + '</b><a data-act="smgo" data-r="' + esca(mr) + '">' + ic('book', 14) + ' Open in the reader</a><label class="small">Translation <select data-sver="1">' + vers.map(function (v) { return '<option' + ((s.ver || 'KJV') === v ? ' selected' : '') + '>' + esc(v) + '</option>'; }).join('') + '</select></label></div>' +
      '<p class="dim small">Tap a verse number to highlight it or write a note on it. Your highlights and notes stay with this sermon.</p>' +
      '<div class="smcmpbar"><span class="small">Compare with</span>' + vers.filter(function (v) { return v !== (s.ver || 'KJV'); }).slice(0, 8).map(function (v) { return '<button class="chip ' + (cmp.indexOf(v) >= 0 ? 'on' : '') + '" data-act="smcmp" data-v="' + v + '">' + esc(v) + '</button>'; }).join('') + '</div>' + cmpH +
      (sel ? '<label class="smf"><span class="sml">Note on ' + esc(sel) + '</span><textarea data-vnote="' + esca(sel) + '" rows="3">' + esc((s.vn || {})[sel] || '') + '</textarea></label>' : '') +
      '<label class="smf"><span class="sml">Observations</span><small>First impressions as you read the whole passage.</small><textarea data-sobs="1" rows="4">' + esc(s.obsv || '') + '</textarea></label>' +
      '<h4 class="smh">Supporting passages</h4><div class="smrefs">' + (refList(smF(s, 'support')) || '<span class="dim small">None yet. Add them in 01 Sermon foundation.</span>') + '</div></div>';
  }
  function outlineHtml(s) {
    var pts = s.points || [];
    return '<div class="smbigline"><small>Big idea</small><b>' + (smF(s, 'b_idea') ? esc(smF(s, 'b_idea')) : '<span class="dim">Not written yet — see 09 The big idea.</span>') + '</b></div>' +
      '<div class="smf"><span class="sml">Structure</span><small>Choosing a structure adds its starting points. You can add, remove, rename and reorder them freely.</small><div class="smchips">' + Object.keys(STRUCT).map(function (k) { return '<button class="chip ' + (s.struct === k ? 'on' : '') + '" data-act="smstruct" data-v="' + k + '">' + STRUCT[k][0] + '</button>'; }).join('') + '</div></div>' +
      (SW.cf === 'struct' ? '<p class="smnote">You already have points. <button class="warn" data-act="smstruct" data-v="' + esca(SW.pend) + '">Replace them with this structure</button> <button data-act="smstructadd" data-v="' + esca(SW.pend) + '">Add its points after mine</button> <button data-act="smcancel">Cancel</button></p>' : '') +
      '<ol class="smpts">' + pts.map(function (p, i) { return '<li><div class="row" style="gap:6px;flex-wrap:nowrap"><span class="smpn">' + (i + 1) + '</span><input data-pt="' + i + '" data-f="title" value="' + esca(p.title) + '" placeholder="Point title" aria-label="Point ' + (i + 1) + ' title"><input data-pt="' + i + '" data-f="ref" value="' + esca(p.ref) + '" placeholder="Scripture" aria-label="Point ' + (i + 1) + ' Scripture" class="smptref"><button class="ib" data-act="smpmove" data-i="' + i + '" data-d="-1" aria-label="Move up"' + (i ? '' : ' disabled') + '>↑</button><button class="ib" data-act="smpmove" data-i="' + i + '" data-d="1" aria-label="Move down"' + (i < pts.length - 1 ? '' : ' disabled') + '>↓</button><button class="ib" data-act="smpdel" data-i="' + i + '" aria-label="Remove point ' + (i + 1) + '">' + ic('x', 14) + '</button></div>' + (p.ref && !normRef(p.ref) ? '<span class="smbad">Reference not found</span>' : '') + '<button class="smpdev" data-act="smpdev" data-i="' + i + '">Develop this point ' + ic('cr', 13) + '</button></li>'; }).join('') + '</ol>' +
      '<button data-act="smpadd">' + ic('plus', 14) + ' Add a point</button>';
  }
  function pointsHtml(s) {
    var pts = s.points || []; if (!pts.length) return '<p class="smnote">No points yet. <a data-act="smstage" data-v="outline">Build the outline first</a>.</p>';
    var i = Math.min(SW.pt || 0, pts.length - 1), p = pts[i];
    return '<div class="smbigline"><small>Big idea</small><b>' + (smF(s, 'b_idea') ? esc(smF(s, 'b_idea')) : '<span class="dim">Not written yet</span>') + '</b></div><div class="smptabs" role="tablist">' + pts.map(function (q, j) { var n = PFIELDS.filter(function (x) { return q[x[0]] && String(q[x[0]]).trim(); }).length; return '<button class="' + (j === i ? 'on' : '') + '" data-act="smpt" data-i="' + j + '"><b>' + (j + 1) + '</b> ' + esc(q.title || 'Point ' + (j + 1)) + ' <small>' + n + '/' + PFIELDS.length + '</small></button>'; }).join('') + '</div>' +
      '<div class="smpt">' + PFIELDS.map(function (x) { var big = ['says', 'means', 'rev', 'evid', 'ill', 'app'].indexOf(x[0]) >= 0; return '<label class="smf"><span class="sml">' + x[1] + '</span><small>' + x[2] + '</small>' + (x[0] === 'title' || x[0] === 'ref' || x[0] === 'mem' ? '<input data-pt="' + i + '" data-f="' + x[0] + '" value="' + esca(p[x[0]]) + '">' : '<textarea data-pt="' + i + '" data-f="' + x[0] + '" rows="' + (big ? 3 : 2) + '">' + esc(p[x[0]] || '') + '</textarea>') + (x[0] === 'ref' && p.ref ? (normRef(p.ref) ? '<span class="smref ok"><a data-act="smgo" data-r="' + esca(normRef(p.ref)) + '">' + rlabel(normRef(p.ref)) + '</a></span>' : '<span class="smbad">Reference not found</span>') : '') + (x[0] === 'ill' ? illPicker(s, i) : '') + '</label>'; }).join('') + '</div>';
  }
  function illPicker(s, i) { var L = ILL.list; return L.length ? '<div class="smchips small"><span class="dim small">From your library:</span>' + L.slice(0, 12).map(function (x) { return '<button class="chip" data-act="smilluse" data-i="' + i + '" data-id="' + x.id + '">' + esc(x.title) + '</button>'; }).join('') + '</div>' : ''; }
  function modeHtml(s) {
    var m = smF(s, 'mode') || '';
    var d = { jesus: ['Mode 1 — Jesus teaching approach', 'Questions, images, parables where appropriate, simplicity, revelation, heart examination, conviction, memorable truth, direct application.'], paul: ['Mode 2 — Paul teaching approach', 'Biblical foundations, doctrine, reasoning, Scripture, explanation, progressive argument, correction, exhortation, practical implications.'], combined: ['Mode 3 — Combined approach', 'Deep but understandable; theological but not needlessly complicated; convicting but biblical; memorable but not gimmicky; powerful but not manipulative; practical without losing the truth of Scripture.'] };
    var done = function (stage) { var x = stageFill(s, stage); return x[1] && x[0] > 0; };
    return '<div class="smmodes">' + Object.keys(d).map(function (k) { return '<button class="smmode ' + (m === k ? 'on' : '') + '" data-act="smmode" data-v="' + k + '"><b>' + d[k][0] + (k === 'combined' ? ' <small>preferred</small>' : '') + '</b><span>' + d[k][1] + '</span></button>'; }).join('') + '</div>' +
      (m === 'combined' ? '<h4 class="smh">The combined flow</h4><ol class="smflow">' + COMBINED.map(function (c) { return '<li class="' + (done(c[1]) ? 'ok' : '') + '"><span>' + c[0] + '</span><a data-act="smstage" data-v="' + c[1] + '">' + (done(c[1]) ? 'Started' : 'Go to stage') + ' ' + ic('cr', 12) + '</a></li>'; }).join('') + '</ol>' : m ? '<p class="smnote">Work through stage <a data-act="smstage" data-v="' + (m === 'jesus' ? 'jesus' : 'paul') + '">' + (m === 'jesus' ? '11' : '12') + '</a>, then develop each point in <a data-act="smstage" data-v="points">15</a>.</p>' : '');
  }
  function illusHtml(s) {
    var mine = s.ills || [], L = ILL.list, ed = SW.ille;
    var form = '<div class="smillform"><b>' + (ed ? 'Edit illustration' : 'New illustration') + '</b><input id="illt" placeholder="Title" value="' + esca(ed ? ed.title : '') + '"><select id="illk">' + IXTYPES.map(function (t) { return '<option' + (ed && ed.type === t ? ' selected' : '') + '>' + t + '</option>'; }).join('') + '</select><textarea id="illx" rows="4" placeholder="The illustration, comparison or picture">' + esc(ed ? ed.text : '') + '</textarea><input id="illr" placeholder="Related Scripture (optional)" value="' + esca(ed ? ed.ref : '') + '"><input id="illg" placeholder="Tags, comma separated (optional)" value="' + esca(ed ? (ed.tags || []).join(', ') : '') + '"><div class="row"><button class="pri" data-act="smillsave">' + (ed ? 'Save changes' : 'Add to library') + '</button>' + (ed ? '<button data-act="smillcancel">Cancel</button>' : '') + '</div></div>';
    var q = (SW.iq || '').toLowerCase(), list = L.filter(function (x) { return !q || (x.title + ' ' + x.text + ' ' + x.type + ' ' + (x.tags || []).join(' ')).toLowerCase().indexOf(q) >= 0; });
    return '<p class="smnote">Your library is shared across all your sermons. Mark which illustrations this sermon uses.</p>' + form +
      '<div class="row" style="justify-content:space-between;align-items:center;margin-top:16px"><h4 class="smh" style="margin:0">Library <span class="dim">' + L.length + '</span></h4><input id="illq" placeholder="Search illustrations" value="' + esca(SW.iq || '') + '" style="max-width:240px"></div>' +
      '<div class="smills">' + (list.length ? list.map(function (x) { var used = mine.indexOf(x.id) >= 0; return '<div class="smill ' + (used ? 'used' : '') + '"><div class="row" style="justify-content:space-between"><b>' + esc(x.title) + '</b><span class="chip">' + esc(x.type) + '</span></div><p>' + esc(x.text) + '</p>' + (x.ref ? '<small>' + (normRef(x.ref) ? '<a data-act="smgo" data-r="' + esca(normRef(x.ref)) + '">' + rlabel(normRef(x.ref)) + '</a>' : esc(x.ref)) + '</small>' : '') + '<div class="row" style="gap:6px"><button class="' + (used ? 'pri' : '') + '" data-act="smilluse2" data-id="' + x.id + '">' + (used ? '✓ In this sermon' : 'Use in this sermon') + '</button><button data-act="smilledit" data-id="' + x.id + '">Edit</button><button data-act="smilldel" data-id="' + x.id + '" class="' + (SW.cf === 'idel' + x.id ? 'warn' : '') + '">' + (SW.cf === 'idel' + x.id ? 'Tap again to delete' : 'Delete') + '</button></div></div>'; }).join('') : '<p class="dim">' + (L.length ? 'No illustrations match.' : 'No illustrations yet. Add your first one above.') + '</p>') + '</div>';
  }
  function reviewHtml(s) {
    var row = function (l, v) { return v && String(v).trim() ? '<div class="smrv"><small>' + l + '</small><p>' + esc(v).replace(/\n/g, '<br>') + '</p></div>' : ''; };
    var mr = normRef(smF(s, 'main')), miss = [];
    if (!mr) miss.push('main Scripture'); if (!smF(s, 'b_idea')) miss.push('big idea'); if (!(s.points || []).length) miss.push('outline points'); if (!smF(s, 'n_hook')) miss.push('introduction');
    (s.points || []).forEach(function (p, i) { if (!p.big) miss.push('how point ' + (i + 1) + ' supports the big idea'); if (p.ref && !normRef(p.ref)) miss.push('a valid Scripture for point ' + (i + 1)); });
    return (miss.length ? '<p class="smnote">Still to do: ' + esc(miss.join(', ')) + '.</p>' : '<p class="smnote ok">Every core part is in place.</p>') +
      '<div class="row" style="gap:8px;margin-bottom:14px"><button data-act="smcopy">' + ic('copy', 14) + ' Copy as text</button><button data-act="smprint">Print</button><label class="small">Status <select data-sf="status">' + STATUS.map(function (o) { return '<option' + (smF(s, 'status') === o ? ' selected' : '') + '>' + o + '</option>'; }).join('') + '</select></label></div>' +
      '<article class="smms" id="smms"><h2>' + esc(smF(s, 'title') || 'Untitled sermon') + '</h2><p class="dim">' + [mr ? rlabel(mr) : '', smF(s, 'type'), smF(s, 'cat'), smF(s, 'date'), smF(s, 'dur')].filter(Boolean).join(' · ') + '</p>' +
      row('Big idea', smF(s, 'b_idea')) + row('The message in one sentence', smF(s, 'b_one')) + row('Purpose', smF(s, 'b_purp')) +
      '<h3>Introduction</h3>' + row('Opening', smF(s, 'n_hook')) + row('Tension', smF(s, 'n_tension')) + row('Into the text', smF(s, 'n_lead')) +
      (s.points || []).map(function (p, i) { return '<h3>' + (i + 1) + '. ' + esc(p.title || 'Point ' + (i + 1)) + (p.ref ? ' <small>' + esc(normRef(p.ref) ? rlabel(normRef(p.ref)).replace(/&amp;/g, '&') : p.ref) + '</small>' : '') + '</h3>' + row('What the text says', p.says) + row('What it means', p.means) + row('Revelation', p.rev) + row('Evidence', p.evid) + row('Illustration', p.ill) + row('Heart examination', p.heart) + row('Application', p.app) + row('Memorable statement', p.mem) + row('Transition', p.trans); }).join('') +
      '<h3>Response</h3>' + row('Conviction', smF(s, 'j_conv')) + row('The call to respond', smF(s, 'j_resp')) + row('Exhortation', smF(s, 'p_exh')) + row('The truth that must not be compromised', smF(s, 't_keep')) + '</article>';
  }
  function stageBody(s, id) {
    if (needsText(id) && !normRef(smF(s, 'main'))) return '<div class="smlock"><b>Establish the Scripture first.</b><span>The study is built on the text, so this stage opens once the main Scripture is set.</span><input data-sf="main" data-main="1" value="' + esca(smF(s, 'main')) + '" placeholder="e.g. Romans 8:28-39"><button class="pri" data-act="smstage" data-v="text">Go to 02 The text</button></div>';
    if (id === 'found') return foundHtml(s); if (id === 'text') return textStage(s); if (id === 'outline') return outlineHtml(s); if (id === 'points') return pointsHtml(s); if (id === 'mode') return modeHtml(s); if (id === 'illus') return illusHtml(s); if (id === 'review') return reviewHtml(s);
    return (BLOCKS[id] || []).map(function (b) { return blockHtml(s, b); }).join('');
  }
  function panelHtml(s) {
    var mr = normRef(smF(s, 'main')); if (!mr) return '<aside class="smpanel"><p class="dim small">The main Scripture will appear here.</p></aside>';
    var ver = s.ver || 'KJV', vs = passageVerses(mr, ver), hl = s.hl || {}, vn = s.vn || {}, lastc = null;
    return '<aside class="smpanel" aria-label="Main Scripture"><div class="row" style="justify-content:space-between"><b>' + rlabel(mr) + '</b><span class="chip">' + esc(ver) + '</span></div><div class="smpv">' + vs.map(function (x) { var k = x.b + ' ' + x.c + ':' + x.v, hd = x.c !== lastc && vs.length && (lastc !== null) ? '<span class="smch">' + esc(x.b) + ' ' + x.c + '</span>' : ''; lastc = x.c; return hd + '<span class="smv ' + (hl[k] ? 'hl' : '') + (vn[k] ? ' nt' : '') + '"><button class="smvn" data-act="smvsel" data-k="' + esca(k) + '" aria-label="Verse ' + x.v + ': highlight or note">' + x.v + '</button>' + esc(x.t) + ' </span>'; }).join('') + '</div>' +
      (SW.sel && SW.sel.s === s.id ? '<div class="row" style="gap:6px;margin-top:8px"><button data-act="smhl">' + (hl[SW.sel.k] ? 'Remove highlight' : 'Highlight ' + esc(SW.sel.k)) + '</button><button data-act="smstage" data-v="text">Note</button></div>' : '') +
      '<a class="small" data-act="smgo" data-r="' + esca(mr) + '">' + ic('book', 13) + ' Full context in the reader</a></aside>';
  }
  function libraryHtml2() {
    var q = SW.q.toLowerCase(), L = SM.list.slice().sort(function (a, b) { return (b.updated || 0) - (a.updated || 0); }).filter(function (s) { return (SW.st === 'all' || smF(s, 'status') === SW.st) && (!q || (smF(s, 'title') + ' ' + smF(s, 'main') + ' ' + smF(s, 'cat') + ' ' + (s.seed ? s.seed.text : '')).toLowerCase().indexOf(q) >= 0); });
    var seedForm = SW.newk ? (function () { var sd = SEEDS.filter(function (x) { return x[0] === SW.newk; })[0]; return '<div class="smnew2"><b>Start from ' + esc(sd[1].toLowerCase()) + '</b><input id="smseed" placeholder="' + esca(sd[2]) + '" autocomplete="off">' + (SW.newk === 'passage' ? '<small class="dim">This becomes the main Scripture.</small>' : '<small class="dim">You will choose the main Scripture next — the study is built on the text.</small>') + '<div class="row"><button class="pri" data-act="smcreate">Create sermon</button><button data-act="smnewk" data-v="">Cancel</button></div></div>'; })() : '';
    return '<div class="home smlib"><div class="greet"><button class="ib mobm" data-act="side" aria-label="Menu">' + ic('menu') + '</button><div><h1>Sermon & Study Workshop</h1></div></div><p class="dim" style="max-width:70ch">Study the text deeply, find the one message it carries, and shape it into a sermon — learning from how Jesus taught and how Paul reasoned, while staying faithful to Scripture.</p>' +
      '<h3>Start a new sermon from…</h3><div class="smseeds">' + SEEDS.map(function (x) { return '<button class="' + (SW.newk === x[0] ? 'on' : '') + '" data-act="smnewk" data-v="' + x[0] + '">' + esc(x[1]) + '</button>'; }).join('') + '</div>' + seedForm +
      (SM.list.length ? '<h3>Your sermons <span class="dim">' + SM.list.length + '</span></h3><div class="row" style="gap:8px;flex-wrap:wrap"><input id="smq" placeholder="Search sermons" value="' + esca(SW.q) + '" style="max-width:280px"><div class="smchips">' + ['all'].concat(STATUS).map(function (x) { return '<button class="chip ' + (SW.st === x ? 'on' : '') + '" data-act="smst" data-v="' + esca(x) + '">' + (x === 'all' ? 'All' : esc(x)) + '</button>'; }).join('') + '</div></div>' +
        '<div class="smcards">' + (L.length ? L.map(function (s) { var mr = normRef(smF(s, 'main')), pc = overall(s); return '<button class="smcard" data-act="smopen" data-id="' + s.id + '"><small>' + esc(smF(s, 'status') || 'Idea') + (smF(s, 'date') ? ' · ' + esc(smF(s, 'date')) : '') + '</small><b>' + esc(smF(s, 'title') || (s.seed && s.seed.text) || 'Untitled sermon') + '</b><span>' + (mr ? rlabel(mr) : '<i class="dim">No main Scripture yet</i>') + (smF(s, 'cat') ? ' · ' + esc(smF(s, 'cat')) : '') + '</span>' + (smF(s, 'b_idea') ? '<em>' + esc(smF(s, 'b_idea')) + '</em>' : '') + '<span class="rpg"><i style="width:' + pc + '%"></i></span><small>' + pc + '% prepared · edited ' + new Date(s.updated || s.created).toLocaleDateString() + '</small></button>'; }).join('') : '<p class="dim">No sermons match.</p>') + '</div>' : '<p class="dim" style="margin-top:18px">Your sermons will appear here. Everything saves as you type.</p>') + '</div>';
  }
  function workspaceHtml(s) {
    var id = SW.stage, st = STAGES.filter(function (x) { return x[0] === id; })[0] || STAGES[0], i = STAGES.indexOf(st);
    var nav = '<nav class="smnav" aria-label="Sermon stages">' + STAGES.map(function (x) { var f = stageFill(s, x[0]), lock = needsText(x[0]) && !normRef(smF(s, 'main')); return '<button class="' + (x[0] === id ? 'on' : '') + (lock ? ' lock' : '') + '" data-act="smstage" data-v="' + x[0] + '"><span class="no">' + x[1] + '</span><span class="tt">' + esc(x[2]) + '</span><i class="dot ' + (f[1] && f[0] >= f[1] ? 'full' : f[0] ? 'part' : '') + '" aria-hidden="true"></i></button>'; }).join('') + '</nav>';
    return '<div class="smws"><div class="smtop"><button class="ib mobm" data-act="side" aria-label="Menu">' + ic('menu') + '</button><a data-act="smclose">' + ic('back', 14) + ' All sermons</a><b>' + esc(smF(s, 'title') || (s.seed && s.seed.text) || 'Untitled sermon') + '</b><span class="smsaved" id="smsaved">Saved</span><span class="sp"></span><button data-act="smdup">Duplicate</button><button data-act="smdel" class="' + (SW.cf === 'del' ? 'warn' : '') + '">' + (SW.cf === 'del' ? 'Tap again to delete' : 'Delete') + '</button></div>' +
      '<div class="smbody">' + nav + '<section class="smstage"><div class="smhd"><span class="no">' + st[1] + '</span><div><h2>' + esc(st[2]) + '</h2><p class="dim">' + esc(st[3]) + '</p></div></div>' + (s.seed && s.seed.kind !== 'passage' && i < 2 ? '<p class="smseed"><small>Started from ' + esc((SEEDS.filter(function (x) { return x[0] === s.seed.kind; })[0] || [0, ''])[1].toLowerCase()) + ':</small> ' + esc(s.seed.text) + '</p>' : '') + stageBody(s, id) +
      '<div class="smpager">' + (i > 0 ? '<button data-act="smstage" data-v="' + STAGES[i - 1][0] + '">' + ic('cl', 13) + ' ' + STAGES[i - 1][1] + ' ' + esc(STAGES[i - 1][2]) + '</button>' : '<span></span>') + (i < STAGES.length - 1 ? '<button class="pri" data-act="smstage" data-v="' + STAGES[i + 1][0] + '">' + STAGES[i + 1][1] + ' ' + esc(STAGES[i + 1][2]) + ' ' + ic('cr', 13) + '</button>' : '') + '</div></section>' + panelHtml(s) + '</div></div>';
  }
  function sermonView() { var s = cur2(); return s ? workspaceHtml(s) : libraryHtml2(); }

  /* ---- editing ---- */
  function touch(s) { s.updated = Date.now(); smsv(); var el = document.getElementById('smsaved'); if (el) { el.textContent = 'Saving…'; clearTimeout(touch.t); touch.t = setTimeout(function () { el.textContent = 'Saved'; }, 600); } }
  function touchNow(s) { s.updated = Date.now(); clearTimeout(smT); store.s('sermons', SM); }
  var smFlush = function () { clearTimeout(smT); store.s('sermons', SM); };
  addEventListener('pagehide', smFlush); document.addEventListener('visibilitychange', function () { if (document.hidden) smFlush(); });
  document.addEventListener('input', function (e) {
    var t = e.target, s = cur2();
    if (t.id === 'smq') { SW.q = t.value; var c = document.querySelector('.smcards'); if (c) { var tmp = document.createElement('div'); tmp.innerHTML = libraryHtml2(); var n = tmp.querySelector('.smcards'); if (n) c.innerHTML = n.innerHTML; } return; }
    if (t.id === 'illq') { SW.iq = t.value; var c2 = document.querySelector('.smills'); if (c2 && s) { var tmp2 = document.createElement('div'); tmp2.innerHTML = illusHtml(s); c2.innerHTML = tmp2.querySelector('.smills').innerHTML; } return; }
    if (!s) return;
    if (t.dataset.sf) { s.f = s.f || {}; s.f[t.dataset.sf] = t.value; touch(s);
      if (t.dataset.refs) { var rf = document.getElementById('rf-' + t.dataset.sf); if (rf) rf.innerHTML = refList(t.value); }
      if (t.dataset.main) { var r = document.getElementById('rf-main'); var ok = normRef(t.value); if (r) r.innerHTML = t.value ? (ok ? '<span class="smref ok">' + rlabel(ok) + ' ✓</span>' : '<span class="smref bad">Not found yet: use Book Chapter:Verse-Verse</span>') : ''; clearTimeout(SW.mt); SW.mt = setTimeout(function () { if (normRef(t.value) !== SW.lastMain) { SW.lastMain = normRef(t.value); var ae = document.activeElement, sel0 = ae && ae.selectionStart; render(); var el = document.querySelector('[data-main="1"]'); if (el && ae && ae.dataset && ae.dataset.main) { el.focus(); try { el.setSelectionRange(sel0, sel0); } catch (x) {} } } }, 700); }
      if (/^n_/.test(t.dataset.sf)) { var m = document.querySelector('.smmeter'); if (m) { var tmp3 = document.createElement('div'); tmp3.innerHTML = blockHtml(s, ['intrometer']); m.outerHTML = tmp3.querySelector('.smmeter').outerHTML; } }
      return; }
    if (t.dataset.sg) { s[t.dataset.sg][t.dataset.t] = t.value; touch(s); return; }
    if (t.dataset.kw != null) { s.kw[+t.dataset.kw][t.dataset.f] = t.value; touch(s); return; }
    if (t.dataset.xr != null && t.tagName !== 'SELECT') { s.refs[+t.dataset.xr][t.dataset.f] = t.value; touch(s); return; }
    if (t.dataset.pt != null) { s.points[+t.dataset.pt][t.dataset.f] = t.value; touch(s); return; }
    if (t.dataset.vnote) { s.vn = s.vn || {}; if (t.value.trim()) s.vn[t.dataset.vnote] = t.value; else delete s.vn[t.dataset.vnote]; touch(s); return; }
    if (t.dataset.sobs) { s.obsv = t.value; touch(s); return; }
  });
  document.addEventListener('change', function (e) {
    var t = e.target, s = cur2(); if (!s) return;
    if (t.tagName === 'SELECT' && t.dataset.sf) { s.f[t.dataset.sf] = t.value; touch(s); return; }
    if (t.dataset.sver) { s.ver = t.value; touchNow(s); if (t.value !== 'KJV' && !BIB[t.value]) { loadVer(t.value).then(render); } render(); return; }
    if (t.dataset.xr != null && t.tagName === 'SELECT') { s.refs[+t.dataset.xr][t.dataset.f] = t.value; touch(s); return; }
    if (t.dataset.xr != null && t.dataset.f === 'ref') { render(); return; }
    if (t.dataset.pt != null && t.dataset.f === 'ref') { render(); return; }
  });
  function newSermon(kind, text) {
    var s = { id: 's' + Date.now().toString(36), created: Date.now(), updated: Date.now(), seed: { kind: kind, text: text }, f: { status: 'Idea', mode: 'combined', style: 'Combined approach', lang: 'English' }, points: [], refs: [], kw: [], hl: {}, vn: {}, th: {}, asp: {}, ills: [] };
    if (kind === 'passage') { var n = normRef(text); s.f.main = n || text; }
    if (kind === 'burden') s.f.burden = text; if (kind === 'question') s.f.n_hook = text; if (kind === 'topic' || kind === 'word') s.f.title = text;
    if (kind === 'doctrine') s.f.t_central = text; if (kind === 'character') s.f.type = 'Character study'; if (kind === 'event') s.f.type = 'Biblical narrative';
    return s;
  }
  var actW = act;
  act = function (a, d) {
    d = d || {}; var s = cur2();
    switch (a) {
      case 'sermons': view = 'sermons'; if (innerWidth <= 800) side = false; SW.cf = null; sv(); render(); return;
      case 'smnewk': SW.newk = d.v || null; render(); setTimeout(function () { var i = $('#smseed'); if (i) i.focus(); }, 30); return;
      case 'smcreate': { var v = ($('#smseed') || {}).value || ''; v = v.trim(); if (!v) { toast('Write something to start from'); return; } if (SW.newk === 'passage' && !normRef(v)) { toast('That reference was not found. Try e.g. John 15:1-17'); return; } var n = newSermon(SW.newk, v); SM.list.push(n); store.s('sermons', SM); SW.open = n.id; SW.stage = SW.newk === 'passage' ? 'found' : 'found'; SW.newk = null; swsv(); render(); return; }
      case 'smopen': SW.open = d.id; SW.stage = (cur2() && cur2().stage) || 'found'; SW.cf = null; SW.pt = 0; swsv(); render(); return;
      case 'smclose': SW.open = null; SW.cf = null; swsv(); render(); return;
      case 'smst': SW.st = d.v; render(); return;
      case 'smstage': if (!s) return; SW.stage = d.v; s.stage = d.v; SW.cf = null; smsv(); swsv(); render(); var m0 = document.querySelector('.smstage'); if (m0) m0.scrollTop = 0; window.scrollTo(0, 0); return;
      case 'smdel': if (SW.cf !== 'del') { SW.cf = 'del'; render(); return; } SM.list = SM.list.filter(function (x) { return x !== s; }); store.s('sermons', SM); SW.open = null; SW.cf = null; swsv(); toast('Sermon deleted'); render(); return;
      case 'smdup': { var c = JSON.parse(JSON.stringify(s)); c.id = 's' + Date.now().toString(36); c.created = c.updated = Date.now(); c.f.title = (c.f.title || 'Untitled sermon') + ' (copy)'; SM.list.push(c); store.s('sermons', SM); SW.open = c.id; swsv(); toast('Duplicated'); render(); return; }
      case 'smchip': { var cur3 = smF(s, d.k); if (d.m) { var arr = cur3 ? cur3.split('|') : [], j = arr.indexOf(d.v); if (j >= 0) arr.splice(j, 1); else arr.push(d.v); s.f[d.k] = arr.join('|'); } else s.f[d.k] = cur3 === d.v ? '' : d.v; touchNow(s); render(); return; }
      case 'smsrc': s.src = s.src || {}; s.src[d.k] = s.src[d.k] === d.v ? '' : d.v; touchNow(s); render(); return;
      case 'smtheme': { var g = s[d.g] = s[d.g] || {}; if (d.v in g) delete g[d.v]; else g[d.v] = ''; touchNow(s); render(); return; }
      case 'smgo': { var p = parse(d.r); if (!p) return; var us = runits(d.r); go({ b: p.b, c: p.c, v: us ? us[0].v1 : p.v }, true); return; }
      case 'smvsel': SW.sel = SW.sel && SW.sel.k === d.k ? null : { s: s.id, k: d.k }; render(); return;
      case 'smhl': if (SW.sel) { s.hl = s.hl || {}; if (s.hl[SW.sel.k]) delete s.hl[SW.sel.k]; else s.hl[SW.sel.k] = 1; touchNow(s); render(); } return;
      case 'smcmp': { var i2 = SW.cmp.indexOf(d.v); if (i2 >= 0) SW.cmp.splice(i2, 1); else { SW.cmp.push(d.v); if (SW.cmp.length > 3) SW.cmp.shift(); if (!BIB[d.v] && d.v !== 'KJV') loadVer(d.v).then(render); } render(); return; }
      case 'smkwsug': SW.kwc = SW.kwc === s.id ? null : s.id; render(); return;
      case 'smkwadd': s.kw = s.kw || []; s.kw.push({ word: '', meaning: '', usage: '', rel: '' }); touchNow(s); render(); return;
      case 'smkwpick': s.kw = s.kw || []; s.kw.push({ word: d.w, strong: d.k, meaning: '', usage: d.v, rel: '' }); touchNow(s); render(); return;
      case 'smkwdel': s.kw.splice(+d.i, 1); touchNow(s); render(); return;
      case 'smxadd': s.refs = s.refs || []; s.refs.push({ cat: d.c, ref: '', ev: d.c === 'xref' || d.c === 'par' ? 'explicit' : 'interp', note: '' }); touchNow(s); render(); return;
      case 'smxdel': s.refs.splice(+d.i, 1); touchNow(s); render(); return;
      case 'smxsug': SW.xr = SW.xr === s.id ? null : s.id; render(); return;
      case 'smxpick': s.refs = s.refs || []; if (!s.refs.some(function (x) { return x.ref === d.r; })) s.refs.push({ cat: 'xref', ref: d.r, ev: 'explicit', note: '' }); touchNow(s); render(); return;
      case 'smstruct': { var T = STRUCT[d.v]; if ((s.points || []).length && SW.cf !== 'struct') { SW.cf = 'struct'; SW.pend = d.v; render(); return; } s.struct = d.v; s.points = structPoints(s, d.v); SW.cf = null; touchNow(s); render(); return; }
      case 'smstructadd': s.struct = d.v; s.points = (s.points || []).concat(structPoints(s, d.v)); SW.cf = null; touchNow(s); render(); return;
      case 'smcancel': SW.cf = null; render(); return;
      case 'smpadd': s.points = s.points || []; s.points.push({ title: '' }); touchNow(s); render(); return;
      case 'smpdel': s.points.splice(+d.i, 1); touchNow(s); render(); return;
      case 'smpmove': { var k = +d.i, to = k + +d.d; if (to < 0 || to >= s.points.length) return; var tmp = s.points[k]; s.points[k] = s.points[to]; s.points[to] = tmp; touchNow(s); render(); return; }
      case 'smpdev': SW.pt = +d.i; SW.stage = 'points'; s.stage = 'points'; swsv(); render(); return;
      case 'smpt': SW.pt = +d.i; render(); return;
      case 'smmode': s.f.mode = d.v; s.f.style = { jesus: 'Jesus teaching approach', paul: 'Paul teaching approach', combined: 'Combined approach' }[d.v]; touchNow(s); render(); return;
      case 'smillsave': { var tt = ($('#illt') || {}).value || '', tx = ($('#illx') || {}).value || ''; if (!tt.trim() || !tx.trim()) { toast('Add a title and the illustration'); return; } var o = { id: SW.ille ? SW.ille.id : 'i' + Date.now().toString(36), title: tt.trim(), type: $('#illk').value, text: tx.trim(), ref: ($('#illr').value || '').trim(), tags: ($('#illg').value || '').split(',').map(function (x) { return x.trim(); }).filter(Boolean) }; var ix = ILL.list.findIndex(function (x) { return x.id === o.id; }); if (ix >= 0) ILL.list[ix] = o; else ILL.list.unshift(o); illsv(); SW.ille = null; toast('Saved to your library'); render(); return; }
      case 'smillcancel': SW.ille = null; render(); return;
      case 'smilledit': SW.ille = ILL.list.filter(function (x) { return x.id === d.id; })[0] || null; render(); return;
      case 'smilldel': if (SW.cf !== 'idel' + d.id) { SW.cf = 'idel' + d.id; render(); return; } ILL.list = ILL.list.filter(function (x) { return x.id !== d.id; }); illsv(); SW.cf = null; render(); return;
      case 'smilluse2': { s.ills = s.ills || []; var ii = s.ills.indexOf(d.id); if (ii >= 0) s.ills.splice(ii, 1); else s.ills.push(d.id); touchNow(s); render(); return; }
      case 'smilluse': { var il = ILL.list.filter(function (x) { return x.id === d.id; })[0], pp = s.points[+d.i]; if (il && pp) { pp.ill = (pp.ill ? pp.ill + '\n\n' : '') + il.title + ': ' + il.text; s.ills = s.ills || []; if (s.ills.indexOf(il.id) < 0) s.ills.push(il.id); touchNow(s); render(); } return; }
      case 'smcopy': { var el = $('#smms'); var txt = el ? el.innerText : ''; try { navigator.clipboard.writeText(txt).then(function () { toast('Copied'); }, function () { toast('Copy is not available here'); }); } catch (e) { toast('Copy is not available here'); } return; }
      case 'smprint': { var el2 = $('#smms'); if (!el2) return; document.body.classList.add('smprinting'); try { window.print(); } catch (e) { toast('Printing is not available here. Use Copy as text instead.'); } setTimeout(function () { document.body.classList.remove('smprinting'); }, 500); return; }
    }
    return actW(a, d);
  };
  function structPoints(s, k) {
    var T = STRUCT[k]; if (T[1]) return T[1].map(function (t) { return { title: t === 'Point 1' || /^Point \d/.test(t) ? '' : t, ph: t }; });
    var mr = normRef(smF(s, 'main')); if (!mr) return [{ title: '' }];
    var vs = passageVerses(mr, 'KJV'), n = vs.length, groups = n <= 6 ? n : Math.min(6, Math.ceil(n / 3)), out = [];
    for (var g = 0; g < groups; g++) { var a2 = vs[Math.floor(g * n / groups)], b2 = vs[Math.floor((g + 1) * n / groups) - 1]; out.push({ title: '', ref: a2.b + ' ' + a2.c + ':' + a2.v + (b2.v !== a2.v || b2.c !== a2.c ? (b2.c !== a2.c ? '' : '-' + b2.v) : '') }); }
    return out;
  }
  var side3 = sideHtml;
  sideHtml = function () { return side3().replace('<button data-act="library"', '<button data-act="sermons" class="' + (view === 'sermons' ? 'on' : '') + '" title="Sermon Workshop">' + ic('pen') + '<span class="lb">Sermon Workshop</span></button><button data-act="library"'); };
  var renderW = render;
  render = function () { renderW(); if (view === 'sermons') { $('#main').innerHTML = sermonView(); var dr0 = $('#drawer'); if (dr0) dr0.classList.remove('open'); var tb0 = $('#tb'); if (tb0) tb0.style.display = 'none'; } };

  /* ============ 16. Word Study — Hebrew & Greek Lab ============ */
  // Built on the data inside the app: the Strong's-tagged KJV (which English word renders which original word, verse by
  // verse), the Strong's dictionary, and the Hebrew Bible with its morphology codes. Nothing is generated: counts are
  // counted, links are typed by their source, and interpretation is the student's, recorded with its evidence.
  SYNC_KEYS.push('wstudy');
  var WZ = store.g('wstudy', null) || { words: {}, hist: [] }; WZ.words = WZ.words || {}; WZ.hist = WZ.hist || [];
  var wzT = 0, wzsv = function (now) { clearTimeout(wzT); if (now) store.s('wstudy', WZ); else wzT = setTimeout(function () { store.s('wstudy', WZ); }, 400); };
  addEventListener('pagehide', function () { wzsv(true); }); document.addEventListener('visibilitychange', function () { if (document.hidden) wzsv(true); });
  var WV = Object.assign({ k: null, r: null, tab: 'ov', dash: 'home' }, store.g('wzv', {}));
  Object.assign(WV, { ask: false, q: '', lang: 'all', mode: 'auto', of: { t: 'all', b: '', g: '', w: '', s: '', sort: 'bible', p: 0 }, sel: [], cv: [], exp: {}, bp: 0, bl: 'all', letter: null, acro: null, an: { lang: 'all', st: 'all', hide: 1 }, rb: '', cf: null, sd: '', cp: '' });
  var wvsv = function () { store.s('wzv', { k: WV.k, r: WV.r, tab: WV.tab, dash: WV.dash }); };
  var WZTABS = [['ov', 'Overview', 'Identify the word'], ['mean', 'Meaning', 'Understand the word'], ['gram', 'Grammar', 'Form and morphology'], ['ctx', 'Context', 'Study the passage'], ['occ', 'Occurrences', 'Trace the word'], ['cmp', 'Compare', 'Compare usage'], ['con', 'Connections', 'Explore relationships'], ['theo', 'Theology', 'What the evidence supports'], ['notes', 'Notes', 'Record your discovery'], ['rep', 'Report', 'Build a study']];
  var WZST = ['To study', 'Studying', 'Studied', 'Important', 'Sermon reference', 'Teaching reference', 'Personal insight'];
  var WZNOTES = [['disc', 'What I discovered'], ['orig', 'What the original language reveals'], ['obs', 'Important observations'], ['ctx', 'Context notes'], ['q', 'Questions'], ['theo', 'Theological insights'], ['rel', 'Related Scriptures'], ['app', 'Personal application'], ['serm', 'Sermon ideas'], ['bs', 'Bible study ideas'], ['pray', 'Prayer'], ['inv', 'Things to investigate further'], ['concl', 'Study conclusion']];
  var WZLAYERS = [['ling', 'Linguistic meaning', 'What the word can mean, shown by its usage', 1], ['pass', 'Meaning in the passage', 'What it means in this verse, shown by the context', 1], ['bt', 'Biblical-theological significance', 'How Scripture develops it, shown by several passages', 1], ['st', 'Systematic interpretation', 'How it fits doctrine. Mark it as interpretation', 0], ['app', 'Personal application', 'What it asks of me', 0]];
  var WZREL = { root: ['Same root or derivation', '#b7791f', ''], rel: ['Related word (Strong\'s cross-reference)', '#2f7d6d', '6 4'], sim: ['Similar meaning (your link)', '#3b6fb6', '2 3'], opp: ['Opposite meaning (your link)', '#b5452f', '8 3 2 3'], tr: ['Translation equivalent (same KJV English word)', '#7a5aa6', '1 4'], theo: ['Theological association (your link)', '#8a6d1f', '10 4'], co: ['Occurs alongside it in the text', '#6b7280', '3 6'] };
  var WZANCH = [['God', ['H430', 'H3068', 'H410', 'G2316']], ['Jesus Christ', ['G2424', 'G5547', 'H4899']], ['Spirit (ruach / pneuma)', ['H7307', 'G4151']], ['Humanity', ['H120', 'H376', 'G444']], ['Sin', ['H2403', 'H2398', 'H5771', 'H6588', 'G266', 'G264']], ['Salvation', ['H3444', 'H3467', 'G4991', 'G4982', 'G4990']], ['Faith and trust', ['H539', 'H530', 'H982', 'G4102', 'G4100']], ['Kingdom', ['H4438', 'H4467', 'G932']], ['Covenant', ['H1285', 'G1242']], ['Obedience and hearing', ['H8085', 'G5218', 'G5219']], ['Life', ['H2416', 'G2222']], ['Grace and mercy', ['H2580', 'H2617', 'G5485', 'G1656']]];
  var WZSTEM = { Qal: 'the basic stem: usually the simple active sense of the verb.', Niphal: 'often passive or reflexive of the Qal, sometimes with other functions depending on the verb.', Piel: 'often called "intensive", but its functions vary (factitive, resultative, denominative); the meaning depends on the verb.', Pual: 'usually the passive of the Piel.', Hiphil: 'often causative (causing someone to do or be something), though not always.', Hophal: 'usually the passive of the Hiphil.', Hithpael: 'often reflexive or reciprocal (acting on oneself or one another), sometimes iterative.' };
  var HLET = [['א', 'Aleph', 'silent / glottal stop'], ['ב', 'Bet', 'b, v'], ['ג', 'Gimel', 'g'], ['ד', 'Dalet', 'd'], ['ה', 'He', 'h'], ['ו', 'Vav', 'v (w)'], ['ז', 'Zayin', 'z'], ['ח', 'Het', 'ḥ (throaty h)'], ['ט', 'Tet', 'ṭ'], ['י', 'Yod', 'y'], ['כ', 'Kaf', 'k, kh', 'ך'], ['ל', 'Lamed', 'l'], ['מ', 'Mem', 'm', 'ם'], ['נ', 'Nun', 'n', 'ן'], ['ס', 'Samekh', 's'], ['ע', 'Ayin', 'ʿ (throat sound, often silent today)'], ['פ', 'Pe', 'p, f', 'ף'], ['צ', 'Tsade', 'ts', 'ץ'], ['ק', 'Qof', 'q'], ['ר', 'Resh', 'r'], ['ש', 'Shin / Sin', 'sh, s'], ['ת', 'Tav', 't']];
  var ACRO = [['Psalms', 25], ['Psalms', 34], ['Psalms', 37], ['Psalms', 111], ['Psalms', 112], ['Psalms', 119], ['Psalms', 145], ['Proverbs', 31, 10], ['Lamentations', 1], ['Lamentations', 2], ['Lamentations', 3], ['Lamentations', 4]];
  var FINAL = { 'ך': 'כ', 'ם': 'מ', 'ן': 'נ', 'ף': 'פ', 'ץ': 'צ' };

  /* ---- data helpers ---- */
  // derivation from Strong's notes: only "from N" counts as a source; "compare N" is a cross-reference, not a root
  var WZPA = null, WZCHD = null;
  function wzFam() { if (WZPA) return; WZPA = {}; WZCHD = {}; Object.keys(LEX).forEach(function (k) { var e = LEX[k], ps = []; if (e && e[5]) e[5].split(';').forEach(function (seg) { if (/compare|\bsee\b|comp\./i.test(seg)) return; (seg.match(/\b\d{1,4}\b/g) || []).forEach(function (n) { var x = k[0] + n; if (x !== k && LEX[x] && ps.indexOf(x) < 0) ps.push(x); }); }); if (ps.length) { WZPA[k] = ps; ps.forEach(function (x) { (WZCHD[x] = WZCHD[x] || []).push(k); }); } }); }
  function wzRoot(k) { wzFam(); var r = k, d = 0; while (WZPA[r] && d++ < 6) r = WZPA[r][0]; return r; }
  function wzKids(k) { wzFam(); return WZCHD[k] || []; }
  function wzFamily(k) { var r = wzRoot(k), seen = [r]; for (var i = 0; i < seen.length && seen.length < 40; i++) wzKids(seen[i]).forEach(function (c) { if (seen.indexOf(c) < 0) seen.push(c); }); return seen; }
  function wzHedge(k) { var e = LEX[k]; return e && /perhaps|probably|apparently|uncertain|or from/i.test((e[5] || '').split(';')[0]) ? ' (Strong\'s is uncertain)' : ''; }
  function wzCH() { try { return (0, eval)('CH') || null; } catch (e) { return null; } } // the app's word-family map (a local CH in section 14 shadows it)
  function wzW(k) { return WZ.words[k] || (WZ.words[k] = { st: '', n: {}, th: [], oc: {}, cm: {}, links: [], first: Date.now(), last: 0, views: 0, reps: [] }); }
  function wzE(k) { return LEX[k] || null; }
  function wzScript(k) { var e = LEX[k]; return (e && e[0] ? e[0].split(',')[0].trim() : '') || (k[0] === 'H' && HEBL[k]) || ''; }
  function wzTr(k) { var e = LEX[k]; return e ? e[1] : ''; }
  function wzGloss(k) { var e = LEX[k]; return e ? (e[7] || (e[3] || '').split(/[;(]/)[0]) : ''; }
  function wzPos(k) { var e = LEX[k]; return e ? (e[6] || '').split(' -')[0].trim() : ''; }
  function wzPhon(k) { var e = LEX[k]; if (!e) return ''; var m = /Phonetic Spelling:\s*\(([^)]+)\)/.exec((e[6] || '') + ' ' + (e[5] || '')); return m ? m[1] : ''; }
  function wzLang(k) { return k[0] === 'H' ? 'Hebrew' : 'Greek'; }
  function wzRef(b, c, v) { return b + ' ' + c + ':' + v; }
  function wzSplitRef(r) { var m = /^(.+) (\d+):(\d+)$/.exec(r); return m ? { b: m[1], c: +m[2], v: +m[3] } : null; }
  function wzGroup(b) { var x = typeof CLS !== 'undefined' && CLS && CLS.books.find(function (y) { return y.name === b; }); return x ? x.group : ''; }
  function wzStrip(s) { return (s || '').normalize('NFD').replace(/[̀-֑ͯ-ׇʼʻ'’`·\-]/g, '').replace(/ς/g, 'σ').toLowerCase(); }
  function wzKey(s) { s = (s || '').trim().toUpperCase(); return /^[HG]\d+$/.test(s) && (LEX[s] || (CI && CI[s])) ? s : null; }
  function wzA(k, label, cls) { return '<a class="wzk ' + (cls || '') + '" data-act="wsopen" data-k="' + k + '">' + (label != null ? label : '<span class="' + (k[0] === 'H' ? 'hebw' : 'grk') + '" lang="' + (k[0] === 'H' ? 'he' : 'grc') + '">' + esc(wzScript(k)) + '</span> ' + esc(wzTr(k)) + ' <small>' + k + '</small>') + '</a>'; }
  function wzRefA(r, t) { return '<a class="wzr" data-act="wzgo" data-r="' + esc(r) + '">' + esc(t || r) + '</a>'; }
  function wzBars(items, opt) { opt = opt || {}; var mx = Math.max(1, Math.max.apply(null, items.map(function (x) { return x[1]; }).concat([1]))); return '<div class="wzbars' + (opt.cls ? ' ' + opt.cls : '') + '">' + items.map(function (x) { return '<div class="wzbar' + (x[3] ? ' on' : '') + '"' + (x[2] ? ' data-act="' + x[2].a + '"' + Object.keys(x[2]).filter(function (q) { return q !== 'a'; }).map(function (q) { return ' data-' + q + '="' + esc(String(x[2][q])) + '"'; }).join('') + ' role="button" tabindex="0"' : '') + '><span class="l">' + x[0] + '</span><span class="t"><i style="width:' + (x[1] / mx * 100).toFixed(1) + '%"></i></span><b>' + x[1].toLocaleString() + '</b></div>'; }).join('') + '</div>'; }

  // every KJV occurrence of a Strong's number, with the English words that render it in that verse
  var WZO = { k: null, L: null };
  function wzOcc(k) {
    if (WZO.k === k && WZO.L) return WZO.L;
    var tag = '{' + k + '}', L = [];
    BOOKS.forEach(function (b, bi) { var B = KJV[b]; if (!B) return; Object.keys(B).forEach(function (c) { (B[c] || []).forEach(function (t, i) { if (t && t.indexOf(tag) >= 0) L.push(wzRow(b, +c, i + 1, t, k, bi)); }); }); });
    WZO = { k: k, L: L }; return L;
  }
  function wzRow(b, c, v, t, k, bi) {
    var re = /([^{}]*?)((?:\{[HG]\d+\})+)/g, m, w = [], ph = [], n = 0;
    while ((m = re.exec(t))) { var tags = m[2].match(/[HG]\d+/g); var hits = tags.filter(function (x) { return x === k; }).length; if (!hits) continue; n += hits; var seg = m[1].trim().split(/\s+/).filter(Boolean); var last = (seg[seg.length - 1] || '').toLowerCase().replace(/[^a-z'’-]/g, ''); if (last) w.push(last); ph.push((seg.length <= 2 ? seg : seg.slice(-1)).join(' ').replace(/^[^A-Za-z]+|[^A-Za-z'’]+$/g, '')); }
    return { b: b, c: c, v: v, bi: bi, r: wzRef(b, c, v), ot: bi < 39, w: w, ph: ph, n: n, t: t };
  }
  function wzVerseHtml(t, k) { t = (t || '').replace(/\{\([HG]\d+\)\}/g, ''); return esc(t).replace(/([^\s{}]+)((?:\{[HG]\d+\})+)/g, function (m0, w, tg) { var ks = tg.match(/[HG]\d+/g); return ks.indexOf(k) >= 0 ? '<mark>' + w + '</mark>' : '<span class="wzw" data-act="wsopen" data-k="' + ks[0] + '" title="' + ks.join(' ') + '">' + w + '</span>'; }).replace(/\{[HG]\d+\}/g, ''); }
  // Hebrew: parsed tokens (surface form, Strong's, morphology) from the bundled Hebrew Bible
  var HBP = null;
  function wzHBP() { if (!HB) return null; if (!HBP) HBP = HB.t.map(function (s) { var a = s.split('\t'), lm = (a[1] || '').split('|'); return [a[0], lm[1] ? 'H' + lm[1] : '', a[2] || '', lm[0] || '']; }); return HBP; }
  function wzHebAt(b, c, v, k) { // the Hebrew word(s) behind this KJV occurrence
    var P = wzHBP(); if (!P || !HB.d[b]) return [];
    var m = (HB.m[b] || {})[c + ':' + v] || c + ':' + v, out = [];
    m.split(',').forEach(function (r) { var q = r.split(':'); ((HB.d[b][q[0]] || {})[q[1]] || []).forEach(function (i) { var x = P[i]; if (x && x[1] === k) out.push({ h: x[0], mo: x[2], pre: x[3], hr: q[0] + ':' + q[1] }); }); });
    return out;
  }
  var WZH = {};
  function wzHebStats(k) { // counts across the whole Hebrew text
    if (WZH[k]) return WZH[k]; var P = wzHBP(); if (!P) return null;
    var n = 0, stems = {}, forms = {}, surf = {};
    Object.keys(HB.d).forEach(function (b) { var B = HB.d[b]; Object.keys(B).forEach(function (c) { var C = B[c]; Object.keys(C).forEach(function (v) { C[v].forEach(function (i) { var x = P[i]; if (!x || x[1] !== k) return; n++; var p = x[2].slice(1).split('/').pop() || ''; if (p[0] === 'V') { var st = MS[p[1]] || p[1]; stems[st] = (stems[st] || 0) + 1; } var f = morph(x[2]) || '—'; forms[f] = (forms[f] || 0) + 1; var s = x[0].replace(/[֑-ֽ֯׀׃]/g, ''); surf[s] = (surf[s] || 0) + 1; }); }); }); });
    return (WZH[k] = { n: n, stems: stems, forms: forms, surf: surf });
  }
  function wzStemOf(mo) { var p = (mo || '').slice(1).split('/').pop() || ''; return p[0] === 'V' ? (MS[p[1]] || p[1]) : ''; }
  function wzBookCounts(L) { var o = {}; L.forEach(function (x) { o[x.b] = (o[x.b] || 0) + x.n; }); return o; }
  function wzRend(k) { var o = CI && CI[k]; return o ? Object.keys(o.w).map(function (w) { return [w, o.w[w]]; }).sort(function (a, b) { return b[1] - a[1]; }) : []; }

  // relationships, each typed by where it comes from
  function wzRels(k) {
    var out = [], seen = {}, e = LEX[k], o = CI && CI[k];
    var add = function (x, t, why) { if (!x || x === k || !(LEX[x] || (CI && CI[x]))) return; var id = x + t; if (seen[id]) return; seen[id] = 1; out.push({ k: x, t: t, why: why }); };
    if (e && e[5]) e[5].split(';').forEach(function (seg) { var cmp = /compare|\bsee\b|comp\./i.test(seg); (seg.match(/\b\d{1,4}\b/g) || []).forEach(function (n) { add(k[0] + n, cmp ? 'rel' : 'root', cmp ? 'Strong\'s: "compare ' + n + '"' : 'Strong\'s: this word comes from ' + k[0] + n + wzHedge(k)); }); });
    wzKids(k).forEach(function (x) { add(x, 'root', 'Strong\'s: ' + x + ' comes from this word' + wzHedge(x)); }); var r = wzRoot(k); if (r !== k) { add(r, 'root', 'The source word of this family'); wzKids(r).forEach(function (x) { add(x, 'root', 'Also comes from ' + r); }); }
    if (o) wzRend(k).slice(0, 4).forEach(function (w) { var m = EN[w[0]] || {}; Object.keys(m).sort(function (a, b) { return m[b] - m[a]; }).slice(0, 6).forEach(function (x) { add(x, 'tr', 'The KJV also renders ' + x + ' as “' + w[0] + '” (' + m[x] + '×)' + (x[0] !== k[0] ? ' · ' + (x[0] === 'H' ? 'Old' : 'New') + ' Testament' : '')); }); });
    if (o && o.nb) Object.keys(o.nb).filter(function (x) { var pp = LEX[x] && LEX[x][6] || ''; return !COMMON[x] && /noun|verb|adjective/i.test(pp) && !/pronoun|proper name/i.test(pp); }).sort(function (a, b) { return o.nb[b] - o.nb[a]; }).slice(0, 5).forEach(function (x) { add(x, 'co', 'Stands next to it ' + o.nb[x] + ' times in the tagged text'); });
    (WZ.words[k] ? WZ.words[k].links : []).forEach(function (l) { add(l.k, l.t, (l.note || 'Your link') + (l.ev ? ' · evidence: ' + l.ev : '')); });
    return out;
  }

  /* ---- search ---- */
  var WZIX = null;
  function wzIndex() { if (WZIX) return WZIX; WZIX = Object.keys(LEX).map(function (k) { var e = LEX[k]; return [k, wzStrip(e[0]), wzStrip(e[1]), ((e[7] || '') + ' ' + (e[3] || '')).toLowerCase()]; }); return WZIX; }
  function wzSearch(q, lang, mode) {
    q = (q || '').trim(); if (!q) return null; ensureCI();
    var res = { groups: [] }, ok = function (k) { return lang === 'all' || k[0] === (lang === 'heb' ? 'H' : 'G'); }, push = function (title, ks, note) { ks = ks.filter(function (x) { return ok(x[0]); }); if (ks.length) res.groups.push({ title: title, ks: ks, note: note }); };
    var cntOf = function (k) { return CI && CI[k] ? CI[k].n : 0; }, byFreq = function (a, b) { return cntOf(b[0]) - cntOf(a[0]); };
    var auto = mode === 'auto';
    if ((auto || mode === 'strong') && /^[HG]?\d{1,4}$/i.test(q)) { var ks = /^\d/.test(q) ? ['H' + +q, 'G' + +q] : [q[0].toUpperCase() + +q.slice(1)]; push('Strong\'s number', ks.filter(function (k) { return LEX[k]; }).map(function (k) { return [k, '']; })); if (!res.groups.length && mode === 'strong') res.empty = 'There is no Strong\'s entry ' + q.toUpperCase() + '. Hebrew runs H1–H8674, Greek G1–G5624, with some numbers unused.'; return res; }
    if ((auto || mode === 'ref') && /\d+:\d+/.test(q)) { var p = parse(q); if (p && KJV[p.b] && KJV[p.b][p.c] && KJV[p.b][p.c][p.v - 1]) { var t = KJV[p.b][p.c][p.v - 1], ks2 = [], re = /([^\s{}]+)((?:\{[HG]\d+\})+)/g, m; while ((m = re.exec(t))) m[2].match(/[HG]\d+/g).forEach(function (k) { if (!ks2.some(function (x) { return x[0] === k; })) ks2.push([k, '“' + m[1].replace(/[^\w'’-]/g, '') + '”']); }); res.ref = wzRef(p.b, p.c, p.v); push('Words in ' + wzRef(p.b, p.c, p.v) + ', in verse order', ks2, 'Each English word is linked to the original word it translates in this verse.'); return res; } }
    var I = wzIndex(), sq = wzStrip(q);
    if (/[֐-׿]/.test(q) || mode === 'heb') { var h = I.filter(function (x) { return x[0][0] === 'H' && x[1] && (x[1] === sq || x[1].indexOf(sq) === 0); }).sort(function (a, b) { return (b[1] === sq) - (a[1] === sq) || cntOf(b[0]) - cntOf(a[0]); }).slice(0, 40); push('Hebrew words', h.map(function (x) { return [x[0], '']; })); return res; }
    if (/[Ͱ-Ͽἀ-῿]/.test(q) || mode === 'grk') { var g = I.filter(function (x) { return x[0][0] === 'G' && x[1] && (x[1] === sq || x[1].indexOf(sq) === 0); }).sort(function (a, b) { return (b[1] === sq) - (a[1] === sq) || cntOf(b[0]) - cntOf(a[0]); }).slice(0, 40); push('Greek words', g.map(function (x) { return [x[0], '']; })); return res; }
    if (mode === 'root') { var k0 = wzKey(q) || (wzSearch(q, lang, 'auto').groups[0] || { ks: [] }).ks.map(function (x) { return x[0]; })[0]; if (!k0) { res.empty = 'Find the word first, then search its root.'; return res; } var r = wzRoot(k0), fam = wzFamily(k0); push('Word family of ' + r + ' (from Strong\'s derivation notes)', fam.map(function (x) { return [x, x === r ? 'source word' : '']; }), 'Words that come from the same source word. A shared origin does not mean a shared meaning: check each word\'s usage.'); return res; }
    var lw = q.toLowerCase();
    if (auto || mode === 'eng') { var E = EN[lw] || {}; push('The KJV renders “' + q + '” from these words', Object.keys(E).sort(function (a, b) { return E[b] - E[a]; }).map(function (k) { return [k, E[k] + '× as “' + lw + '”']; }), Object.keys(E).length > 1 ? 'One English word, ' + Object.keys(E).length + ' different original words. They are separate words with their own meanings; open each one.' : ''); }
    if (auto || mode === 'tr') { var tr = I.filter(function (x) { return x[2] && (x[2] === sq || (sq.length > 2 && x[2].indexOf(sq) === 0)); }).sort(byFreq).slice(0, 30); push('Transliteration', tr.map(function (x) { return [x[0], '']; })); }
    if (auto || mode === 'mean') { var rx = new RegExp('\\b' + lw.replace(/[^a-z ]/g, '') + '\\b'); if (lw.replace(/[^a-z]/g, '').length > 2) { var mm = I.filter(function (x) { return rx.test(x[3]); }).sort(byFreq).slice(0, 30); push('Definitions that mention “' + q + '”', mm.map(function (x) { return [x[0], '']; }), 'From the Strong\'s definitions, which is wider than how the KJV translates.'); } }
    if (!res.groups.length) res.empty = 'Nothing found for “' + q + '”. Try an English word from the KJV, a Strong\'s number (G26), a transliteration (agape), Hebrew or Greek script, or a verse (John 3:16).';
    return res;
  }
  function wzResHtml(R) {
    if (!R) return ''; if (R.empty) return '<p class="wzempty">' + esc(R.empty) + '</p>';
    return R.groups.map(function (g) { return '<section class="wzres"><h3>' + esc(g.title) + ' <small>' + g.ks.length + '</small></h3>' + (g.note ? '<p class="wzhint">' + esc(g.note) + '</p>' : '') + '<div class="wzlist">' + g.ks.map(function (x) { return wzItem(x[0], x[1], R.ref); }).join('') + '</div></section>'; }).join('');
  }
  function wzItem(k, note, ref) { var o = CI && CI[k], H = k[0] === 'H', st = WZ.words[k] && WZ.words[k].st; return '<button class="wzitem" data-act="wsopen" data-k="' + k + '"' + (ref ? ' data-r="' + esc(ref) + '"' : '') + '><span class="sc ' + (H ? 'hebw' : 'grk') + '" lang="' + (H ? 'he' : 'grc') + '">' + esc(wzScript(k) || k) + '</span><span class="tx"><b>' + esc(wzTr(k)) + ' <small>' + k + '</small>' + (st ? ' <i class="wzst">' + esc(st) + '</i>' : '') + '</b><span>' + esc(wzGloss(k)) + (note ? ' · ' + esc(note) : '') + '</span></span><span class="n">' + (o ? o.n.toLocaleString() + '<small>×</small>' : '') + '</span></button>'; }

  /* ---- dashboard ---- */
  function wzDash() {
    var tabs = [['home', 'Study'], ['browse', 'Browse'], ['an', 'Analytics'], ['let', 'Hebrew letters'], ['src', 'Sources']];
    var R = WV.q ? wzSearch(WV.q, WV.lang, WV.mode) : null;
    return '<div class="wzdash"><header class="wzdh"><button class="ib mobm" data-act="side" aria-label="Menu">' + ic('menu') + '</button><div><h1>Word Study</h1><p>Hebrew & Greek lab: find the word behind the English, then let Scripture show how it is used.</p></div></header>' +
      '<div class="wzsearch" role="search"><input id="wzq" value="' + esc(WV.q) + '" placeholder="love · G26 · agape · ἀγάπη · אהב · John 3:16" autocomplete="off" aria-label="Search for a word"><select id="wzl" aria-label="Language"><option value="all">Hebrew & Greek</option><option value="heb"' + (WV.lang === 'heb' ? ' selected' : '') + '>Hebrew (OT)</option><option value="grk"' + (WV.lang === 'grk' ? ' selected' : '') + '>Greek (NT)</option></select><select id="wzm" aria-label="Search by">' + [['auto', 'Anything'], ['eng', 'English word (KJV)'], ['strong', 'Strong\'s number'], ['tr', 'Transliteration'], ['heb', 'Hebrew script'], ['grk', 'Greek script'], ['ref', 'Scripture reference'], ['root', 'Root / word family'], ['mean', 'Meaning']].map(function (m) { return '<option value="' + m[0] + '"' + (WV.mode === m[0] ? ' selected' : '') + '>' + m[1] + '</option>'; }).join('') + '</select><button class="pri" data-act="wzsearch">Search</button></div>' +
      (R ? '<div class="wzresults">' + wzResHtml(R) + '<button class="wzclr" data-act="wzclear">Clear search</button></div>' :
        '<nav class="wztabs2" role="tablist">' + tabs.map(function (t) { return '<button role="tab" aria-selected="' + (WV.dash === t[0]) + '" class="' + (WV.dash === t[0] ? 'on' : '') + '" data-act="wzdash" data-v="' + t[0] + '">' + t[1] + '</button>'; }).join('') + '</nav>' + (WV.dash === 'browse' ? wzBrowse() : WV.dash === 'an' ? wzAnalytics() : WV.dash === 'let' ? wzLetters() : WV.dash === 'src' ? wzSources() : wzHome())) + '</div>';
  }
  function wzChapterWords(b, c, v1, v2) { // repeated meaningful Strong's numbers in a reading
    var B = KJV[b], cnt = {}, eng = {}; if (!B || !B[c]) return [];
    B[c].forEach(function (t, i) { if (!t || (v1 && (i + 1 < v1 || i + 1 > v2))) return; var re = /([^\s{}]+)((?:\{[HG]\d+\})+)/g, m; while ((m = re.exec(t))) m[2].match(/[HG]\d+/g).forEach(function (k) { var e = LEX[k]; if (!e || COMMON[k] || SKIPPOS.test(e[6] || '') || /Proper Name/i.test(e[6] || '')) return; cnt[k] = (cnt[k] || 0) + 1; eng[k] = eng[k] || m[1].replace(/[^\w'’-]/g, ''); }); });
    return Object.keys(cnt).filter(function (k) { return cnt[k] > 1; }).sort(function (a, b) { return cnt[b] - cnt[a]; }).slice(0, 10).map(function (k) { return [k, '“' + eng[k] + '” ×' + cnt[k] + ' here']; });
  }
  function wzPlanToday() { try { if (!RPD || !RP || !RP.plans) return null; var ids = Object.keys(RP.plans); for (var i = 0; i < ids.length; i++) { var p = getPlan(ids[i]); if (!p || RP.plans[ids[i]].paused) continue; var g = prog(p); if (!g || g.next == null) continue; return { p: p, d: g.next, us: dayUnits(p, g.next) }; } } catch (e) {} return null; }
  function wzHome() {
    var recent = [], seen = {}; for (var i = WZ.hist.length - 1; i >= 0 && recent.length < 8; i--) { var h = WZ.hist[i]; if (!seen[h.k]) { seen[h.k] = 1; recent.push([h.k, h.r ? 'from ' + h.r : '']); } }
    var saved = Object.keys(WZ.words).filter(function (k) { return WZ.words[k].st; }).sort(function (a, b) { return WZ.words[b].last - WZ.words[a].last; });
    var most = Object.keys(WZ.words).filter(function (k) { return WZ.words[k].views > 1; }).sort(function (a, b) { return WZ.words[b].views - WZ.words[a].views; }).slice(0, 6);
    var chap = wzChapterWords(cur.b, cur.c), plan = wzPlanToday(), pw = [];
    if (plan) plan.us.slice(0, 3).forEach(function (u) { wzChapterWords(u.b, u.c, u.v1, u.v2).slice(0, 5).forEach(function (x) { if (!pw.some(function (y) { return y[0] === x[0]; })) pw.push([x[0], x[1].replace(' here', ' in ' + u.b + ' ' + u.c)]); }); });
    var serm = []; try { (typeof SM !== 'undefined' ? SM.list : []).forEach(function (s) { (s.kw || []).forEach(function (w) { if (w.strong && !serm.some(function (x) { return x[0] === w.strong; })) serm.push([w.strong, 'in “' + ((s.f && s.f.title) || 'Untitled sermon') + '”']); }); }); } catch (e) {}
    var bk = WV.rb || cur.b, bkw = wzBookWords(bk);
    var sec = function (t, items, empty, more) { return '<section class="wzsec"><h2>' + t + '</h2>' + (more || '') + (items.length ? '<div class="wzlist">' + items.map(function (x) { return wzItem(x[0], x[1]); }).join('') + '</div>' : '<p class="wzempty">' + empty + '</p>') + '</section>'; };
    return (recent.length ? sec('Continue studying', recent, '') : '<p class="wzlead">Search above, or tap any word in the Bible reader and choose <b>Word study</b>. You can also start from a word in the chapter you are reading:</p>') +
      sec('Suggested from ' + esc(cur.b + ' ' + cur.c) + ' (where you are reading)', chap, 'No repeated key words in this chapter.') +
      (plan ? sec('From today\'s reading plan: ' + esc(plan.p.title) + ', day ' + (plan.d + 1), pw, 'No repeated key words in today\'s reading.') : '') +
      (saved.length ? sec('Saved words', saved.slice(0, 12).map(function (k) { return [k, WZ.words[k].st]; }), '') : '') +
      (serm.length ? sec('Words in your sermons', serm.slice(0, 10), '') : '') +
      (most.length ? sec('Most studied', most.map(function (k) { return [k, 'opened ' + WZ.words[k].views + '×']; }), '') : '') +
      sec('Repeated through a book', bkw, 'No data.', '<label class="wzinl">Book <select id="wzrb">' + BOOKS.filter(function (b) { return KJV[b]; }).map(function (b) { return '<option' + (b === bk ? ' selected' : '') + '>' + b + '</option>'; }).join('') + '</select></label>');
  }
  var WZBW = {};
  function wzBookWords(b) {
    if (WZBW[b]) return WZBW[b]; var B = KJV[b], cnt = {}, tot = {}; if (!B) return [];
    Object.keys(B).forEach(function (c) { B[c].forEach(function (t) { if (!t) return; (t.match(/\{[HG]\d+\}/g) || []).forEach(function (x) { var k = x.slice(1, -1), e = LEX[k]; if (!e || COMMON[k] || SKIPPOS.test(e[6] || '') || /Proper Name/i.test(e[6] || '')) return; cnt[k] = (cnt[k] || 0) + 1; }); }); });
    // weight by how concentrated the word is in this book compared with the whole Bible
    var L = Object.keys(cnt).filter(function (k) { return cnt[k] >= 4; }).map(function (k) { var all = CI && CI[k] ? CI[k].n : cnt[k]; return [k, cnt[k], cnt[k] * cnt[k] / all]; }).sort(function (a, b) { return b[2] - a[2]; }).slice(0, 12);
    return (WZBW[b] = L.map(function (x) { var all = CI && CI[x[0]] ? CI[x[0]].n : x[1]; return [x[0], x[1] + '× in ' + b + ' (' + Math.round(x[1] / all * 100) + '% of all uses)']; }));
  }
  function wzBrowse() {
    ensureCI(); var L = Object.keys(LEX).filter(function (k) { return (WV.bl === 'all' || k[0] === WV.bl) && CI && CI[k]; }).sort(function (a, b) { return CI[b].n - CI[a].n; }), P = 60, pg = WV.bp, n = Math.ceil(L.length / P);
    return '<section class="wzsec"><div class="wzrow"><h2>Vocabulary by frequency</h2><span class="sp"></span>' + [['all', 'All'], ['H', 'Hebrew'], ['G', 'Greek']].map(function (x) { return '<button class="chip' + (WV.bl === x[0] ? ' on' : '') + '" data-act="wzbl" data-v="' + x[0] + '">' + x[1] + '</button>'; }).join('') + '</div><p class="wzhint">' + L.length.toLocaleString() + ' words with tagged occurrences in the KJV, most frequent first.</p><div class="wzlist">' + L.slice(pg * P, pg * P + P).map(function (k) { return wzItem(k, ''); }).join('') + '</div><div class="wzpager"><button data-act="wzbp" data-d="-1"' + (pg ? '' : ' disabled') + '>Previous</button><span>Page ' + (pg + 1) + ' of ' + n + '</span><button data-act="wzbp" data-d="1"' + (pg < n - 1 ? '' : ' disabled') + '>Next</button></div></section>';
  }
  function wzDayKey(t) { var d = new Date(t); return d.getFullYear() + '-' + ('0' + (d.getMonth() + 1)).slice(-2) + '-' + ('0' + d.getDate()).slice(-2); }
  function wzAnalytics() {
    ensureCI(); var A = WV.an, keys = Object.keys(WZ.words).filter(function (k) { var w = WZ.words[k]; return (A.lang === 'all' || k[0] === A.lang) && (A.st === 'all' || (A.st === 'none' ? !w.st : w.st === A.st)); });
    var now = Date.now(), wk = now - 7 * 864e5, mo = now - 30 * 864e5, H = WZ.hist.filter(function (h) { return A.lang === 'all' || h.k[0] === A.lang; });
    var days = {}; H.forEach(function (h) { days[wzDayKey(h.t)] = (days[wzDayKey(h.t)] || 0) + 1; });
    var streak = 0, d = new Date(); if (!days[wzDayKey(d)]) d.setDate(d.getDate() - 1); while (days[wzDayKey(d)]) { streak++; d.setDate(d.getDate() - 1); }
    var uniq = function (arr) { var s = {}; arr.forEach(function (h) { s[h.k] = 1; }); return Object.keys(s).length; };
    var tile = function (n, l) { return '<div class="wztile"><b>' + n + '</b><small>' + l + '</small></div>'; };
    var act30 = []; for (var i = 29; i >= 0; i--) { var dd = new Date(now - i * 864e5), kk = wzDayKey(dd); act30.push([dd.getDate() + '/' + (dd.getMonth() + 1), days[kk] || 0]); }
    var st = {}; keys.forEach(function (k) { var s = WZ.words[k].st || 'No status'; st[s] = (st[s] || 0) + 1; });
    var books = {}; keys.forEach(function (k) { var o = CI && CI[k]; if (o) Object.keys(o.ch).forEach(function (x) { var b = x.split('|')[0]; books[b] = (books[b] || 0) + o.ch[x]; }); });
    var top = Object.keys(CI || {}).filter(function (k) { return (A.lang === 'all' || k[0] === A.lang) && (!A.hide || (!COMMON[k] && LEX[k] && !SKIPPOS.test(LEX[k][6] || ''))); }).sort(function (a, b) { return CI[b].n - CI[a].n; }).slice(0, 15);
    wzFam(); var fams = Object.keys(WZCHD).filter(function (k) { return (A.lang === 'all' || k[0] === A.lang) && !WZPA[k]; }).map(function (k) { return [k, wzFamily(k).length]; }).sort(function (a, b) { return b[1] - a[1]; }).slice(0, 10);
    var sel = function (id, cur0, opts) { return '<select id="' + id + '">' + opts.map(function (o) { return '<option value="' + o[0] + '"' + (cur0 === o[0] ? ' selected' : '') + '>' + o[1] + '</option>'; }).join('') + '</select>'; };
    return '<div class="wzrow wzfilters">' + sel('wzanl', A.lang, [['all', 'Hebrew & Greek'], ['H', 'Hebrew'], ['G', 'Greek']]) + sel('wzans', A.st, [['all', 'Any status'], ['none', 'No status']].concat(WZST.map(function (s) { return [s, s]; }))) + '</div>' +
      '<section class="wzsec"><h2>Your study</h2><div class="wztiles">' + tile(keys.length, 'words studied') + tile(keys.filter(function (k) { return k[0] === 'H'; }).length, 'Hebrew') + tile(keys.filter(function (k) { return k[0] === 'G'; }).length, 'Greek') + tile(uniq(H.filter(function (h) { return h.t > wk; })), 'this week') + tile(uniq(H.filter(function (h) { return h.t > mo; })), 'last 30 days') + tile(streak + (streak === 1 ? ' day' : ' days'), 'study streak') + tile(keys.filter(function (k) { return WZ.words[k].st; }).length, 'saved') + tile(keys.filter(function (k) { return WZ.words[k].st === 'Studied'; }).length, 'completed') + tile(keys.filter(function (k) { return WZ.words[k].st === 'To study'; }).length, 'waiting to study') + '</div>' +
      (keys.length ? '<div class="wzgrid2"><div><h3>Study activity, last 30 days</h3><div class="wzcols" role="img" aria-label="Words opened per day over the last 30 days">' + act30.map(function (x) { var mx = Math.max(1, Math.max.apply(null, act30.map(function (y) { return y[1]; }))); return '<span title="' + x[0] + ': ' + x[1] + '"><i style="height:' + (x[1] / mx * 100) + '%"></i></span>'; }).join('') + '</div><small class="dim">Each bar is a day; height is how many words you opened.</small></div>' +
        '<div><h3>Hebrew and Greek</h3>' + wzBars([['Hebrew', keys.filter(function (k) { return k[0] === 'H'; }).length], ['Greek', keys.filter(function (k) { return k[0] === 'G'; }).length]]) + '<h3>By status</h3>' + wzBars(Object.keys(st).map(function (s) { return [esc(s), st[s]]; })) + '</div>' +
        '<div><h3>Most studied</h3>' + wzBars(keys.sort(function (a, b) { return WZ.words[b].views - WZ.words[a].views; }).slice(0, 8).map(function (k) { return [esc(wzTr(k)) + ' <small>' + k + '</small>', WZ.words[k].views, { a: 'wsopen', k: k }]; })) + '</div>' +
        '<div><h3>Where your words occur</h3><small class="dim">Occurrences of your studied words, by book</small>' + wzBars(Object.keys(books).sort(function (a, b) { return books[b] - books[a]; }).slice(0, 8).map(function (b) { return [esc(b), books[b]]; })) + '</div></div>' : '<p class="wzempty">Open a word to start your study record.</p>') + '</section>' +
      '<section class="wzsec"><div class="wzrow"><h2>Across Scripture</h2><span class="sp"></span><label class="wzinl"><input type="checkbox" id="wzanh"' + (A.hide ? ' checked' : '') + '> Hide particles and small words</label></div><div class="wzgrid2"><div><h3>Most frequent words</h3><small class="dim">Tagged occurrences in the KJV</small>' + wzBars(top.map(function (k) { return ['<span class="' + (k[0] === 'H' ? 'hebw' : 'grk') + '">' + esc(wzScript(k)) + '</span> ' + esc(wzTr(k)) + ' <small>' + k + '</small>', CI[k].n, { a: 'wsopen', k: k }]; })) + '</div>' +
      '<div><h3>Largest word families</h3><small class="dim">Words traced to one source word in Strong\'s notes</small>' + wzBars(fams.map(function (x) { return [esc(wzTr(x[0])) + ' <small>' + x[0] + '</small>', x[1], { a: 'wsopen', k: x[0] }]; })) + '</div></div></section>';
  }
  function wzFirstLetter(h) { var s = (h || '').replace(/[֑-ׇ־\/]/g, ''); var m = /[א-ת]/.exec(s); return m ? (FINAL[m[0]] || m[0]) : ''; }
  function wzLetters() {
    var L = WV.letter, P = wzHBP(); if (!HB) { loadHB(); }
    var grid = '<div class="wzlet">' + HLET.map(function (x, i) { return '<button class="' + (L === i ? 'on' : '') + '" data-act="wzlet" data-i="' + i + '" aria-label="' + x[1] + '"><b lang="he">' + x[0] + (x[3] ? ' ' + x[3] : '') + '</b><span>' + x[1] + '</span><small>' + (i + 1) + '</small></button>'; }).join('') + '</div>';
    var det = '';
    if (L != null) {
      var x = HLET[L], ws = Object.keys(LEX).filter(function (k) { return k[0] === 'H' && wzFirstLetter(LEX[k][0]) === x[0]; }), top = ws.filter(function (k) { return CI && CI[k]; }).sort(function (a, b) { return CI[b].n - CI[a].n; }).slice(0, 18);
      var ps = '';
      if (P && HB.d.Psalms && HB.d.Psalms[119]) { var v1 = L * 8 + 1, vs = []; for (var v = v1; v < v1 + 8; v++) { var ix = HB.d.Psalms[119][v] || []; if (ix.length) vs.push([v, P[ix[0]][0], wzFirstLetter(P[ix[0]][0])]); } ps = '<h3>Psalm 119:' + v1 + '–' + (v1 + 7) + ', the ' + x[1] + ' section</h3><p class="wzhint">The opening word of each verse in the Hebrew text (Hebrew verse numbers).</p><div class="wzacro">' + vs.map(function (y) { return '<span class="' + (y[2] === x[0] ? 'ok' : '') + '"><small>' + y[0] + '</small><b lang="he">' + esc(y[1]) + '</b></span>'; }).join('') + '</div>'; }
      det = '<section class="wzsec"><h2><span lang="he" class="hebw">' + x[0] + '</span> ' + x[1] + '</h2><p>Letter ' + (L + 1) + ' of 22 · pronounced ' + esc(x[2]) + (x[3] ? ' · final form <span lang="he" class="hebw">' + x[3] + '</span>' : '') + ' · ' + ws.length.toLocaleString() + ' dictionary words begin with it.</p><h3>Most frequent words beginning with ' + x[1] + '</h3><div class="wzlist">' + top.map(function (k) { return wzItem(k, ''); }).join('') + '</div>' + ps + '</section>';
    }
    var A = WV.acro, ac = '';
    if (A != null && P) {
      var bc = ACRO[A], B = (HB.d[bc[0]] || {})[bc[1]] || {}, exp = 0, rows = [];
      var multi = (bc[0] === 'Psalms' && bc[1] === 119) || (bc[0] === 'Lamentations' && bc[1] === 3), v0s = bc[2] || 1;
      Object.keys(B).map(Number).sort(function (a, b) { return a - b; }).forEach(function (v) { var ix = B[v]; if (!ix || !ix.length || v < v0s) return; var f = wzFirstLetter(P[ix[0]][0]), want = HLET[exp] ? HLET[exp][0] : '', nxt = HLET[exp + 1] ? HLET[exp + 1][0] : '', ok = false; if (f === want) ok = true; else if (f === nxt) { exp++; ok = true; } rows.push([v, f, ok, P[ix[0]][0]]); if (ok && !multi) exp++; });
      var okN = rows.filter(function (r) { return r[2]; }).length;
      ac = '<div class="wzacrob"><p class="wzhint">The first letter of each verse in ' + bc[0] + ' ' + bc[1] + ' (Hebrew text and verse numbers). Letters that continue the alphabet in order are marked. ' + okN + ' of ' + rows.length + ' verses follow the sequence; a title verse, a skipped letter or a different arrangement shows up here as a break.</p><div class="wzacro">' + rows.map(function (r) { return '<span class="' + (r[2] ? 'ok' : '') + '" title="' + esc(r[3]) + '"><small>' + r[0] + '</small><b lang="he">' + (r[1] || '–') + '</b></span>'; }).join('') + '</div></div>';
    }
    return grid + det + '<section class="wzsec"><h2>Alphabet acrostics</h2><p class="wzhint">Poems whose verses (or groups of verses) begin with the letters of the alphabet in order. Choose one to check it against the Hebrew text.</p><div class="wzchips">' + ACRO.map(function (a, i) { return '<button class="chip' + (A === i ? ' on' : '') + '" data-act="wzacro" data-i="' + i + '">' + (a[0] === 'Psalms' ? 'Psalm' : a[0]) + ' ' + a[1] + '</button>'; }).join('') + '</div>' + (HB ? ac : '<p class="wzempty">Loading the Hebrew text…</p>') + '</section>' +
      '<section class="wzsec wznote"><h2>About letter meanings</h2><p>Each letter has a name, a sound and a place in the alphabet; that is the linguistic evidence. Popular teaching that gives each letter a picture meaning (for example, that a word "means" the sum of its letters\' pictures) comes from theories about ancient letter shapes. Scholars do not accept it as a way to find what Hebrew words mean, so this lab does not use it. A word\'s meaning is shown by how Scripture uses it.</p></section>';
  }
  function wzSources() {
    var row = function (n, l, c, lim) { return '<tr><th>' + n + '</th><td>' + l + '</td><td>' + c + '</td><td>' + lim + '</td></tr>'; };
    return '<section class="wzsec"><h2>Data used by the Word Study lab</h2><p class="wzhint">Everything the lab shows is counted from the data below, already inside your Bible app. Nothing is filled in to make up for missing data.</p><div class="wztbl"><table><thead><tr><th>Data</th><th>Source and licence</th><th>Coverage</th><th>Limitations</th></tr></thead><tbody>' +
      row('KJV with Strong\'s numbers', 'King James Version with Strong\'s numbering of each translated word. Public domain.', 'All 66 books; each tagged English word or phrase is linked to its Hebrew or Greek number.', 'Tagging follows the KJV\'s English. A number may cover a phrase, some words have two numbers, and some original words are untagged. Occurrence counts are counts of tags, so they can differ slightly from counts in the Hebrew or Greek text.') +
      row('Strong\'s dictionary', 'James Strong, Exhaustive Concordance (1890). Public domain.', '14,197 entries (Hebrew H1–H8674, Greek G1–G5624): word, transliteration, definition, KJV renderings, derivation.', 'Strong\'s is a 19th-century concordance dictionary, not a modern lexicon. Its derivations are sometimes disputed. The short glosses and part-of-speech labels in this app\'s copy come from an added source that the app does not name, so treat them as a guide.') +
      row('Hebrew Bible with morphology', 'Hebrew text with word-by-word morphology codes in the format of the Open Scripture Hebrew Bible (Westminster Leningrad Codex: public domain; OSHB morphology: CC BY 4.0, openscriptures.org).', 'Old Testament: every word with its Strong\'s number, prefixes, part of speech, stem, form, person, gender and number.', 'Hebrew verse numbers sometimes differ from English; the app maps between them. Aramaic sections use the same codes.') +
      row('Other English versions', 'ASV, WEB (public domain), NET, Geneva, Bishops\', Coverdale, as installed in your library.', 'Full verses for comparison.', 'Not tagged with Strong\'s numbers, so the lab shows the whole verse and does not guess which English word matches.') +
      '</tbody></table></div><h3>Not available yet</h3><ul class="wzul"><li><b>Greek morphology</b> (tense, voice, mood, case for each New Testament word). The app has no Greek parsing data, so the lab shows Greek part of speech only. A tagged Greek text, such as the CC BY-SA MorphGNT edition of the SBL Greek New Testament, can be added later.</li><li><b>Septuagint</b> (the Greek Old Testament). Not included, so Hebrew–Greek links are shown only where the KJV uses the same English word.</li><li><b>Audio pronunciation.</b> No reliable recordings are included; the transliteration and, where Strong\'s gives one, the phonetic spelling are shown instead.</li><li><b>Modern lexicons</b> (BDAG, HALOT, BDB). These are copyrighted and are not copied here. Use the links on each word to open them where you have access.</li></ul><h3>External tools linked from each word</h3><p class="wzhint">Bible Hub, Blue Letter Bible and STEP Bible (Tyndale House, Cambridge). Each link opens that site\'s page for the word you are studying.</p></section>';
  }
  function wzLinks(k) { var n = +k.slice(1), H = k[0] === 'H'; return '<div class="wzlinks"><a href="https://biblehub.com/' + (H ? 'hebrew' : 'greek') + '/' + n + '.htm" target="_blank" rel="noopener">Bible Hub: ' + k + '</a><a href="https://www.blueletterbible.org/lexicon/' + k.toLowerCase() + '/kjv/' + (H ? 'wlc' : 'tr') + '/0-1/" target="_blank" rel="noopener">Blue Letter Bible: ' + k + '</a><a href="https://www.stepbible.org/?q=strong=' + k[0] + ('000' + n).slice(-4) + '" target="_blank" rel="noopener">STEP Bible: ' + k + '</a></div>'; }

  /* ---- word page ---- */
  function wzPage() {
    var k = WV.k; ensureCI(); var e = wzE(k), o = CI && CI[k];
    if (!e && !o) return '<div class="wzdash"><p class="wzempty">There is no entry for ' + esc(k) + '. <a data-act="wzhome">Back to Word Study</a></p></div>';
    if (k[0] === 'H' && !HB) loadHB();
    var rec = WZ.words[k] || wzW(k), H = k[0] === 'H', i = WZTABS.findIndex(function (t) { return t[0] === WV.tab; }); if (i < 0) i = 0;
    var body = { ov: wzOv, mean: wzMean, gram: wzGram, ctx: wzCtx, occ: wzOccTab, cmp: wzCmp, con: wzCon, theo: wzTheo, notes: wzNotes, rep: wzRep }[WZTABS[i][0]](k, rec);
    return '<div class="wzpage"><header class="wzph"><button class="ib mobm" data-act="side" aria-label="Menu">' + ic('menu') + '</button><a data-act="wzhome">' + ic('back', 14) + ' Word Study</a>' + (WV.r ? '<a data-act="wzgo" data-r="' + esc(WV.r) + '">' + ic('book', 14) + ' Back to ' + esc(WV.r) + '</a>' : '') + '<span class="sp"></span><label class="wzinl">Status <select id="wzst"><option value="">None</option>' + WZST.map(function (s) { return '<option' + (rec.st === s ? ' selected' : '') + '>' + s + '</option>'; }).join('') + '</select></label><button class="' + (WV.ask ? 'pri' : '') + '" data-act="wzask" aria-pressed="' + !!WV.ask + '">' + ic('spark', 14) + ' Ask</button><button data-act="slpinw" data-k="' + k + '" title="Pin to your Study Lab workbench">' + ic('bookmark', 14) + ' Workbench</button></header>' +
      '<div class="wzhero"><div class="wzscript ' + (H ? 'hebw' : 'grk') + '" lang="' + (H ? 'he' : 'grc') + '" dir="' + (H ? 'rtl' : 'ltr') + '">' + esc(wzScript(k)) + '</div><div class="wzid"><h1>' + esc(wzTr(k)) + '</h1><p><b>' + k + '</b> · ' + wzLang(k) + (wzPos(k) ? ' · ' + esc(wzPos(k)) : '') + (o ? ' · ' + o.n.toLocaleString() + ' occurrences' : '') + '</p><p class="wzgl">' + esc(wzGloss(k)) + '</p></div><div class="wznav2"><button class="ib" data-act="wzstep" data-d="-1" aria-label="Previous Strong\'s number" title="' + k[0] + (+k.slice(1) - 1) + '">' + ic('cl', 16) + '</button><button class="ib" data-act="wzstep" data-d="1" aria-label="Next Strong\'s number" title="' + k[0] + (+k.slice(1) + 1) + '">' + ic('cr', 16) + '</button></div></div>' +
      '<nav class="wztabs" role="tablist" aria-label="Study steps">' + WZTABS.map(function (t, j) { return '<button role="tab" aria-selected="' + (j === i) + '" class="' + (j === i ? 'on' : '') + '" data-act="wztab" data-v="' + t[0] + '"><small>' + (j + 1) + '</small>' + t[1] + '</button>'; }).join('') + '</nav>' +
      (WV.ask ? wzAsk(k, rec) : '') + '<section class="wzbody" aria-label="' + WZTABS[i][1] + '"><p class="wzstepn">Step ' + (i + 1) + ' of 10 · ' + WZTABS[i][2] + '</p>' + body + '<div class="wzpager2">' + (i > 0 ? '<button data-act="wztab" data-v="' + WZTABS[i - 1][0] + '">' + ic('cl', 13) + ' ' + WZTABS[i - 1][1] + '</button>' : '<span></span>') + (i < 9 ? '<button class="pri" data-act="wztab" data-v="' + WZTABS[i + 1][0] + '">' + WZTABS[i + 1][1] + ' ' + ic('cr', 13) + '</button>' : '') + '</div></section></div>';
  }
  function wzHereCard(k) {
    var r = WV.r && wzSplitRef(WV.r); if (!r) return '';
    var t = KJV[r.b] && KJV[r.b][r.c] && KJV[r.b][r.c][r.v - 1]; if (!t || t.indexOf('{' + k + '}') < 0) return '<div class="wzcard"><small>You came from ' + esc(WV.r) + '</small><p>' + esc(k) + ' does not occur in that verse.</p></div>';
    var row = wzRow(r.b, r.c, r.v, t, k, BOOKS.indexOf(r.b)), hb = k[0] === 'H' ? wzHebAt(r.b, r.c, r.v, k) : [];
    var others = []; row.w.forEach(function (w) { var E = EN[w] || {}; Object.keys(E).forEach(function (x) { if (x !== k && others.indexOf(x) < 0) others.push(x); }); });
    return '<div class="wzcard here"><small>In ' + esc(WV.r) + '</small><p class="wzv">' + wzVerseHtml(t, k) + '</p><dl class="wzdl"><dt>English (KJV)</dt><dd>' + row.ph.map(function (x) { return '“' + esc(x) + '”'; }).join(', ') + '</dd>' +
      (hb.length ? '<dt>Hebrew here</dt><dd>' + hb.map(function (h) { return '<span class="hebw" lang="he" dir="rtl">' + esc(h.h) + '</span> <span class="wzmo">' + esc(morph(h.mo)) + (h.pre ? ' · with prefix: ' + h.pre.split('').map(function (x) { return PRE[x] || x; }).join(', ') : '') + '</span>'; }).join('<br>') + '</dd>' : k[0] === 'G' ? '<dt>Greek form here</dt><dd class="dim">Not available: the app has no Greek parsing data yet.</dd>' : '') + '</dl>' +
      (others.length ? '<p class="wzhint">The KJV uses the same English word for ' + others.length + ' other original word' + (others.length > 1 ? 's' : '') + ': ' + others.slice(0, 8).map(function (x) { return wzA(x); }).join(', ') + (others.length > 8 ? '…' : '') + '. In this verse it is ' + k + '.</p>' : '') + '</div>';
  }
  function wzOv(k, rec) {
    var e = wzE(k) || [], o = CI && CI[k], L = wzOcc(k), bc = wzBookCounts(L), r = wzRoot(k), hs = k[0] === 'H' ? wzHebStats(k) : null, ph = wzPhon(k);
    var stTop = hs && Object.keys(hs.stems).sort(function (a, b) { return hs.stems[b] - hs.stems[a]; });
    return wzHereCard(k) + '<dl class="wzfacts"><div><dt>Original</dt><dd><span class="' + (k[0] === 'H' ? 'hebw' : 'grk') + ' big" lang="' + (k[0] === 'H' ? 'he' : 'grc') + '">' + esc(e[0] || wzScript(k)) + '</span></dd></div><div><dt>Transliteration</dt><dd>' + esc(e[1] || '') + '</dd></div>' + (ph ? '<div><dt>Pronunciation (Strong\'s)</dt><dd>' + esc(ph) + '</dd></div>' : '') + '<div><dt>Strong\'s number</dt><dd>' + k + '</dd></div><div><dt>Language</dt><dd>' + wzLang(k) + '</dd></div><div><dt>Part of speech</dt><dd>' + (esc(wzPos(k)) || '<span class="dim">Not recorded</span>') + '</dd></div>' +
      '<div><dt>Source word (Strong\'s)</dt><dd>' + (r !== k ? wzA(r) + esc(wzHedge(k)) : 'None given (Strong\'s treats it as a primary word or gives no number)') + '</dd></div><div><dt>Occurrences (KJV tagging)</dt><dd>' + (o ? o.n.toLocaleString() + ' in ' + L.length.toLocaleString() + ' verses' : '0') + '</dd></div>' + (hs ? '<div><dt>In the Hebrew text</dt><dd>' + hs.n.toLocaleString() + ' times' + (stTop.length ? ' · mostly ' + stTop[0] : '') + '</dd></div>' : '') + '<div><dt>Books</dt><dd>' + Object.keys(bc).length + '</dd></div><div><dt>English renderings</dt><dd>' + wzRend(k).length + '</dd></div></dl>' +
      '<div class="wzcard"><small>Strong\'s definition</small><p>' + esc(e[3] || '—') + '</p></div>' +
      '<h3>How to study this word</h3><ol class="wzflow">' + [['ov', 'Find and identify the word'], ['mean', 'Understand its meaning and range'], ['gram', 'Look at its form'], ['ctx', 'Read it in context'], ['occ', 'Trace it through Scripture'], ['cmp', 'Compare how it is used and translated'], ['con', 'Explore related words'], ['theo', 'Ask what the evidence supports'], ['notes', 'Record your discovery'], ['rep', 'Build a report or add it to a sermon']].map(function (x, j) { return '<li><a data-act="wztab" data-v="' + x[0] + '"><b>' + (j + 1) + '</b> ' + x[1] + '</a></li>'; }).join('') + '</ol>' + '<h3>Further study</h3>' + wzLinks(k);
  }
  function wzMean(k, rec) {
    var e = wzE(k) || [], R = wzRend(k), o = CI && CI[k], lnk = function (t) { return esc(t || '').replace(/\b(\d{1,4})\b/g, function (m, n) { return LEX[k[0] + n] ? '<a class="wzk" data-act="wsopen" data-k="' + k[0] + n + '">' + n + '</a>' : n; }); };
    var ta = function (f, l, h) { return '<label class="smf"><span class="sml">' + l + '</span>' + (h ? '<small>' + h + '</small>' : '') + '<textarea data-wzn="' + f + '" rows="2">' + esc(rec.n[f] || '') + '</textarea></label>'; };
    return '<div class="wzgrid2"><div class="wzcard"><small>Core meaning (Strong\'s)</small><p>' + lnk(e[3]) + '</p>' + (e[7] ? '<small>Short gloss</small><p>' + esc(e[7]) + '</p>' : '') + '</div><div class="wzcard"><small>Where it comes from (Strong\'s)</small><p>' + (lnk(e[5]) || '—') + '</p><small>KJV renderings listed by Strong\'s</small><p>' + lnk(e[4]) + '</p></div></div>' +
      '<h3>Range of meaning: how the KJV actually translates it</h3><p class="wzhint">The clearest evidence of a word\'s range is how it is translated in different contexts. Tap a rendering to see those verses.</p>' + wzBars(R.slice(0, 14).map(function (x) { return ['“' + esc(x[0]) + '”' + (o.wv[x[0]] ? ' <small>e.g. ' + o.wv[x[0]].join(', ') + '</small>' : ''), x[1], { a: 'wzrend', w: x[0] }]; })) + (R.length > 14 ? '<p class="dim small">and ' + (R.length - 14) + ' more renderings</p>' : '') +
      '<div class="wzwarn"><b>Reading the evidence well</b><ul><li><b>Usage decides meaning.</b> Where a word came from (its root or derivation) shows its history, not what it means in a given verse.</li><li><b>One meaning per occurrence.</b> A word does not carry all its possible meanings into every verse; the context selects one.</li><li><b>English can hide or merge words.</b> The KJV may use one English word for several originals, or several English words for one.</li></ul></div>' +
      '<h3>Your lexical analysis</h3>' + ta('lit', 'Literal or basic sense', 'Where linguistically appropriate') + ta('fig', 'Figurative, idiomatic or specialised uses', 'With the verses that show it') + ta('range', 'Boundaries of the meaning', 'What it can mean, what it does not mean, and where context changes it') + ta('dev', 'Relation to its root and related forms', 'Without assuming related words mean the same') + ta('trd', 'Translation differences', 'Why translators choose different words; what nuance English loses');
  }
  function wzGram(k) {
    var H = k[0] === 'H', pos = wzPos(k);
    if (!H) return '<div class="wzcard"><small>Part of speech</small><p>' + (esc(pos) || 'Not recorded') + '</p></div><div class="wzwarn"><b>Greek forms are not available yet</b><p>The app has no Greek parsing data, so it cannot show the tense, voice, mood, case, gender or number of each New Testament occurrence, and it will not guess. When a tagged Greek text is added, each occurrence will show its form here.</p></div>' +
      '<h3>Reading Greek verb forms responsibly</h3><ul class="wzul"><li><b>Aspect, not just time.</b> Greek "tenses" mainly show how the writer presents an action (as a whole, as in progress, or as a completed state). Time comes mostly from context.</li><li><b>The aorist is not "once for all" by itself.</b> It presents an action as a whole; whether it was a single event depends on the context.</li><li><b>The present is not always "continuous".</b> It presents the action as in progress or general; context decides how far to press that.</li><li><b>The perfect</b> usually presents a completed action with a continuing result, a nuance often worth noting.</li></ul>';
    var hs = wzHebStats(k); if (!hs) return '<p class="wzempty">Loading the Hebrew text…</p>';
    var st = Object.keys(hs.stems).sort(function (a, b) { return hs.stems[b] - hs.stems[a]; }), fm = Object.keys(hs.forms).sort(function (a, b) { return hs.forms[b] - hs.forms[a]; }), sf = Object.keys(hs.surf).sort(function (a, b) { return hs.surf[b] - hs.surf[a]; });
    var here = WV.r && wzSplitRef(WV.r), hh = here ? wzHebAt(here.b, here.c, here.v, k) : [];
    return '<div class="wzcard"><small>Part of speech (dictionary)</small><p>' + (esc(pos) || 'Not recorded') + '</p>' + (hh.length ? '<small>Form in ' + esc(WV.r) + '</small><p><span class="hebw" lang="he">' + esc(hh[0].h) + '</span> ' + esc(morph(hh[0].mo)) + '</p>' + (wzStemOf(hh[0].mo) && WZSTEM[wzStemOf(hh[0].mo)] ? '<p class="wzhint"><b>' + wzStemOf(hh[0].mo) + '</b>: ' + WZSTEM[wzStemOf(hh[0].mo)] + ' Check the context before drawing a conclusion from the stem.</p>' : '') : '') + '</div>' +
      (st.length ? '<h3>Stems (binyanim) across the Hebrew Bible</h3><p class="wzhint">Counted from the morphology of all ' + hs.n.toLocaleString() + ' occurrences. A stem describes grammatical function; it does not carry a theological meaning by itself.</p>' + wzBars(st.map(function (s) { return [s, hs.stems[s]]; })) + '<ul class="wzul">' + st.filter(function (s) { return WZSTEM[s]; }).map(function (s) { return '<li><b>' + s + '</b>: ' + WZSTEM[s] + '</li>'; }).join('') + '</ul>' : '') +
      '<h3>Forms</h3>' + wzBars(fm.slice(0, 12).map(function (f) { return [esc(f), hs.forms[f]]; })) + '<h3>Spellings in the text</h3><div class="wzchips">' + sf.slice(0, 24).map(function (s) { return '<span class="chip"><span class="hebw" lang="he">' + esc(s) + '</span> ×' + hs.surf[s] + '</span>'; }).join('') + '</div><p class="wzhint">Spellings include prefixes and suffixes attached in the Hebrew text.</p>';
  }
  function wzCtx(k, rec) {
    var L = wzOcc(k); if (!L.length) return '<p class="wzempty">No occurrences to show.</p>';
    var i = Math.max(0, L.findIndex(function (x) { return x.r === WV.r; })), x = L[i], full = WV.exp.ctx, B = KJV[x.b][x.c], a = full ? 1 : Math.max(1, x.v - 3), z = full ? B.length : Math.min(B.length, x.v + 3);
    var cm = rec.cm[x.r] || {}, hb = k[0] === 'H' ? wzHebAt(x.b, x.c, x.v, k) : [];
    var vs = []; for (var v = a; v <= z; v++) { var t = B[v - 1]; if (t) vs.push('<p class="' + (v === x.v ? 'cur' : '') + '"><sup>' + v + '</sup> ' + (v === x.v || t.indexOf('{' + k + '}') >= 0 ? wzVerseHtml(t, k) : esc(plain(t))) + '</p>'); }
    var bi = BOOKS.indexOf(x.b);
    return '<div class="wzrow"><button data-act="wzocc" data-i="' + (i - 1) + '"' + (i ? '' : ' disabled') + '>' + ic('cl', 13) + ' Previous occurrence</button><b class="wzctr">' + esc(x.r) + ' <small>' + (i + 1) + ' of ' + L.length + '</small></b><button data-act="wzocc" data-i="' + (i + 1) + '"' + (i < L.length - 1 ? '' : ' disabled') + '>Next occurrence ' + ic('cr', 13) + '</button></div>' +
      '<p class="wzhint">' + esc(x.b) + ' · ' + esc(wzGroup(x.b)) + ' · ' + (bi < 39 ? 'Old' : 'New') + ' Testament · chapter ' + x.c + ' of ' + Object.keys(KJV[x.b]).length + '</p>' +
      '<div class="wzpass">' + vs.join('') + '</div><div class="wzrow"><button data-act="wzexp" data-v="ctx">' + (full ? 'Show nearby verses only' : 'Show the whole chapter') + '</button><button data-act="wzgo" data-r="' + esc(x.r) + '">' + ic('book', 13) + ' Open in the reader</button></div>' +
      '<dl class="wzdl"><dt>English here</dt><dd>' + x.ph.map(function (p) { return '“' + esc(p) + '”'; }).join(', ') + '</dd>' + (hb.length ? '<dt>Hebrew here</dt><dd>' + hb.map(function (h) { return '<span class="hebw" lang="he">' + esc(h.h) + '</span> <span class="wzmo">' + esc(morph(h.mo)) + '</span>'; }).join('<br>') + '</dd>' : '') + '</dl>' +
      '<label class="smf"><span class="sml">What does it mean here?</span><small>Let the surrounding verses decide. This is saved with this occurrence and appears in Compare.</small><textarea data-wzcm="' + esc(x.r) + '" data-f="mean" rows="3">' + esc(cm.mean || '') + '</textarea></label>' +
      '<label class="smf"><span class="sml">What in the context shows this?</span><textarea data-wzcm="' + esc(x.r) + '" data-f="why" rows="2">' + esc(cm.why || '') + '</textarea></label>';
  }
  function wzFiltered(k) {
    var L = wzOcc(k), f = WV.of, q = (f.s || '').toLowerCase(), rec = WZ.words[k];
    var out = L.filter(function (x) { return (f.t === 'all' || (f.t === 'ot') === x.ot) && (!f.b || x.b === f.b) && (!f.g || wzGroup(x.b) === f.g) && (!f.w || x.w.indexOf(f.w) >= 0) && (!f.sv || (rec && rec.oc[x.r] && rec.oc[x.r].s)) && (!q || plain(x.t).toLowerCase().indexOf(q) >= 0 || x.r.toLowerCase().indexOf(q) >= 0); });
    if (f.sort === 'rend') out = out.slice().sort(function (a, b) { return (a.w[0] || '').localeCompare(b.w[0] || '') || a.bi - b.bi; });
    else if (f.sort === 'book') { var bc = wzBookCounts(L); out = out.slice().sort(function (a, b) { return bc[b.b] - bc[a.b] || a.bi - b.bi; }); }
    return out;
  }
  function wzOccTab(k, rec) {
    var L = wzOcc(k), F = wzFiltered(k), f = WV.of, P = 40, pg = Math.min(f.p, Math.max(0, Math.ceil(F.length / P) - 1)), bc = wzBookCounts(L), books = BOOKS.filter(function (b) { return bc[b]; });
    var ot = 0, nt = 0, grp = {}; L.forEach(function (x) { if (x.ot) ot += x.n; else nt += x.n; var g = wzGroup(x.b); grp[g] = (grp[g] || 0) + x.n; });
    var chap = ''; if (f.b) { var cc = {}; L.filter(function (x) { return x.b === f.b; }).forEach(function (x) { cc[x.c] = (cc[x.c] || 0) + x.n; }); var nch = Object.keys(KJV[f.b]).length, mx = Math.max.apply(null, Object.keys(cc).map(function (c) { return cc[c]; })); chap = '<h3>By chapter in ' + esc(f.b) + '</h3><div class="wzheat" role="img" aria-label="Occurrences per chapter">' + Array.from({ length: nch }, function (_, j) { var n = cc[j + 1] || 0; return '<span style="--a:' + (n ? 0.2 + 0.8 * n / mx : 0) + '" title="Chapter ' + (j + 1) + ': ' + n + '">' + (j + 1) + '</span>'; }).join('') + '</div>'; }
    var hb = k[0] === 'H' && HB;
    var rows = F.slice(pg * P, pg * P + P).map(function (x) { var oc = rec.oc[x.r] || {}, sel = WV.sel.indexOf(x.r) >= 0, h = hb ? wzHebAt(x.b, x.c, x.v, k) : [], ex = WV.exp[x.r];
      var ctx = ''; if (ex) { var B = KJV[x.b][x.c]; for (var v = Math.max(1, x.v - 2); v <= Math.min(B.length, x.v + 2); v++) if (v !== x.v && B[v - 1]) ctx += '<p class="dim"><sup>' + v + '</sup> ' + esc(plain(B[v - 1])) + '</p>'; }
      return '<li class="wzoc' + (oc.s ? ' saved' : '') + '"><div class="wzoch"><a data-act="wzgo" data-r="' + esc(x.r) + '"><b>' + esc(x.r) + '</b></a><span class="wzren">“' + esc(x.ph.join('”, “')) + '”</span>' + (h.length ? '<span class="hebw" lang="he">' + esc(h[0].h) + '</span><span class="wzmo">' + esc(morph(h[0].mo)) + '</span>' : '') + '<span class="sp"></span><button class="ib" data-act="wzsave" data-r="' + esc(x.r) + '" aria-pressed="' + !!oc.s + '" title="' + (oc.s ? 'Saved' : 'Save this occurrence') + '">' + (oc.s ? '★' : '☆') + '</button><label class="wzck" title="Add to Compare"><input type="checkbox" data-wzsel="' + esc(x.r) + '"' + (sel ? ' checked' : '') + '> Compare</label></div>' +
        (ex && ctx ? '<div class="wzocx">' + ctx + '</div>' : '') + '<p class="wzv">' + wzVerseHtml(x.t, k) + '</p><div class="wzrow small"><button class="lnk" data-act="wzexp" data-v="' + esc(x.r) + '">' + (ex ? 'Hide context' : 'Show context') + '</button><button class="lnk" data-act="wzctx" data-r="' + esc(x.r) + '">Study this occurrence</button><button class="lnk" data-act="wzoctog" data-r="' + esc(x.r) + '">' + (oc.n ? 'Edit note' : 'Add note') + '</button></div>' + (oc.n != null && (oc.n || WV.exp['n' + x.r]) ? '<textarea class="wzocn" data-wzoc="' + esc(x.r) + '" rows="2" placeholder="Your note on this verse">' + esc(oc.n || '') + '</textarea>' : '') + '</li>'; }).join('');
    var R = wzRend(k), groups = Object.keys(grp);
    return '<div class="wzgrid3"><div><h3>By testament</h3>' + wzBars([['Old Testament', ot, { a: 'wzof', f: 't', v: 'ot' }, f.t === 'ot'], ['New Testament', nt, { a: 'wzof', f: 't', v: 'nt' }, f.t === 'nt']]) + '<h3>By section</h3>' + wzBars(groups.map(function (g) { return [esc(g), grp[g], { a: 'wzof', f: 'g', v: g }, f.g === g]; })) + '</div><div><h3>By book</h3>' + wzBars(books.map(function (b) { return [esc(b), bc[b], { a: 'wzof', f: 'b', v: b }, f.b === b]; }), { cls: 'scroll' }) + '</div></div>' + chap +
      '<div class="wzfilters"><input id="wzos" value="' + esc(f.s) + '" placeholder="Search within these verses" aria-label="Search within occurrences"><select id="wzot" aria-label="Testament"><option value="all">Both testaments</option><option value="ot"' + (f.t === 'ot' ? ' selected' : '') + '>Old Testament</option><option value="nt"' + (f.t === 'nt' ? ' selected' : '') + '>New Testament</option></select><select id="wzob" aria-label="Book"><option value="">All books</option>' + books.map(function (b) { return '<option' + (f.b === b ? ' selected' : '') + '>' + b + '</option>'; }).join('') + '</select><select id="wzow" aria-label="English rendering"><option value="">Any rendering</option>' + R.map(function (r) { return '<option value="' + esc(r[0]) + '"' + (f.w === r[0] ? ' selected' : '') + '>“' + esc(r[0]) + '” (' + r[1] + ')</option>'; }).join('') + '</select><select id="wzoo" aria-label="Sort"><option value="bible">Bible order</option><option value="rend"' + (f.sort === 'rend' ? ' selected' : '') + '>By English rendering</option><option value="book"' + (f.sort === 'book' ? ' selected' : '') + '>Books with most uses first</option></select><label class="wzinl"><input type="checkbox" id="wzosv"' + (f.sv ? ' checked' : '') + '> Saved only</label></div>' +
      '<div class="wzrow"><b>' + F.length.toLocaleString() + ' of ' + L.length.toLocaleString() + ' verses</b>' + (F.length !== L.length ? '<button class="lnk" data-act="wzofx">Clear filters</button>' : '') + '<span class="sp"></span>' + (WV.sel.length ? '<button class="pri" data-act="wztab" data-v="cmp">Compare ' + WV.sel.length + ' selected</button>' : '<small class="dim">Tick “Compare” on verses to set them side by side</small>') + '</div>' +
      (k[0] === 'H' && !HB ? '<p class="wzhint">Loading Hebrew forms…</p>' : '') + '<ol class="wzocs">' + rows + '</ol>' + (F.length > P ? '<div class="wzpager"><button data-act="wzop" data-d="-1"' + (pg ? '' : ' disabled') + '>Previous</button><span>Page ' + (pg + 1) + ' of ' + Math.ceil(F.length / P) + '</span><button data-act="wzop" data-d="1"' + ((pg + 1) * P < F.length ? '' : ' disabled') + '>Next</button></div>' : '');
  }
  function wzSpread(k) { var L = wzOcc(k), out = [], seenW = {}; L.forEach(function (x) { var w = x.w[0]; if (w && !seenW[w] && out.length < 6) { seenW[w] = 1; out.push(x.r); } }); if (out.length < 4) { [L.find(function (x) { return x.ot; }), L.find(function (x) { return !x.ot; }), L[Math.floor(L.length / 2)], L[L.length - 1]].forEach(function (x) { if (x && out.length < 6 && out.indexOf(x.r) < 0) out.push(x.r); }); } return out; }
  function wzCmp(k, rec) {
    var L = wzOcc(k), M = {}; L.forEach(function (x) { M[x.r] = x; });
    var sel = WV.sel.filter(function (r) { return M[r]; }); if (!sel.length) return '<p class="wzlead">Choose verses to compare in <a data-act="wztab" data-v="occ">Occurrences</a>, or let the lab pick a spread: one verse for each different English rendering, from both testaments.</p><button class="pri" data-act="wzspread">Pick a spread for me</button>';
    var rows = sel.map(function (r) { return M[r]; }), hb = k[0] === 'H' && HB, USE = ['', 'Literal', 'Figurative', 'Idiomatic', 'Theological / technical', 'Name or title'];
    var ws = {}, ots = 0, uses = {}; rows.forEach(function (x) { x.w.forEach(function (w) { ws[w] = 1; }); if (x.ot) ots++; var u = (rec.cm[x.r] || {}).use; if (u) uses[u] = (uses[u] || 0) + 1; });
    var vers = VL.filter(function (v) { return v !== 'KJV' && v !== 'HEB'; }), cv = WV.cv.filter(function (v) { return vers.indexOf(v) >= 0; });
    return '<div class="wzrow"><b>' + rows.length + ' passages</b><span class="sp"></span><button data-act="wzspread">Pick a spread</button><button data-act="wzselclr">Clear</button></div>' +
      '<div class="wzcard"><small>What these passages show</small><ul class="wzul"><li>English renderings: ' + Object.keys(ws).map(function (w) { return '“' + esc(w) + '”'; }).join(', ') + (Object.keys(ws).length > 1 ? ' — the translators judged the context to call for different English words.' : ' — rendered the same way in each.') + '</li><li>' + ots + ' from the Old Testament, ' + (rows.length - ots) + ' from the New.</li></ul>' + (Object.keys(uses).length ? '<p>Your usage marks: ' + Object.keys(uses).map(function (u) { return esc(u) + ' ×' + uses[u]; }).join(', ') + '</p>' : '<p class="dim small">Mark each passage\'s usage below to see patterns (literal, figurative, and so on).</p>') + '</div>' +
      '<div class="wztbl"><table class="wzct"><thead><tr><th>Passage</th><th>Original</th><th>KJV rendering</th><th>Context</th><th>Meaning in context <small>(yours)</small></th><th>Usage</th></tr></thead><tbody>' + rows.map(function (x) { var cm = rec.cm[x.r] || {}, h = hb ? wzHebAt(x.b, x.c, x.v, k) : []; return '<tr><td><a data-act="wzctx" data-r="' + esc(x.r) + '"><b>' + esc(x.r) + '</b></a><br><small>' + esc(wzGroup(x.b)) + '</small></td><td>' + (h.length ? '<span class="hebw" lang="he">' + esc(h[0].h) + '</span><br><small>' + esc(morph(h[0].mo)) + '</small>' : '<span class="' + (k[0] === 'H' ? 'hebw' : 'grk') + '">' + esc(wzScript(k)) + '</span>') + '</td><td>“' + esc(x.ph.join('”, “')) + '”</td><td class="wzv">' + wzVerseHtml(x.t, k) + '</td><td><textarea data-wzcm="' + esc(x.r) + '" data-f="mean" rows="3" aria-label="Meaning in ' + esc(x.r) + '">' + esc(cm.mean || '') + '</textarea></td><td><select data-wzcm="' + esc(x.r) + '" data-f="use" aria-label="Usage in ' + esc(x.r) + '">' + USE.map(function (u) { return '<option value="' + u + '"' + ((cm.use || '') === u ? ' selected' : '') + '>' + (u || '—') + '</option>'; }).join('') + '</select><button class="lnk" data-act="wzselrm" data-r="' + esc(x.r) + '">Remove</button></td></tr>'; }).join('') + '</tbody></table></div>' +
      '<h3>Compare translations</h3><p class="wzhint">Other versions are not tagged with Strong\'s numbers, so compare the whole verse and see how each renders the word. A different English word is not automatically wrong: ask what the original and the context support.</p><div class="wzchips">' + vers.map(function (v) { return '<button class="chip' + (cv.indexOf(v) >= 0 ? ' on' : '') + '" data-act="wzcv" data-v="' + v + '">' + esc(v) + '</button>'; }).join('') + '</div>' +
      (cv.length ? '<div class="wztbl"><table class="wzct"><thead><tr><th>Passage</th><th>KJV</th>' + cv.map(function (v) { return '<th>' + esc(v) + '</th>'; }).join('') + '</tr></thead><tbody>' + rows.map(function (x) { return '<tr><td><b>' + esc(x.r) + '</b></td><td class="wzv">' + wzVerseHtml(x.t, k) + '</td>' + cv.map(function (v) { var t = gv(v, x.b, x.c, x.v); return '<td class="wzv">' + (t ? esc(plain(t)) : BIB[v] ? '<span class="dim">Not in this version</span>' : '<span class="dim">Loading…</span>') + '</td>'; }).join('') + '</tr>'; }).join('') + '</tbody></table></div>' : '');
  }
  function wzCon(k, rec) {
    var R = wzRels(k), types = Object.keys(WZREL), by = {}; R.forEach(function (x) { (by[x.t] = by[x.t] || []).push(x); });
    var cap = { root: 7, rel: 4, tr: 5, co: 3, sim: 6, opp: 6, theo: 6 }, cn = {}, N = R.filter(function (x) { cn[x.t] = (cn[x.t] || 0) + 1; return cn[x.t] <= cap[x.t]; }).slice(0, 20), W = 720, Hh = 460, cx = W / 2, cy = Hh / 2, pos = {};
    N.forEach(function (x, i) { var a = i / N.length * Math.PI * 2 - Math.PI / 2, rr = i % 2 ? 0.74 : 1; pos[i] = [cx + Math.cos(a) * 290 * rr, cy + Math.sin(a) * 185 * rr]; });
    var svg = N.length ? '<svg class="wznet" viewBox="0 0 ' + W + ' ' + Hh + '" role="img" aria-label="Network of words related to ' + k + '">' + N.map(function (x, i) { var t = WZREL[x.t]; return '<line x1="' + cx + '" y1="' + cy + '" x2="' + pos[i][0].toFixed(1) + '" y2="' + pos[i][1].toFixed(1) + '" stroke="' + t[1] + '" stroke-width="2" stroke-dasharray="' + t[2] + '"/>'; }).join('') +
      N.map(function (x, i) { var p = pos[i], t = WZREL[x.t]; return '<g class="wznode" data-act="wsopen" data-k="' + x.k + '" tabindex="0" role="button" aria-label="' + esc(wzTr(x.k)) + ' ' + x.k + ', ' + t[0] + '"><title>' + esc(x.why) + '</title><rect x="' + (p[0] - 50).toFixed(1) + '" y="' + (p[1] - 19).toFixed(1) + '" width="100" height="38" rx="9" fill="var(--pane)" stroke="' + t[1] + '" stroke-width="1.6"/><text x="' + p[0].toFixed(1) + '" y="' + (p[1] - 3).toFixed(1) + '" text-anchor="middle" class="' + (x.k[0] === 'H' ? 'hebw' : 'grk') + '">' + esc(wzScript(x.k).slice(0, 12)) + '</text><text x="' + p[0].toFixed(1) + '" y="' + (p[1] + 12).toFixed(1) + '" text-anchor="middle" class="sm">' + esc(wzTr(x.k).slice(0, 12)) + ' ' + x.k + '</text></g>'; }).join('') +
      '<g class="ctrg"><circle cx="' + cx + '" cy="' + cy + '" r="42" fill="var(--acc)"/><text x="' + cx + '" y="' + (cy + 2) + '" text-anchor="middle" fill="var(--onacc,#fff)" class="' + (k[0] === 'H' ? 'hebw' : 'grk') + ' ctr">' + esc(wzScript(k).slice(0, 10)) + '</text><text x="' + cx + '" y="' + (cy + 18) + '" text-anchor="middle" fill="var(--onacc,#fff)" class="sm">' + k + '</text></g></svg>' : '<p class="wzempty">No related words recorded for ' + k + '.</p>';
    var legend = '<ul class="wzleg">' + types.map(function (t) { return '<li><svg width="34" height="8" aria-hidden="true"><line x1="0" y1="4" x2="34" y2="4" stroke="' + WZREL[t][1] + '" stroke-width="2.5" stroke-dasharray="' + WZREL[t][2] + '"/></svg>' + WZREL[t][0] + ' <small>' + ((by[t] || []).length) + '</small></li>'; }).join('') + '</ul>';
    var lists = types.filter(function (t) { return by[t]; }).map(function (t) { return '<h3><i class="wzsw" style="background:' + WZREL[t][1] + '"></i>' + WZREL[t][0] + '</h3><ul class="wzrl">' + by[t].map(function (x) { var mine = rec.links.findIndex(function (l) { return l.k === x.k && l.t === x.t; }); return '<li>' + wzA(x.k) + ' <span class="dim">' + esc(wzGloss(x.k)) + '</span><small>' + esc(x.why) + '</small>' + (mine >= 0 ? '<button class="lnk" data-act="wzlinkrm" data-i="' + mine + '">Remove</button>' : '') + '</li>'; }).join('') + '</ul>'; }).join('');
    return (R.length > N.length ? '' : '') + '<p class="wzhint">Each line shows where the link comes from.' + (R.length > N.length ? ' The map shows ' + N.length + ' of ' + R.length + '; all are listed below.' : '') + ' Words that share a root or an English rendering are related, not identical: open each one and look at its own usage.</p>' + svg + legend + lists +
      '<h3>Add your own connection</h3><p class="wzhint">For similar meanings, opposites and theological associations the app has no dataset, so these come from your study. Give the verse that shows the connection.</p><div class="wzform"><input id="wzlk" placeholder="Strong\'s number, e.g. G5368" aria-label="Related word"><select id="wzlt" aria-label="Type of connection"><option value="sim">Similar meaning</option><option value="opp">Opposite meaning</option><option value="theo">Theological association</option><option value="rel">Related word</option></select><input id="wzle" placeholder="Evidence, e.g. John 21:15-17" aria-label="Evidence"><input id="wzln" placeholder="Why they connect" aria-label="Note"><button class="pri" data-act="wzlinkadd">Add</button></div>';
  }
  function wzTheo(k, rec) {
    var L = wzOcc(k), cat = WZANCH.map(function (a) { var vs = L.filter(function (x) { return a[1].some(function (z) { return z !== k && x.t.indexOf('{' + z + '}') >= 0; }); }); return [a[0], vs, a[1]]; }).filter(function (a) { return a[1].length; });
    var lay = function (id) { return WZLAYERS.filter(function (l) { return l[0] === id; })[0]; };
    var ledger = WZLAYERS.map(function (l) { var it = rec.th.map(function (x, i) { return [x, i]; }).filter(function (p) { return p[0].l === l[0]; }); return it.length ? '<div class="wzlay"><h4>' + l[1] + '</h4>' + it.map(function (p) { var x = p[0], refs = (x.ev || '').split(/[;\n]/).map(function (s) { return s.trim(); }).filter(Boolean); return '<div class="wzclaim"><p>' + esc(x.t) + '</p><div class="wzev">' + (refs.length ? refs.map(function (r) { var n = normRef(r); return n ? '<a class="smref ok" data-act="smgo" data-r="' + esc(n) + '">' + rlabel(n) + '</a>' : '<span class="smref bad">' + esc(r) + ' — not found</span>'; }).join('') : '<span class="dim small">No verse attached</span>') + '</div><button class="lnk" data-act="wzthrm" data-i="' + p[1] + '">Remove</button></div>'; }).join('') + '</div>' : ''; }).join('');
    return '<div class="wzwarn"><b>Let the text lead</b><p>Theological meaning comes from how this word is used in its passages, not from its root or from every possible definition at once. Keep the layers apart: what the word means, what it means here, how Scripture develops it, how it fits doctrine, and what it asks of you.</p></div>' +
      '<h3>Passages to examine</h3><p class="wzhint">Verses where ' + k + ' appears in the same verse as these key words (counted from the tagged text). Appearing together is evidence to read, not a conclusion.</p>' + (cat.length ? '<div class="wzanch">' + cat.map(function (c) { return '<details><summary><b>' + esc(c[0]) + '</b> <span>' + c[1].length + ' verse' + (c[1].length > 1 ? 's' : '') + '</span></summary><p class="small dim">Words: ' + c[2].filter(function (z) { return LEX[z]; }).map(function (z) { return wzA(z, esc(wzTr(z)) + ' ' + z); }).join(', ') + '</p><div class="wzrefs">' + c[1].slice(0, 24).map(function (x) { return '<a class="chip" data-act="wzctx" data-r="' + esc(x.r) + '">' + esc(x.r) + '</a>'; }).join('') + (c[1].length > 24 ? '<span class="dim small">+' + (c[1].length - 24) + ' more</span>' : '') + '</div></details>'; }).join('') + '</div>' : '<p class="wzempty">This word does not appear alongside the key theological words in the same verse.</p>') +
      '<h3>Your evidence ledger</h3><p class="wzhint">Write what you conclude and attach the verses that show it. The first three layers need at least one verse that the lab can find.</p>' + (ledger || '<p class="wzempty">No conclusions recorded yet.</p>') +
      '<div class="wzform col"><select id="wzthl" aria-label="Layer">' + WZLAYERS.map(function (l) { return '<option value="' + l[0] + '">' + l[1] + ' — ' + l[2] + '</option>'; }).join('') + '</select><textarea id="wzthx" rows="3" placeholder="What does the evidence show?" aria-label="Statement"></textarea><input id="wzthe" placeholder="Verses that show it, separated by ; (e.g. John 3:16; 1 John 4:8)" aria-label="Evidence"><button class="pri" data-act="wzthadd">Add to ledger</button></div>' +
      '<label class="smf"><span class="sml">Christ-centred connections</span><small>Only where the text justifies them. Say how.</small><textarea data-wzn="christ" rows="3">' + esc(rec.n.christ || '') + '</textarea></label>';
  }
  function wzNotes(k, rec) {
    var ocs = Object.keys(rec.oc).filter(function (r) { return rec.oc[r].s || rec.oc[r].n; });
    return '<div class="wzchips" role="group" aria-label="Study status">' + WZST.map(function (s) { return '<button class="chip' + (rec.st === s ? ' on' : '') + '" data-act="wzst" data-v="' + s + '" aria-pressed="' + (rec.st === s) + '">' + s + '</button>'; }).join('') + '</div><p class="wzhint">Everything saves as you type and syncs with the rest of your Bible app.</p>' +
      '<div class="wznotes">' + WZNOTES.map(function (x) { return '<label class="smf"><span class="sml">' + x[1] + '</span><textarea data-wzn="' + x[0] + '" rows="' + ((rec.n[x[0]] || '').length > 140 ? 4 : 2) + '">' + esc(rec.n[x[0]] || '') + '</textarea></label>'; }).join('') + '</div>' +
      '<h3>Your verses</h3>' + (ocs.length ? '<ul class="wzrl">' + ocs.map(function (r) { var o = rec.oc[r]; return '<li>' + (o.s ? '★ ' : '') + wzRefA(r) + (o.n ? '<small>' + esc(o.n) + '</small>' : '') + '</li>'; }).join('') + '</ul>' : '<p class="wzempty">Save occurrences or add notes to them in Occurrences.</p>');
  }
  function wzReportHtml(k, rec) {
    var e = wzE(k) || [], o = CI && CI[k], L = wzOcc(k), R = wzRend(k), bc = wzBookCounts(L), hs = k[0] === 'H' ? wzHebStats(k) : null, rels = wzRels(k), r = wzRoot(k);
    var sec = function (n, t, body) { return body ? '<h3>' + n + '. ' + t + '</h3>' + body : ''; }, p = function (t) { return t ? '<p>' + esc(t).replace(/\n/g, '<br>') + '</p>' : ''; };
    var ex = Object.keys(rec.cm).filter(function (x) { return rec.cm[x].mean; });
    var stems = hs && Object.keys(hs.stems).sort(function (a, b) { return hs.stems[b] - hs.stems[a]; });
    return '<article class="wzrep" id="wzrep"><h2>Word study: ' + esc(e[1] || k) + ' (' + k + ')</h2><p class="dim">' + wzLang(k) + ' · prepared ' + new Date().toLocaleDateString() + '</p>' +
      sec(1, 'Word', '<p><span class="' + (k[0] === 'H' ? 'hebw' : 'grk') + ' big">' + esc(e[0] || '') + '</span> · ' + esc(e[1] || '') + (wzPhon(k) ? ' · pronounced ' + esc(wzPhon(k)) : '') + ' · Strong\'s ' + k + (wzPos(k) ? ' · ' + esc(wzPos(k)) : '') + '</p>') +
      sec(2, 'Definition (Strong\'s)', p(e[3])) + sec(3, 'Root and derivation', p((e[5] || '') + (r !== k ? ' Source word: ' + r + ' ' + wzTr(r) + '.' : ''))) +
      sec(4, 'Morphology', stems && stems.length ? p('Stems in the Hebrew Bible: ' + stems.map(function (s) { return s + ' ' + hs.stems[s]; }).join(', ') + '.') : p(k[0] === 'G' ? 'Greek parsing data is not available in this app.' : 'No verbal stems recorded.')) +
      sec(5, 'Semantic range: how the KJV translates it', p(R.map(function (x) { return '“' + x[0] + '” ' + x[1] + '×'; }).join(', ')) + p(rec.n.range)) +
      sec(6, 'Frequency', p((o ? o.n : 0) + ' occurrences in ' + L.length + ' verses across ' + Object.keys(bc).length + ' books. Most in: ' + Object.keys(bc).sort(function (a, b) { return bc[b] - bc[a]; }).slice(0, 5).map(function (b) { return b + ' (' + bc[b] + ')'; }).join(', ') + '.')) +
      sec(7, 'Meaning in context', ex.length ? '<ul>' + ex.map(function (x) { return '<li><b>' + esc(x) + '</b>: ' + esc(rec.cm[x].mean) + (rec.cm[x].use ? ' <i>(' + esc(rec.cm[x].use) + ')</i>' : '') + '</li>'; }).join('') + '</ul>' : '') +
      sec(8, 'Related words', rels.length ? '<ul>' + rels.slice(0, 14).map(function (x) { return '<li>' + x.k + ' ' + esc(wzTr(x.k)) + ' — ' + esc(WZREL[x.t][0]) + ': ' + esc(x.why) + '</li>'; }).join('') + '</ul>' : '') +
      sec(9, 'Theological significance', rec.th.length ? '<ul>' + rec.th.map(function (x) { var l = WZLAYERS.filter(function (y) { return y[0] === x.l; })[0]; return '<li><b>' + (l ? l[1] : '') + ':</b> ' + esc(x.t) + (x.ev ? ' <i>(' + esc(x.ev) + ')</i>' : '') + '</li>'; }).join('') + '</ul>' : '') +
      sec(10, 'Christ-centred connections', p(rec.n.christ)) +
      sec(11, 'Lexical notes', p([rec.n.lit && 'Literal sense: ' + rec.n.lit, rec.n.fig && 'Figurative use: ' + rec.n.fig, rec.n.dev && 'Root and related forms: ' + rec.n.dev, rec.n.trd && 'Translation differences: ' + rec.n.trd].filter(Boolean).join('\n'))) +
      sec(12, 'My study notes', WZNOTES.filter(function (x) { return x[0] !== 'concl' && rec.n[x[0]]; }).map(function (x) { return '<p><b>' + x[1] + ':</b> ' + esc(rec.n[x[0]]).replace(/\n/g, '<br>') + '</p>'; }).join('')) +
      sec(13, 'Conclusion', p(rec.n.concl)) + '<p class="dim small">Sources: Strong\'s Exhaustive Concordance (public domain); KJV with Strong\'s numbers (public domain)' + (hs ? '; Hebrew morphology in the Open Scripture Hebrew Bible format (CC BY 4.0)' : '') + '.</p></article>';
  }
  function wzRep(k, rec) {
    var sl = typeof SM !== 'undefined' ? SM.list : [], s = sl.filter(function (x) { return x.id === WV.sd; })[0] || sl[0];
    return '<div class="wzrow"><button data-act="wzcopy">' + ic('copy', 14) + ' Copy</button><button data-act="wzprint">Print or save as PDF</button><button data-act="wzrsave">Save a snapshot</button><button data-act="wzjr">' + ic('note', 14) + ' To journal</button></div>' +
      (sl.length ? '<div class="wzform"><span>Add to sermon</span><select id="wzsd" aria-label="Sermon">' + sl.map(function (x) { return '<option value="' + x.id + '"' + (s && x.id === s.id ? ' selected' : '') + '>' + esc((x.f && x.f.title) || (x.seed && x.seed.text) || 'Untitled sermon') + '</option>'; }).join('') + '</select><select id="wzsp" aria-label="Where in the sermon"><option value="kw">Key words (stage 04)</option>' + (s && s.points ? s.points.map(function (p, i) { return '<option value="' + i + '">Point ' + (i + 1) + (p.title ? ': ' + esc(p.title.slice(0, 40)) : '') + ' (evidence)</option>'; }).join('') : '') + '</select><button class="pri" data-act="wzsermon">Add</button></div>' : '<p class="wzhint">Create a sermon in the Sermon Workshop to add this study to it.</p>') +
      (rec.reps.length ? '<details><summary>Saved snapshots (' + rec.reps.length + ')</summary><ul class="wzrl">' + rec.reps.map(function (x, i) { return '<li>' + new Date(x.at).toLocaleString() + ' <button class="lnk" data-act="wzrview" data-i="' + i + '">View</button></li>'; }).join('') + '</ul></details>' : '') +
      (WV.rv != null && rec.reps[WV.rv] ? '<div class="wzsnap"><button class="lnk" data-act="wzrview" data-i="-1">Close snapshot</button>' + rec.reps[WV.rv].html + '</div>' : wzReportHtml(k, rec));
  }
  function wzSummary(k, rec) { var e = wzE(k) || [], ex = Object.keys(rec.cm).filter(function (x) { return rec.cm[x].mean; }); return k + ' ' + (e[0] || '') + ' (' + (e[1] || '') + '): ' + wzGloss(k) + '.' + (rec.n.disc ? ' ' + rec.n.disc : '') + (ex.length ? ' In context — ' + ex.slice(0, 3).map(function (x) { return x + ': ' + rec.cm[x].mean; }).join('; ') + '.' : '') + (rec.n.concl ? ' Conclusion: ' + rec.n.concl : ''); }

  /* ---- events ---- */
  function wzOpen(k, r, keepTab) {
    k = (k || '').toUpperCase(); ensureCI(); if (!LEX[k] && !(CI && CI[k])) { toast('No entry for ' + k); return; }
    if (WV.k !== k) { WV.sel = []; WV.exp = {}; WV.of = { t: 'all', b: '', g: '', w: '', s: '', sort: 'bible', p: 0 }; WV.rv = null; }
    WV.k = k; WV.r = r || null; if (!keepTab) WV.tab = 'ov';
    var rec = wzW(k), now = Date.now(); rec.views++; rec.last = now; WZ.hist.push({ k: k, t: now, r: r || '' }); if (WZ.hist.length > 3000) WZ.hist = WZ.hist.slice(-3000);
    wzsv(true); wvsv(); view = 'wstudy'; if (innerWidth <= 800) side = false; drawer = false; sv(); render(); window.scrollTo(0, 0); var m = $('#main'); if (m) m.scrollTop = 0;
  }
  function wzRefresh(sel) { var el = sel && document.querySelector(sel); if (!el) { render(); return; } }
  document.addEventListener('keydown', function (e) { if (e.key !== 'Enter' || !e.target) return; if (e.target.id === 'wzq') { e.preventDefault(); act('wzsearch', {}); } else if (e.target.id === 'wzos') { e.preventDefault(); WV.of.s = e.target.value; WV.of.p = 0; render(); } else if (e.target.closest && e.target.closest('.wzbar[data-act],.wznode')) { e.preventDefault(); e.target.closest('[data-act]').click(); } });
  document.addEventListener('input', function (e) {
    var t = e.target, k = WV.k; if (!t || !t.dataset) return;
    if (t.dataset.wzn != null && k) { wzW(k).n[t.dataset.wzn] = t.value; wzsv(); return; }
    if (t.dataset.wzcm != null && k && t.tagName === 'TEXTAREA') { var c = wzW(k).cm; (c[t.dataset.wzcm] = c[t.dataset.wzcm] || {})[t.dataset.f] = t.value; wzsv(); document.querySelectorAll('textarea[data-wzcm="' + t.dataset.wzcm + '"][data-f="' + t.dataset.f + '"]').forEach(function (o) { if (o !== t) o.value = t.value; }); return; }
    if (t.dataset.wzoc != null && k) { var oc = wzW(k).oc; (oc[t.dataset.wzoc] = oc[t.dataset.wzoc] || {}).n = t.value; wzsv(); return; }
    if (t.id === 'wzos') { clearTimeout(WV.ot); WV.ot = setTimeout(function () { WV.of.s = t.value; WV.of.p = 0; var pos = t.selectionStart; render(); var n = $('#wzos'); if (n) { n.focus(); try { n.setSelectionRange(pos, pos); } catch (x) {} } }, 350); }
  });
  document.addEventListener('change', function (e) {
    var t = e.target, k = WV.k; if (!t) return;
    var F = { wzot: 't', wzob: 'b', wzow: 'w', wzoo: 'sort' };
    if (F[t.id]) { WV.of[F[t.id]] = t.value; WV.of.p = 0; render(); return; }
    if (t.id === 'wzosv') { WV.of.sv = t.checked; WV.of.p = 0; render(); return; }
    if (t.id === 'wzst' && k) { wzW(k).st = t.value; wzsv(true); return; }
    if (t.id === 'wzl') { WV.lang = t.value; if (WV.q) render(); return; } if (t.id === 'wzm') { WV.mode = t.value; if (WV.q) render(); return; }
    if (t.id === 'wzrb') { WV.rb = t.value; render(); return; }
    if (t.id === 'wzanl') { WV.an.lang = t.value; render(); return; } if (t.id === 'wzans') { WV.an.st = t.value; render(); return; } if (t.id === 'wzanh') { WV.an.hide = t.checked ? 1 : 0; render(); return; }
    if (t.id === 'wzsd') { WV.sd = t.value; render(); return; }
    if (t.dataset && t.dataset.wzsel != null) { var r = t.dataset.wzsel, i = WV.sel.indexOf(r); if (t.checked && i < 0) { if (WV.sel.length >= 12) { t.checked = false; toast('Compare up to 12 passages'); return; } WV.sel.push(r); } if (!t.checked && i >= 0) WV.sel.splice(i, 1); render(); return; }
    if (t.dataset && t.dataset.wzcm != null && t.tagName === 'SELECT' && k) { var c = wzW(k).cm; (c[t.dataset.wzcm] = c[t.dataset.wzcm] || {})[t.dataset.f] = t.value; wzsv(true); render(); return; }
  });
  var actZ = act;
  act = function (a, d) {
    d = d || {}; var k = WV.k, rec = k ? wzW(k) : null;
    switch (a) {
      case 'wstudy': view = 'wstudy'; if (innerWidth <= 800) side = false; sv(); render(); return;
      case 'wsopen': wzOpen(d.k, d.r || (view === 'read' || view === 'analyze' ? wzRef(cur.b, cur.c, cur.v) : null)); return;
      case 'wzhome': WV.k = null; wvsv(); render(); window.scrollTo(0, 0); return;
      case 'wzdash': WV.dash = d.v; wvsv(); render(); return;
      case 'wzsearch': WV.q = (($('#wzq') || {}).value || '').trim(); WV.lang = ($('#wzl') || {}).value || WV.lang; WV.mode = ($('#wzm') || {}).value || WV.mode; var R0 = WV.q && wzSearch(WV.q, WV.lang, WV.mode); if (R0 && R0.groups.length === 1 && R0.groups[0].ks.length === 1 && !R0.ref) { var only = R0.groups[0].ks[0][0]; WV.q = ''; wzOpen(only); return; } render(); return;
      case 'wzclear': WV.q = ''; render(); return;
      case 'wzbl': WV.bl = d.v; WV.bp = 0; render(); return;
      case 'wzbp': WV.bp = Math.max(0, WV.bp + +d.d); render(); window.scrollTo(0, 0); return;
      case 'wzlet': WV.letter = WV.letter === +d.i ? null : +d.i; render(); return;
      case 'wzacro': WV.acro = WV.acro === +d.i ? null : +d.i; render(); return;
      case 'wztab': WV.tab = d.v; wvsv(); render(); var b0 = document.querySelector('.wztabs'); if (b0 && b0.getBoundingClientRect().top < 0) b0.scrollIntoView(); return;
      case 'wzstep': { var n = +k.slice(1) + +d.d, nk = k[0] + n; while (n > 0 && n < 9000 && !LEX[nk]) { n += +d.d; nk = k[0] + n; } if (LEX[nk]) wzOpen(nk, null, true); return; }
      case 'wzgo': { var p = wzSplitRef(d.r) || parse(d.r); if (p) { go({ b: p.b, c: p.c, v: p.v || 1 }, true); } return; }
      case 'wzocc': { var L = wzOcc(k), x = L[+d.i]; if (x) { WV.r = x.r; wvsv(); render(); } return; }
      case 'wzctx': WV.r = d.r; WV.tab = 'ctx'; WV.exp.ctx = false; wvsv(); render(); window.scrollTo(0, 0); return;
      case 'wzexp': WV.exp[d.v] = !WV.exp[d.v]; render(); return;
      case 'wzof': WV.of[d.f] = WV.of[d.f] === d.v ? (d.f === 't' ? 'all' : '') : d.v; WV.of.p = 0; render(); return;
      case 'wzofx': WV.of = { t: 'all', b: '', g: '', w: '', s: '', sort: 'bible', p: 0 }; render(); return;
      case 'wzop': WV.of.p = Math.max(0, WV.of.p + +d.d); render(); var ol = document.querySelector('.wzocs'); if (ol) ol.scrollIntoView(); return;
      case 'wzrend': WV.tab = 'occ'; WV.of = { t: 'all', b: '', g: '', w: d.w, s: '', sort: 'bible', p: 0 }; wvsv(); render(); return;
      case 'wzsave': { var o = rec.oc[d.r] = rec.oc[d.r] || {}; o.s = !o.s; wzsv(true); render(); return; }
      case 'wzoctog': { var o2 = rec.oc[d.r] = rec.oc[d.r] || {}; if (o2.n == null) o2.n = ''; WV.exp['n' + d.r] = true; render(); var ta = document.querySelector('textarea[data-wzoc="' + d.r + '"]'); if (ta) ta.focus(); return; }
      case 'wzspread': WV.sel = wzSpread(k); render(); return;
      case 'wzselclr': WV.sel = []; render(); return;
      case 'wzselrm': WV.sel = WV.sel.filter(function (r) { return r !== d.r; }); render(); return;
      case 'wzcv': { var i = WV.cv.indexOf(d.v); if (i >= 0) WV.cv.splice(i, 1); else { if (WV.cv.length >= 4) WV.cv.shift(); WV.cv.push(d.v); if (!BIB[d.v]) loadVer(d.v).then(render); } render(); return; }
      case 'wzlinkadd': { var lk = wzKey(($('#wzlk') || {}).value || '') || ((wzSearch(($('#wzlk') || {}).value || '', 'all', 'auto') || { groups: [] }).groups[0] || { ks: [[null]] }).ks[0][0]; if (!lk || lk === k) { toast('Enter a Strong\'s number, e.g. G5368'); return; } var ev = (($('#wzle') || {}).value || '').trim(); if (ev && !ev.split(';').every(function (r) { return normRef(r.trim()); })) { toast('Check the evidence reference'); return; } rec.links.push({ k: lk, t: $('#wzlt').value, ev: ev, note: (($('#wzln') || {}).value || '').trim() }); wzsv(true); render(); return; }
      case 'wzlinkrm': rec.links.splice(+d.i, 1); wzsv(true); render(); return;
      case 'wzthadd': { var l = $('#wzthl').value, tx = ($('#wzthx').value || '').trim(), ev2 = ($('#wzthe').value || '').trim(), need = WZLAYERS.filter(function (y) { return y[0] === l; })[0][3]; if (!tx) { toast('Write the statement first'); return; } var ok = ev2.split(/[;\n]/).map(function (s) { return s.trim(); }).filter(Boolean).filter(function (r) { return normRef(r); }); if (need && !ok.length) { toast('Attach at least one verse that shows this'); return; } rec.th.push({ l: l, t: tx, ev: ev2, at: Date.now() }); wzsv(true); render(); return; }
      case 'wzthrm': rec.th.splice(+d.i, 1); wzsv(true); render(); return;
      case 'wzst': rec.st = rec.st === d.v ? '' : d.v; wzsv(true); render(); return;
      case 'wzcopy': { var el = $('#wzrep'), txt = el ? el.innerText : ''; try { navigator.clipboard.writeText(txt).then(function () { toast('Copied'); }, function () { toast('Copy is not available here'); }); } catch (x) { toast('Copy is not available here'); } return; }
      case 'wzprint': document.body.classList.add('wzprinting'); try { window.print(); } catch (x) { toast('Printing is not available here. Use Copy instead.'); } setTimeout(function () { document.body.classList.remove('wzprinting'); }, 600); return;
      case 'wzrsave': { var el2 = $('#wzrep'); if (el2) { rec.reps.unshift({ at: Date.now(), html: el2.outerHTML.replace('id="wzrep"', '') }); rec.reps = rec.reps.slice(0, 10); wzsv(true); toast('Snapshot saved'); render(); } return; }
      case 'wzrview': WV.rv = +d.i < 0 ? null : +d.i; render(); return;
      case 'wzjr': { try { var el3 = $('#wzrep'); var j = curJ() || JR.list.find(function (x) { return x.id === JR.last; }) || JR.list[0]; if (!j) j = newJournal('My Journal'); D.j = j.id; var pg = newPage(j); pg.title = 'Word study: ' + wzTr(k) + ' (' + k + ')'; pg.body = el3 ? el3.innerText : ''; D.p = pg.id; jsv(); toast('Saved to ' + j.name); } catch (x) { toast('Could not reach the journal'); } return; }
      case 'wzsermon': { var sid = ($('#wzsd') || {}).value, s = SM.list.filter(function (x) { return x.id === sid; })[0], where = ($('#wzsp') || {}).value; if (!s) return; var sum = wzSummary(k, rec);
        if (where === 'kw') { s.kw = s.kw || []; if (!s.kw.some(function (x) { return x.strong === k; })) { var R1 = wzRend(k); s.kw.push({ word: R1[0] ? R1[0][0] : '', strong: k, meaning: (WV.r && rec.cm[WV.r] && rec.cm[WV.r].mean) || rec.n.disc || '', usage: WV.r || '', rel: Object.keys(rec.oc).filter(function (r) { return rec.oc[r].s; }).join('; ') }); } s.wsr = (s.wsr || []).filter(function (x) { return x.k !== k; }); s.wsr.push({ k: k, at: Date.now(), text: sum }); }
        else { var pt = s.points[+where]; if (pt) pt.evid = (pt.evid ? pt.evid + '\n\n' : '') + 'Word study — ' + sum; }
        s.updated = Date.now(); store.s('sermons', SM); toast('Added to “' + ((s.f && s.f.title) || 'sermon') + '”'); return; }
    }
    return actZ(a, d);
  };

  /* ---- 16b. AI word assistant: grounded in this word's data, with tools to fetch more evidence ---- */
  var WZAI = { busy: false, ctl: null, live: '' };
  var WZQS = ['What does this word mean in its original language?', 'What does it mean in the verse I came from, without importing meanings from other passages?', 'Why is it translated differently in different passages?', 'How is this word used elsewhere in the Bible?', 'What is the grammatical significance of the form here?', 'How does it differ from the other words the KJV translates the same way?', 'Is my interpretation in my notes supported by the text?', 'What are common misunderstandings of this word?', 'What am I missing in this passage?'];
  function wzCtxText(k, rec) {
    var e = wzE(k) || [], L = wzOcc(k), R = wzRend(k), bc = wzBookCounts(L), hs = k[0] === 'H' ? wzHebStats(k) : null, r = wzRoot(k);
    var here = WV.r && wzSplitRef(WV.r), hereRow = here && L.filter(function (x) { return x.r === WV.r; })[0], hh = here && k[0] === 'H' ? wzHebAt(here.b, here.c, here.v, k) : [];
    var pick = [], add = function (x) { if (x && pick.indexOf(x) < 0 && pick.length < 45) pick.push(x); };
    if (hereRow) add(hereRow); WV.sel.forEach(function (r) { add(L.filter(function (x) { return x.r === r; })[0]); }); Object.keys(rec.oc).forEach(function (r) { if (rec.oc[r].s) add(L.filter(function (x) { return x.r === r; })[0]); });
    var step = Math.max(1, Math.floor(L.length / 30)); for (var i = 0; i < L.length; i += step) add(L[i]);
    var notes = WZNOTES.concat([['lit', 'Literal sense'], ['fig', 'Figurative use'], ['range', 'Boundaries of meaning'], ['dev', 'Root and related forms'], ['trd', 'Translation differences'], ['christ', 'Christ-centred connections']]).filter(function (x) { return rec.n[x[0]]; }).map(function (x) { return '- ' + x[1] + ': ' + rec.n[x[0]]; });
    var cms = Object.keys(rec.cm).filter(function (x) { return rec.cm[x].mean || rec.cm[x].use; }).map(function (x) { return '- ' + x + ': ' + (rec.cm[x].mean || '') + (rec.cm[x].use ? ' [' + rec.cm[x].use + ']' : ''); });
    var rels = wzRels(k).slice(0, 16).map(function (x) { return '- ' + x.k + ' ' + wzTr(x.k) + ' (' + wzGloss(x.k) + '): ' + WZREL[x.t][0] + ' — ' + x.why; });
    return ['WORD: ' + k + ' ' + (e[0] || '') + ' (' + (e[1] || '') + '), ' + wzLang(k) + (wzPos(k) ? ', ' + wzPos(k) : ''),
      'STRONG\'S DEFINITION: ' + (e[3] || 'none'), 'STRONG\'S DERIVATION NOTE: ' + (e[5] || 'none') + (r !== k ? ' (source word ' + r + ' ' + wzTr(r) + ')' : ''), 'KJV RENDERINGS LISTED BY STRONG\'S: ' + (e[4] || ''),
      'HOW THE KJV ACTUALLY RENDERS IT (counted): ' + R.map(function (x) { return '"' + x[0] + '" ' + x[1]; }).join(', '),
      'FREQUENCY: ' + L.reduce(function (a, x) { return a + x.n; }, 0) + ' tagged occurrences in ' + L.length + ' verses; by book: ' + Object.keys(bc).map(function (b) { return b + ' ' + bc[b]; }).join(', '),
      hs ? 'HEBREW TEXT (OSHB morphology): ' + hs.n + ' occurrences; stems: ' + (Object.keys(hs.stems).map(function (s) { return s + ' ' + hs.stems[s]; }).join(', ') || 'none') + '; forms: ' + Object.keys(hs.forms).slice(0, 10).map(function (f) { return f + ' ' + hs.forms[f]; }).join(', ') : 'GREEK MORPHOLOGY: not available in this app\'s data.',
      hereRow ? 'THE VERSE THE STUDENT CAME FROM: ' + hereRow.r + ' — ' + plain(hereRow.t) + ' | English here: "' + hereRow.ph.join('", "') + '"' + (hh.length ? ' | Hebrew here: ' + hh.map(function (h) { return h.h + ' = ' + morph(h.mo); }).join('; ') : '') : 'No specific verse selected.',
      'SAMPLE OF OCCURRENCES (' + pick.length + ' of ' + L.length + '; use the find_occurrences tool for more):', pick.map(function (x) { return '- ' + x.r + ' ["' + x.ph.join('", "') + '"]: ' + plain(x.t); }).join('\n'),
      'RELATED WORDS (typed by source):', rels.join('\n') || '- none',
      'STUDENT\'S NOTES:', notes.join('\n') || '- none', 'STUDENT\'S MEANING-IN-CONTEXT NOTES:', cms.join('\n') || '- none',
      'STUDENT\'S EVIDENCE LEDGER:', rec.th.map(function (x) { return '- [' + x.l + '] ' + x.t + ' (evidence: ' + (x.ev || 'none') + ')'; }).join('\n') || '- none'].join('\n');
  }
  var WZRULES = 'You are a careful biblical-languages tutor inside a Bible study app. The student is studying one Hebrew or Greek word. Answer the question about THIS word.\n' +
    'Rules:\n1. Ground every claim in the data below or in what the tools return. Quote or cite the verses you rely on (Book Chapter:Verse). Never cite a verse you have not seen in the data or a tool result.\n' +
    '2. Usage decides meaning. Do not derive meaning from the root or etymology, do not load every possible sense into one verse, and do not make the word say more than its context says.\n' +
    '3. Keep the layers distinct and label them when it matters: what the text explicitly says; a strong textual conclusion; interpretation; theological application.\n' +
    '4. The app has Hebrew morphology but no Greek morphology. If you discuss a Greek form, say that the form is not in the app\'s data and must be checked in a Greek text. Do not overstate tense or aspect (no "the aorist means once for all").\n' +
    '5. You may use standard, widely accepted lexical scholarship, but say so ("lexicons generally note…") and never present a disputed or popular claim as settled. Do not invent lexicon quotations, statistics or sources. No Septuagint data is in the app; if relevant, say so.\n' +
    '6. If the evidence does not settle the question, say that plainly. If the student\'s notes go beyond the evidence, say so kindly and show what the text does support.\n' +
    '7. Be clear and reasonably concise. Use short paragraphs or bullet points. Plain markdown only (bold, bullets).';
  function wzTools(k) {
    var row = function (x) { var o = { ref: x.r, english: x.ph.join('; '), text: plain(x.t) }; if (k[0] === 'H' && HB) { var h = wzHebAt(x.b, x.c, x.v, k); if (h.length) o.hebrew = h.map(function (y) { return y.h + ' (' + morph(y.mo) + ')'; }).join('; '); } return o; };
    return [
      { name: 'find_occurrences', description: 'List verses where the word being studied occurs, with the English rendering' + (k[0] === 'H' ? ' and the Hebrew form' : '') + '. Filter by book, testament (OT/NT), English rendering, or a word in the verse text.', inputSchema: { type: 'object', properties: { book: { type: 'string' }, testament: { type: 'string', enum: ['OT', 'NT'] }, rendering: { type: 'string' }, contains: { type: 'string' }, limit: { type: 'number' } } },
        execute: function (a) { a = a || {}; var L = wzOcc(k).filter(function (x) { return (!a.book || x.b.toLowerCase() === String(a.book).toLowerCase()) && (!a.testament || (a.testament === 'OT') === x.ot) && (!a.rendering || x.w.indexOf(String(a.rendering).toLowerCase()) >= 0) && (!a.contains || plain(x.t).toLowerCase().indexOf(String(a.contains).toLowerCase()) >= 0); }); return { total: L.length, verses: L.slice(0, Math.min(40, a.limit || 25)).map(row) }; } },
      { name: 'read_passage', description: 'Read a Bible passage in the KJV, e.g. "John 15:1-12" or "Psalm 23". Up to 40 verses.', inputSchema: { type: 'object', properties: { ref: { type: 'string' } }, required: ['ref'] },
        execute: function (a) { var n = normRef(a && a.ref); if (!n) throw new Error('Reference not found: ' + (a && a.ref)); var out = []; (runits(n) || []).forEach(function (u) { for (var v = u.v1; v <= u.v2 && out.length < 40; v++) { var t = KJV[u.b] && KJV[u.b][u.c] && KJV[u.b][u.c][v - 1]; if (t) out.push(u.b + ' ' + u.c + ':' + v + ' ' + plain(t)); } }); return { ref: n, verses: out }; } },
      { name: 'other_word', description: 'Look up another Strong\'s number (e.g. G5368) to compare it with the word being studied: dictionary entry, KJV renderings, frequency and sample verses.', inputSchema: { type: 'object', properties: { strong: { type: 'string' } }, required: ['strong'] },
        execute: function (a) { var x = wzKey(a && a.strong); if (!x) throw new Error('No such Strong\'s number'); var e = LEX[x] || [], L = wzOcc2(x); return { strong: x, word: e[0], translit: e[1], definition: e[3], derivation: e[5], renderings: wzRend(x).slice(0, 10), occurrences: L.length, sample: L.slice(0, 12) }; } }
    ];
  }
  function wzOcc2(k) { var tag = '{' + k + '}', out = []; BOOKS.forEach(function (b) { var B = KJV[b]; if (!B) return; Object.keys(B).forEach(function (c) { B[c].forEach(function (t, i) { if (t && t.indexOf(tag) >= 0 && out.length < 400) out.push(b + ' ' + c + ':' + (i + 1) + ' ' + plain(t)); }); }); }); return out; }
  function wzAnsHtml(t) { // markdown, then check every reference against the Bible
    var h = md(t || '');
    return h.replace(/\b((?:[1-3] )?(?:Song of Solomon|[A-Z][a-z]+)) (\d{1,3}):(\d{1,3})(?:[-–](\d{1,3}))?/g, function (m) { var n = normRef(m.replace('–', '-')); return n ? '<a class="wzr" data-act="smgo" data-r="' + esc(n) + '">' + m + '</a>' : '<span class="wzbadref" title="This reference was not found in the Bible text">' + m + ' ⚠</span>'; });
  }
  function wzAsk(k, rec) {
    var chat = rec.chat || [];
    return '<section class="wzask" aria-label="Ask about this word"><div class="wzrow"><b>Ask about ' + esc(wzTr(k)) + '</b><span class="sp"></span><button class="ib" data-act="wzaskx" aria-label="Close">' + ic('x', 15) + '</button></div><p class="wzhint">Answers draw on this word\'s verses, its dictionary entry, its forms and your notes. References are checked against the Bible; any that are not found are marked ⚠. Weigh every answer against the text.</p>' +
      '<div class="wzchat" id="wzchat">' + chat.map(function (m, i) { return '<div class="wzq">' + esc(m.q) + '</div><div class="wza">' + wzAnsHtml(m.a) + (m.err ? '<p class="dim small">' + esc(m.err) + '</p>' : '') + '<div class="wzrow small"><button class="lnk" data-act="wzaisave" data-i="' + i + '">Save to my notes</button></div></div>'; }).join('') + (WZAI.busy && WZAI.k === k ? '<div class="wzq">' + esc(WZAI.q) + '</div><div class="wza" id="wzlive">' + (WZAI.live ? wzAnsHtml(WZAI.live) : '<p class="dim">Studying the verses…</p>') + '</div>' : '') + '</div>' +
      (!chat.length && !WZAI.busy ? '<div class="wzchips">' + WZQS.map(function (q) { return '<button class="chip" data-act="wzaiq" data-q="' + esc(q) + '">' + esc(q) + '</button>'; }).join('') + '</div>' : '') +
      '<div class="wzform"><textarea id="wzaq" rows="2" placeholder="Ask a question about this word…" aria-label="Your question"></textarea>' + (WZAI.busy ? '<button data-act="wzaistop">Stop</button>' : '<button class="pri" data-act="wzaiq">Ask</button>') + (chat.length && !WZAI.busy ? '<button class="lnk" data-act="wzaiclr">Clear conversation</button>' : '') + '</div></section>';
  }
  async function wzAskRun(k, q) {
    var rec = wzW(k); if (WZAI.busy) return;
    var sample = await hasAI(); if (!sample) { (rec.chat = rec.chat || []).push({ q: q, a: '', err: 'AI isn\'t available in this view. Open the app from your Claude library to use it.' }); wzsv(true); render(); return; }
    WZAI = { busy: true, k: k, q: q, live: '', ctl: new AbortController() }; render();
    var prev = (rec.chat || []).slice(-3), msgs = [];
    prev.forEach(function (m) { if (m.a) { msgs.push({ role: 'user', content: m.q }); msgs.push({ role: 'assistant', content: m.a }); } });
    var first = WZRULES + '\n\n=== DATA FOR THIS WORD ===\n' + wzCtxText(k, rec) + '\n=== END DATA ===\n\n';
    if (msgs.length) msgs[0].content = first + 'Question: ' + msgs[0].content; msgs.push({ role: 'user', content: (msgs.length ? '' : first + 'Question: ') + q });
    var ans = '', err = '';
    try { var r = await sample(msgs, { signal: WZAI.ctl.signal, cache: false, modelTier: 'default', tools: wzTools(k), onText: function (o) { WZAI.live = o.text; var el = document.getElementById('wzlive'); if (el) el.innerHTML = wzAnsHtml(o.text); } }); ans = r.text; if (r.truncated) err = 'The answer was cut short.'; }
    catch (e) { var c = e && e.code; ans = (e && e.text) || ''; err = c === 'not_granted' ? 'AI access was declined for this app.' : c === 'rate_limited' ? 'Too many requests just now. Please wait a moment and ask again.' : c === 'aborted' || c === 'canceled' || (e && e.name === 'AbortError') ? 'Stopped.' : 'That didn\'t work. Please try again in a moment.'; }
    (rec.chat = rec.chat || []).push({ q: q, a: ans, err: err, at: Date.now() }); if (rec.chat.length > 30) rec.chat = rec.chat.slice(-30);
    WZAI = { busy: false, live: '' }; wzsv(true); render(); var c2 = document.getElementById('wzchat'); if (c2) c2.lastElementChild && c2.lastElementChild.scrollIntoView({ block: 'nearest' });
  }
  var actZ2 = act;
  act = function (a, d) {
    d = d || {}; var k = WV.k;
    switch (a) {
      case 'wzask': WV.ask = !WV.ask; render(); if (WV.ask) { var q0 = $('#wzaq'); if (q0) q0.focus(); } return;
      case 'wzaskx': WV.ask = false; render(); return;
      case 'wzaiq': { var q = d.q || (($('#wzaq') || {}).value || '').trim(); if (!q) { toast('Type a question'); return; } wzAskRun(k, q); return; }
      case 'wzaistop': if (WZAI.ctl) WZAI.ctl.abort(); return;
      case 'wzaiclr': wzW(k).chat = []; wzsv(true); render(); return;
      case 'wzaisave': { var rec = wzW(k), m = (rec.chat || [])[+d.i]; if (m) { rec.n.disc = (rec.n.disc ? rec.n.disc + '\n\n' : '') + 'Q: ' + m.q + '\nAI answer (check against the text): ' + m.a; wzsv(true); toast('Added to “What I discovered”'); } return; }
    }
    return actZ2(a, d);
  };
  /* ---- integration ---- */
  var side4 = sideHtml;
  sideHtml = function () { return side4().replace('<button data-act="analyze"', '<button data-act="wstudy" class="' + (view === 'wstudy' ? 'on' : '') + '" title="Word Study">' + ic('spark') + '<span class="lb">Word Study</span></button><button data-act="analyze"'); };
  var renderZ = render;
  render = function () {
    renderZ();
    if (view === 'wstudy') { $('#main').innerHTML = WV.k ? wzPage() : wzDash(); var dr = $('#drawer'); if (dr) dr.classList.remove('open'); var tb = $('#tb'); if (tb) tb.style.display = 'none'; }
    else if (view === 'read' && Object.keys(WZ.words).length) { document.querySelectorAll('.w[data-s],.sw2[data-s]').forEach(function (s) { if (s.dataset.s.split(' ').some(function (k) { return WZ.words[k] && (WZ.words[k].st || WZ.words[k].views); })) s.classList.add('wzd'); }); }
  };
  // reader word panel: open the full study for this exact occurrence
  if (typeof wordHtml === 'function') { var wordHtmlZ = wordHtml; wordHtml = function (k) { var h = wordHtmlZ(k); k = (k || 'H430').toUpperCase(); return h.replace('<button data-act="slpinw"', '<button class="pri" data-act="wsopen" data-k="' + k + '" data-r="' + (view === 'read' || view === 'analyze' ? esc(wzRef(cur.b, cur.c, cur.v)) : '') + '">' + ic('spark', 15) + ' Word study</button><button data-act="slpinw"'); }; }
  // sermon key words: link to the study, and list attached word studies
  var kwZ = keywords;
  keywords = function (s) { var h = kwZ(s).replace(/<a data-act="lab" data-k="([HG]\d+)">\1<\/a>/g, '<a data-act="lab" data-k="$1">$1</a> <a class="wzk" data-act="wsopen" data-k="$1">Word study</a>'); var w = s.wsr || []; return h + (w.length ? '<div class="smfact"><b>Attached word studies</b><ul>' + w.map(function (x) { return '<li><a data-act="wsopen" data-k="' + x.k + '">' + x.k + ' ' + esc(wzTr(x.k)) + '</a> — ' + esc(x.text) + '</li>'; }).join('') + '</ul></div>' : ''); };
  window.__wz = { WZ: WZ, WV: WV, occ: wzOcc, heb: wzHebAt, stats: wzHebStats, search: wzSearch, rels: wzRels };

  /* ============ 17. Resizable and stackable reading panes; licensed versions ============ */
  var PG = Object.assign({ below: {}, w: {}, h: 0.5 }, store.g('pgrid', {})), PGS = {};
  var pgsv = function () { store.s('pgrid', PG); };
  function pgKey(el) { var v = el.querySelector('.vs[data-vk]'); return v ? v.dataset.vk.replace(/:\d+$/, '') : ''; }
  function pgSave() { document.querySelectorAll('#rd .panes.stack .pane').forEach(function (el) { PGS[el.dataset.pv] = { k: pgKey(el), t: el.scrollTop }; }); }
  function pgApply() {
    var P = document.querySelector('#rd .panes'); if (!P || innerWidth <= 800) return;
    var panes = Array.prototype.slice.call(P.children).filter(function (e) { return e.classList.contains('pane'); });
    if (panes.length !== LAY.length) return;
    var top = [], bot = [];
    panes.forEach(function (el, i) { var v = LAY[i]; el.dataset.pv = v; (PG.below[v] ? bot : top).push(el); });
    if (!top.length) { top = bot; bot = []; }
    if (!P.classList.contains('solo')) {
      var row = function (list, cls) { var r = document.createElement('div'); r.className = 'prow ' + cls; list.forEach(function (el, i) { if (i) r.appendChild(pgGut('v', list[i - 1].dataset.pv, el.dataset.pv)); el.style.flex = (PG.w[el.dataset.pv] || 1) + ' 1 0'; r.appendChild(el); pgHead(el, cls); }); return r; };
      P.classList.add('pgrid'); P.style.gridTemplateColumns = ''; P.innerHTML = '';
      var T = row(top, 'top'); P.appendChild(T);
      if (bot.length) {
        P.classList.add('stack'); P.appendChild(pgGut('h')); var B = row(bot, 'bot'); P.appendChild(B);
        var rd = $('#rd'), H = Math.max(440, (rd ? rd.clientHeight : innerHeight) - 30); P.style.height = H + 'px';
        T.style.flex = PG.h + ' 1 0'; B.style.flex = (1 - PG.h) + ' 1 0';
        if (rd) rd.scrollTop += P.getBoundingClientRect().top - rd.getBoundingClientRect().top - 8;
        panes.forEach(function (el) { var s = PGS[el.dataset.pv], cv = el.querySelector('.vs.cv'); if (s && s.k === pgKey(el)) el.scrollTop = s.t; else if (cv) el.scrollTop = cv.offsetTop - el.offsetTop - 60; });
      }
    }
    var others = VL.filter(function (v) { return LAY.indexOf(v) < 0; });
    if (others.length) P.insertAdjacentHTML('afterend', '<div class="pgadd"><label>' + ic('plus', 14) + ' Add a Bible <select id="pgaddv" aria-label="Bible to add"><option value="">Choose…</option>' + others.map(function (v) { return '<option value="' + v + '">' + esc(v) + ' — ' + esc((VINFO[v] || [v])[0]) + '</option>'; }).join('') + '</select></label><select id="pgaddw" aria-label="Where to add it"><option value="side">beside</option><option value="below">below</option></select>' + (Object.keys(PG.w).length || PG.h !== 0.5 ? '<button class="lnk" data-act="pgreset">Reset pane sizes</button>' : '') + '<span class="dim small">Drag the lines between panes to resize them.</span></div>');
  }
  function pgGut(dir, a, b) { var g = document.createElement('div'); g.className = 'pgut ' + dir; g.tabIndex = 0; g.setAttribute('role', 'separator'); g.setAttribute('aria-orientation', dir === 'v' ? 'vertical' : 'horizontal'); g.setAttribute('aria-label', dir === 'v' ? 'Resize ' + a + ' and ' + b : 'Resize the top and bottom rows'); g.title = 'Drag to resize · double-click to make equal'; g.appendChild(document.createElement('i')); return g; }
  function pgHead(el, cls) { var ph = el.querySelector('.ph'); if (!ph || ph.querySelector('.pgmv')) return; var v = el.dataset.pv, b = document.createElement('button'); b.className = 'pgmv'; b.dataset.act = 'pgmove'; b.dataset.v = v; b.title = cls === 'bot' ? 'Move to the top row' : 'Move to the bottom row'; b.setAttribute('aria-label', b.title); b.innerHTML = cls === 'bot' ? '↑' : '↓'; var x = ph.querySelector('[data-act="tog"]'); if (x) ph.insertBefore(b, x); else ph.appendChild(b); }
  function pgWeights(row) { return Array.prototype.slice.call(row.querySelectorAll(':scope > .pane')); }
  var PD = null;
  document.addEventListener('pointerdown', function (e) {
    var g = e.target.closest && e.target.closest('.pgut'); if (!g) return; e.preventDefault();
    if (g.classList.contains('v')) { var a = g.previousElementSibling, b = g.nextElementSibling; PD = { g: g, d: 'v', a: a, b: b, x: e.clientX, wa: a.getBoundingClientRect().width, wb: b.getBoundingClientRect().width, ga: PG.w[a.dataset.pv] || 1, gb: PG.w[b.dataset.pv] || 1 }; }
    else { var P = g.parentElement, T = P.querySelector('.prow.top'), B = P.querySelector('.prow.bot'); PD = { g: g, d: 'h', T: T, B: B, y: e.clientY, ht: T.getBoundingClientRect().height, hb: B.getBoundingClientRect().height }; }
    g.classList.add('drag'); document.body.classList.add('pgdrag', PD.d === 'v' ? 'pgdv' : 'pgdh'); try { g.setPointerCapture(e.pointerId); } catch (x) {}
  });
  document.addEventListener('pointermove', function (e) {
    if (!PD) return;
    if (PD.d === 'v') { var tot = PD.wa + PD.wb, na = Math.min(tot * 0.85, Math.max(tot * 0.15, PD.wa + e.clientX - PD.x)), gt = PD.ga + PD.gb; PG.w[PD.a.dataset.pv] = +(gt * na / tot).toFixed(3); PG.w[PD.b.dataset.pv] = +(gt - PG.w[PD.a.dataset.pv]).toFixed(3); PD.a.style.flex = PG.w[PD.a.dataset.pv] + ' 1 0'; PD.b.style.flex = PG.w[PD.b.dataset.pv] + ' 1 0'; }
    else { var th = PD.ht + PD.hb, nt = Math.min(th * 0.85, Math.max(th * 0.15, PD.ht + e.clientY - PD.y)); PG.h = +(nt / th).toFixed(3); PD.T.style.flex = PG.h + ' 1 0'; PD.B.style.flex = (1 - PG.h) + ' 1 0'; }
  });
  var pgEnd = function () { if (!PD) return; PD.g.classList.remove('drag'); document.body.classList.remove('pgdrag', 'pgdv', 'pgdh'); PD = null; pgsv(); };
  document.addEventListener('pointerup', pgEnd); document.addEventListener('pointercancel', pgEnd);
  document.addEventListener('dblclick', function (e) { var g = e.target.closest && e.target.closest('.pgut'); if (!g) return; if (g.classList.contains('v')) { pgWeights(g.parentElement).forEach(function (el) { delete PG.w[el.dataset.pv]; el.style.flex = '1 1 0'; }); } else { PG.h = 0.5; var P = g.parentElement; P.querySelector('.prow.top').style.flex = '0.5 1 0'; P.querySelector('.prow.bot').style.flex = '0.5 1 0'; } pgsv(); });
  document.addEventListener('keydown', function (e) {
    var g = e.target.closest && e.target.closest('.pgut'); if (!g) return; var d = { ArrowLeft: -1, ArrowUp: -1, ArrowRight: 1, ArrowDown: 1 }[e.key]; if (!d) return; e.preventDefault(); e.stopPropagation();
    if (g.classList.contains('v')) { var a = g.previousElementSibling, b = g.nextElementSibling, ga = PG.w[a.dataset.pv] || 1, gb = PG.w[b.dataset.pv] || 1, t = ga + gb, na = Math.min(t * 0.85, Math.max(t * 0.15, ga + d * t * 0.05)); PG.w[a.dataset.pv] = +na.toFixed(3); PG.w[b.dataset.pv] = +(t - na).toFixed(3); a.style.flex = PG.w[a.dataset.pv] + ' 1 0'; b.style.flex = PG.w[b.dataset.pv] + ' 1 0'; }
    else { PG.h = Math.min(0.85, Math.max(0.15, PG.h + d * 0.05)); var P = g.parentElement; P.querySelector('.prow.top').style.flex = PG.h + ' 1 0'; P.querySelector('.prow.bot').style.flex = (1 - PG.h) + ' 1 0'; }
    pgsv();
  }, true);
  document.addEventListener('change', function (e) {
    if (e.target.id !== 'pgaddv' || !e.target.value) return; var v = e.target.value, w = ($('#pgaddw') || {}).value;
    if (LAY.indexOf(v) < 0) LAY.push(v); if (w === 'below') PG.below[v] = 1; else delete PG.below[v]; pgsv(); sv(); render();
  });
  var actP = act;
  act = function (a, d) {
    d = d || {};
    if (a === 'pgmove') { if (PG.below[d.v]) delete PG.below[d.v]; else PG.below[d.v] = 1; pgsv(); render(); return; }
    if (a === 'pgreset') { PG.w = {}; PG.h = 0.5; pgsv(); render(); return; }
    if (a === 'libimp') { var f = $('#fl'); if (f) f.click(); return; }
    return actP(a, d);
  };
  document.addEventListener('click', function (e) { var p = e.target.closest && e.target.closest('.pane'); if (!p || view !== 'read' || !document.querySelector('.panes.pgrid')) return; try { var a = APN; document.querySelectorAll('.pane').forEach(function (x) { x.classList.toggle('active', +x.dataset.pi === a); }); } catch (x) {} }, true);
  var goP = go;
  go = function (p, sc) { goP(p, sc); var P = document.querySelector('#rd .panes.stack'), rd = $('#rd'); if (P && rd) rd.scrollTop += P.getBoundingClientRect().top - rd.getBoundingClientRect().top - 8; };
  var renderP = render;
  render = function () { if (view === 'read') pgSave(); renderP(); if (view === 'read') pgApply(); };
  addEventListener('resize', function () { var P = document.querySelector('#rd .panes.stack'); if (P) { var rd = $('#rd'); P.style.height = Math.max(440, (rd ? rd.clientHeight : innerHeight) - 30) + 'px'; } });
  // licensed translations: explain and offer import of the reader's own copy
  var LICV = [['NASB', 'New American Standard Bible', 'The Lockman Foundation'], ['CSB', 'Christian Standard Bible', 'Holman Bible Publishers'], ['NLT', 'New Living Translation', 'Tyndale House Publishers'], ['AMP', 'Amplified Bible', 'The Lockman Foundation'], ['AMPC', 'Amplified Bible, Classic Edition', 'The Lockman Foundation'], ['NKJV', 'New King James Version', 'Thomas Nelson']];
  var libP = libraryHtml;
  libraryHtml = function () {
    var h = libP(); var have = function (ab) { return VL.some(function (v) { return v.toUpperCase() === ab; }); };
    var box = '<section class="licv"><h3>Copyrighted translations</h3><p>These versions are owned by their publishers, who do not allow them to be copied into apps, so they cannot be built into this Bible. If you have a licensed electronic copy, import it here: it stays on this device and works in every pane, side by side or below.</p><div class="licg">' + LICV.map(function (x) { var ok = have(x[0]); return '<div class="licc' + (ok ? ' ok' : '') + '"><b>' + x[0] + '</b><span>' + x[1] + '</span><small>© ' + x[2] + '</small>' + (ok ? '<em>✓ In your library</em>' : '') + '</div>'; }).join('') + '</div><p class="dim small">Import format: an XML file with &lt;book number="…"&gt;, &lt;chapter number="…"&gt; and &lt;verse number="…"&gt; elements. When asked for a name, use the abbreviation (for example NKJV).</p><button class="pri" data-act="libimp">' + ic('imp', 15) + ' Import a Bible file</button></section>';
    return h.replace(/<p class="dim" style="font-size:12px;margin-top:22px">Copyrighted translations[^<]*<\/p>/, box);
  };

  /* ============ 18. Imported Bibles saved online ============ */
  // Imported translations live in this browser's storage, which can be emptied (a new device, a cleared browser, an
  // updated app). Each imported Bible is also kept in the person's private online space, in its own collection so the
  // regular settings sync never downloads it, and is restored automatically wherever they open the app.
  var BL = { idx: null, busy: false, msg: '', q: [], pend: {}, removed: store.g('bl.removed', {}) };
  var BUILT = ['KJV', 'ASV', 'WEB', 'NET', 'Geneva', 'Bishops', 'Coverdale', 'HEB'];
  function blCol() { return SY.db.collection('data/users/' + SY.uid + '/blib/v1'); }
  function blSid(id) { return String(id).replace(/[^A-Za-z0-9_-]/g, '_'); }
  function blRead(k) { var c = blCol(); return retry(function () { return c.doc(k).get(); }).then(function (d) { if (!d.exists) return null; var b = d.data() || {}, n = b.n || 1, parts = [b.c || '']; var w = Promise.resolve(); for (var i = 1; i < n; i++) (function (i) { w = w.then(function () { return retry(function () { return c.doc(k + '~' + i).get(); }).then(function (x) { parts[i] = (x.exists && x.data().c) || ''; }); }); })(i); return w.then(function () { return parts.join(''); }); }); }
  function blWrite(k, v) { var c = blCol(), n = Math.max(1, Math.ceil(v.length / CH)), w = Promise.resolve(); for (var i = 1; i < n; i++) (function (i) { w = w.then(function () { return retry(function () { return c.doc(k + '~' + i).set({ c: v.slice(i * CH, (i + 1) * CH) }); }); }); })(i); return w.then(function () { return retry(function () { return c.doc(k).set({ t: Date.now(), n: n, c: v.slice(0, CH) }); }); }); }
  function blDel(k) { var c = blCol(); return retry(function () { return c.doc(k).get(); }).then(function (d) { var n = d.exists ? (d.data().n || 1) : 0, w = Promise.resolve(); for (var i = 1; i < n; i++) (function (i) { w = w.then(function () { return c.doc(k + '~' + i).delete(); }); })(i); return w.then(function () { return d.exists ? c.doc(k).delete() : null; }); }); }
  function blMsg(m) { BL.msg = m; var el = document.getElementById('blst'); if (el) el.textContent = m; }
  function blIdxGet() { return blRead('index').then(function (v) { try { return v ? JSON.parse(v) : { list: [] }; } catch (e) { return { list: [] }; } }); }
  function blIdxPut(fn) { return blIdxGet().then(function (ix) { fn(ix); BL.idx = ix; return blWrite('index', JSON.stringify(ix)); }); }
  function blLocal(id) { return BIB[id] ? Promise.resolve(BIB[id]) : Promise.resolve(idbGet(id)).catch(function () { return null; }); }
  function blUpload(id) {
    return blLocal(id).then(function (data) {
      if (!data || !Object.keys(data).length) return;
      var books = Object.keys(data), sid = blSid(id), w = Promise.resolve();
      books.forEach(function (b, i) { w = w.then(function () { blMsg('Saving ' + id + ' online… ' + Math.round(i / books.length * 100) + '%'); return blWrite('b~' + sid + '~' + i, JSON.stringify(data[b])); }); });
      return w.then(function () { return blIdxPut(function (ix) { ix.list = ix.list.filter(function (x) { return x.id !== id; }); ix.list.push({ id: id, meta: META[id] || { name: id }, books: books, at: Date.now() }); }); }).then(function () { delete BL.removed[id]; store.s('bl.removed', BL.removed); blMsg(id + ' is saved online.'); });
    });
  }
  function blDownload(ent) {
    if (BL.pend[ent.id]) return BL.pend[ent.id];
    var sid = blSid(ent.id), data = {}, w = Promise.resolve();
    ent.books.forEach(function (b, i) { w = w.then(function () { blMsg('Restoring ' + ent.id + '… ' + Math.round(i / ent.books.length * 100) + '%'); return blRead('b~' + sid + '~' + i).then(function (v) { if (v) data[b] = JSON.parse(v); }); }); });
    return (BL.pend[ent.id] = w.then(function () {
      if (!Object.keys(data).length) throw new Error('empty');
      apply(ent.id, data); return Promise.resolve(save(ent.id, data)).catch(function () {});
    }).then(function () { blMsg(ent.id + ' restored from your online library.'); delete BL.pend[ent.id]; render(); }).catch(function (e) { delete BL.pend[ent.id]; blMsg('Could not restore ' + ent.id + ' right now. It will try again next time.'); throw e; }));
  }
  function blRegister(ent) { if (!META[ent.id]) { META[ent.id] = ent.meta || { name: ent.id }; store.s('vmeta', META); } regVer(ent.id, META[ent.id]); }
  function blRun() {
    if (BL.busy || !SY.db || !SY.uid) return; BL.busy = true;
    blIdxGet().then(function (ix) {
      BL.idx = ix; var chain = Promise.resolve(), changed = false;
      ix.list.forEach(function (ent) { if (BL.removed[ent.id]) return; if (!META[ent.id]) changed = true; blRegister(ent); });
      if (changed) render();
      // restore any that this browser no longer holds
      ix.list.forEach(function (ent) { if (BL.removed[ent.id]) return; chain = chain.then(function () { return blLocal(ent.id).then(function (d) { if (!d) return blDownload(ent).catch(function () {}); }); }); });
      // save any imported here that are not online yet
      Object.keys(META).forEach(function (id) { if (BUILT.indexOf(id) >= 0 || /^LEXICON/.test(id) || ix.list.some(function (x) { return x.id === id; })) return; chain = chain.then(function () { return blUpload(id).catch(function () { blMsg('Could not save ' + id + ' online right now. It will try again.'); }); }); });
      // versions removed on this device: take them out of the online library too
      Object.keys(BL.removed).forEach(function (id) { if (!ix.list.some(function (x) { return x.id === id; })) return; chain = chain.then(function () { return blForget(id); }); });
      return chain;
    }).catch(function () { blMsg('Your online library is not reachable right now.'); }).then(function () { BL.busy = false; if (BL.again) { BL.again = false; blRun(); } var el = document.getElementById('blst'); if (el && !Object.keys(BL.pend).length) render(); });
  }
  function blForget(id) {
    var ent = BL.idx && BL.idx.list.filter(function (x) { return x.id === id; })[0], sid = blSid(id), w = Promise.resolve();
    if (ent) ent.books.forEach(function (b, i) { w = w.then(function () { return blDel('b~' + sid + '~' + i); }); });
    return w.then(function () { return blIdxPut(function (ix) { ix.list = ix.list.filter(function (x) { return x.id !== id; }); }); }).then(function () { delete BL.removed[id]; store.s('bl.removed', BL.removed); blMsg(id + ' was removed from your online library.'); }).catch(function () {});
  }
  // start once the online save is connected
  var blT = setInterval(function () { if (SY.db && SY.uid) { clearInterval(blT); blRun(); } else if (SY.state === 'local') clearInterval(blT); }, 800);
  // a new import is saved online as soon as it is stored here
  var saveB = save;
  save = function (n, d) { var r = saveB(n, d); if (META[n] && BUILT.indexOf(n) < 0 && !/^LEXICON/.test(n) && SY.db && !(BL.idx && BL.idx.list.some(function (x) { return x.id === n; })) && !BL.pend[n]) { delete BL.removed[n]; store.s('bl.removed', BL.removed); Promise.resolve(r).then(function () { if (BL.busy) BL.again = true; else blRun(); }); } return r; };
  // removing a version on this device also removes the online copy
  var idbDelB = idbDel;
  idbDel = function (k) { var r = idbDelB(k); if (BUILT.indexOf(k) < 0 && !/^LEXICON/.test(k)) { BL.removed[k] = 1; store.s('bl.removed', BL.removed); if (SY.db) { if (BL.busy) BL.again = true; else blRun(); } } return r; };
  // opening a version whose data this browser lost: fetch it from the online library
  var loadVerB = loadVer;
  loadVer = function (n) { return Promise.resolve(loadVerB(n)).then(function () { if (BIB[n] || !META[n] || !SY.db) return; var ent = BL.idx && BL.idx.list.filter(function (x) { return x.id === n; })[0]; if (ent) return blDownload(ent).catch(function () {}); }); };
  // ask the browser to keep this app's storage
  try { if (navigator.storage && navigator.storage.persist) navigator.storage.persist(); } catch (e) {}
  // library: show the state of the online copies
  var libB = libraryHtml;
  libraryHtml = function () {
    var h = libB(), on = BL.idx ? BL.idx.list.map(function (x) { return x.id; }) : [];
    var line = '<p class="blst"><span id="blst">' + esc(BL.msg || (SY.db ? (on.length ? on.length + ' imported Bible' + (on.length > 1 ? 's are' : ' is') + ' saved online: ' + on.join(', ') + '. They load by themselves on any device where you open this app.' : 'Bibles you import are saved online automatically.') : 'Imported Bibles are saved on this device. Sign in to claude.ai to keep them online as well.')) + '</span></p>';
    h = h.replace('<label class="dropz"', line + '<label class="dropz"');
    return h.replace(/<em>✓ In your library<\/em>/g, function (m) { return m; });
  };
  window.__bl = BL;

  /* ============ 19. Other Books: further reading outside the 66 books ============ */
  SYNC_KEYS.push('obk');
  var OB = { data: null, err: '', loading: false, q: '', res: null, sel: null };
  var OBK = Object.assign({ open: null, pos: {}, read: {} }, store.g('obk', {}));
  var obsv = function () { store.s('obk', OBK); };
  function obLoad() { if (OB.data || OB.loading) return; OB.loading = true; fetch('books.json').then(function (r) { if (!r.ok) throw 0; return r.json(); }).then(function (j) { OB.data = j; OB.loading = false; if (view === 'obooks') render(); }).catch(function () { OB.loading = false; OB.err = 'The books could not be loaded. Check your connection and open this page again.'; if (view === 'obooks') render(); }); }
  function obBook(id) { return OB.data && OB.data.books.filter(function (b) { return b.id === id; })[0]; }
  function obProg(b) { var r = OBK.read[b.id] || {}, n = Object.keys(r).length; return [n, b.ch.length]; }
  function obLabel(s) { return 'Chapter ' + s.c + (s.note ? ' (' + s.note.toLowerCase() + ')' : ''); }
  function obShelf() {
    if (!OB.data) { obLoad(); return '<div class="home obk"><div class="greet"><button class="ib mobm" data-act="side" aria-label="Menu">' + ic('menu') + '</button><h1>Other Books</h1></div><p class="dim">' + esc(OB.err || 'Loading the books…') + '</p></div>'; }
    return '<div class="home obk"><div class="greet"><button class="ib mobm" data-act="side" aria-label="Menu">' + ic('menu') + '</button><div><h1>Other Books</h1></div></div><p class="obintro">Ancient writings outside the 66 books of the Bible, for reading and study. Read them alongside Scripture and weigh them by it.</p><div class="obshelf">' +
      OB.data.books.map(function (b) { var p = obProg(b), pos = OBK.pos[b.id], pc = Math.round(p[0] / p[1] * 100); return '<article class="obcard"><div class="obspine" aria-hidden="true"><span>' + esc(b.short) + '</span></div><div class="obbody"><h2>' + esc(b.title) + '</h2><p class="obsub">' + esc(b.sub) + '</p>' + b.about.map(function (t) { return '<p>' + esc(t) + '</p>'; }).join('') + '<p class="obmeta">' + esc(b.trans) + ' ' + esc(b.licence) + '. ' + b.ch.length + ' chapters.</p>' + (p[0] ? '<span class="rpg"><i style="width:' + pc + '%"></i></span><small class="dim">' + p[0] + ' of ' + p[1] + ' chapters read</small>' : '') + '<div class="row" style="gap:8px;margin-top:12px"><button class="pri" data-act="obopen" data-b="' + b.id + '">' + (pos ? 'Continue at ' + esc(obLabel(b.ch[pos.i] || b.ch[0])) : 'Start reading') + '</button>' + (pos ? '<button data-act="obopen" data-b="' + b.id + '" data-i="0">From the beginning</button>' : '') + '</div></div></article>'; }).join('') + '</div></div>';
  }
  function obVerse(b, s, v) {
    var t = v[1], ref = b.short + ' ' + s.c + ':' + v[0], on = OB.sel === ref;
    var body = typeof t === 'string' ? esc(t) : '<span class="obpar"><span><b>' + esc(t.el) + '</b> ' + esc(t.E) + '</span><span><b>' + esc(t.gl) + '</b> ' + esc(t.G || '—') + '</span></span>';
    return '<p class="obv' + (on ? ' on' : '') + '" id="obv-' + v[0] + '" data-act="obsel" data-r="' + esc(ref) + '"><sup>' + v[0] + '</sup>' + body + (on ? '<span class="obvact"><button data-act="obcopy" data-r="' + esc(ref) + '">' + ic('copy', 13) + ' Copy</button></span>' : '') + '</p>';
  }
  function obReader(b) {
    var pos = OBK.pos[b.id] || { i: 0 }, i = Math.min(Math.max(0, pos.i), b.ch.length - 1), s = b.ch[i], read = (OBK.read[b.id] || {})[i];
    var res = OB.res && OB.res.b === b.id ? OB.res : null;
    return '<div class="obr"><header class="obh"><button class="ib mobm" data-act="side" aria-label="Menu">' + ic('menu') + '</button><a data-act="obshelf">' + ic('back', 14) + ' Other Books</a><b>' + esc(b.title) + '</b><span class="sp"></span><div class="obsrch" role="search"><input id="obq" value="' + esc(OB.q) + '" placeholder="Search ' + esc(b.short) + '" aria-label="Search this book"><button data-act="obsearch" aria-label="Search">' + ic('search', 15) + '</button></div></header>' +
      (res ? '<section class="obres"><div class="row" style="justify-content:space-between"><b>' + res.hits.length + (res.hits.length === 200 ? '+' : '') + ' verses with “' + esc(res.q) + '”</b><button class="lnk" data-act="obclear">Close search</button></div>' + (res.hits.length ? '<ol>' + res.hits.map(function (h) { return '<li><a data-act="obgo" data-i="' + h.i + '" data-v="' + h.v + '"><b>' + esc(obLabel(b.ch[h.i])) + ':' + h.v + '</b> ' + h.html + '</a></li>'; }).join('') + '</ol>' : '<p class="dim">No verses found.</p>') + '</section>' : '') +
      '<nav class="obnav" aria-label="Chapters"><button class="ib" data-act="obch" data-d="-1"' + (i ? '' : ' disabled') + ' aria-label="Previous chapter">' + ic('cl', 16) + '</button><select id="obsel" aria-label="Chapter">' + b.ch.map(function (x, j) { return '<option value="' + j + '"' + (j === i ? ' selected' : '') + '>' + esc(obLabel(x)) + ((OBK.read[b.id] || {})[j] ? ' ✓' : '') + '</option>'; }).join('') + '</select><button class="ib" data-act="obch" data-d="1"' + (i < b.ch.length - 1 ? '' : ' disabled') + ' aria-label="Next chapter">' + ic('cr', 16) + '</button></nav>' +
      '<article class="obtext"><h1>' + esc(b.title) + '</h1><h2>' + esc(obLabel(s)) + '</h2>' + (i === 0 && b.opening ? '<p class="obopen">' + esc(b.opening) + '</p>' : '') + (s.title ? '<p class="obopen">' + esc(s.title) + '</p>' : '') + s.v.map(function (v) { return obVerse(b, s, v); }).join('') +
      '<div class="obfoot"><button class="' + (read ? '' : 'pri') + '" data-act="obdone">' + (read ? ic('check', 14) + ' Read' : 'Mark as read' + (i < b.ch.length - 1 ? ' and continue' : '')) + '</button></div></article>' +
      (b.legend ? '<details class="oblegend"><summary>Signs used in this translation</summary><dl>' + b.legend.map(function (x) { return '<dt>' + esc(x[0]) + '</dt><dd>' + esc(x[1]) + '</dd>'; }).join('') + '</dl></details>' : '') +
      '<p class="obsrc">' + esc([b.trans, b.licence ? b.licence + '.' : '', b.source].filter(Boolean).join(' ')) + '</p></div>';
  }
  function obView() { if (!OB.data) return obShelf(); var b = OBK.open && obBook(OBK.open); return b ? obReader(b) : obShelf(); }
  function obSearch(b, q) { var rx = new RegExp(q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i'), hits = []; b.ch.forEach(function (s, i) { s.v.forEach(function (v) { if (hits.length >= 200) return; var t = typeof v[1] === 'string' ? v[1] : v[1].E + ' ' + v[1].G, m = rx.exec(t); if (m) { var a = Math.max(0, m.index - 60), z = Math.min(t.length, m.index + q.length + 80); hits.push({ i: i, v: v[0], html: (a ? '…' : '') + esc(t.slice(a, m.index)) + '<mark>' + esc(t.substr(m.index, q.length)) + '</mark>' + esc(t.slice(m.index + q.length, z)) + (z < t.length ? '…' : '') }); } }); }); return hits; }
  function obTop() { var m = $('#main'); if (m) m.scrollTop = 0; window.scrollTo(0, 0); }
  document.addEventListener('keydown', function (e) { if (e.target && e.target.id === 'obq' && e.key === 'Enter') { e.preventDefault(); act('obsearch', {}); } });
  document.addEventListener('change', function (e) { if (e.target && e.target.id === 'obsel') { var b = obBook(OBK.open); if (!b) return; OBK.pos[b.id] = { i: +e.target.value }; OB.sel = null; obsv(); render(); obTop(); } });
  var actO = act;
  act = function (a, d) {
    d = d || {}; var b = OBK.open && obBook(OBK.open);
    switch (a) {
      case 'obooks': view = 'obooks'; if (innerWidth <= 800) side = false; sv(); render(); return;
      case 'obshelf': OBK.open = null; OB.res = null; obsv(); render(); obTop(); return;
      case 'obopen': OBK.open = d.b; if (d.i != null) OBK.pos[d.b] = { i: +d.i }; OB.res = null; OB.q = ''; OB.sel = null; obsv(); render(); obTop(); return;
      case 'obch': if (!b) return; var i = ((OBK.pos[b.id] || {}).i || 0) + +d.d; if (i < 0 || i >= b.ch.length) return; OBK.pos[b.id] = { i: i }; OB.sel = null; obsv(); render(); obTop(); return;
      case 'obdone': { if (!b) return; var i2 = (OBK.pos[b.id] || {}).i || 0, r = OBK.read[b.id] = OBK.read[b.id] || {}; if (r[i2]) { delete r[i2]; obsv(); render(); return; } r[i2] = day(); if (i2 < b.ch.length - 1) OBK.pos[b.id] = { i: i2 + 1 }; obsv(); render(); obTop(); if (i2 === b.ch.length - 1) toast('You have reached the end of ' + b.title); return; }
      case 'obsel': OB.sel = OB.sel === d.r ? null : d.r; render(); return;
      case 'obcopy': { if (!b) return; var m = /:(\d+)$/.exec(d.r), s = b.ch[(OBK.pos[b.id] || {}).i || 0], v = s && s.v.filter(function (x) { return x[0] === +m[1]; })[0]; if (!v) return; var t = typeof v[1] === 'string' ? v[1] : v[1].el + ': ' + v[1].E + '\n' + v[1].gl + ': ' + v[1].G; var txt = '“' + t + '” — ' + b.title + ' ' + s.c + ':' + v[0] + ' (' + b.trans.split(' (')[0].replace(/\.$/, '') + ')'; try { navigator.clipboard.writeText(txt).then(function () { toast('Copied'); }, function () { toast('Copy is not available here'); }); } catch (x) { toast('Copy is not available here'); } return; }
      case 'obsearch': { if (!b) return; var q = (($('#obq') || {}).value || '').trim(); OB.q = q; if (q.length < 2) { toast('Type at least two letters'); return; } OB.res = { b: b.id, q: q, hits: obSearch(b, q) }; render(); return; }
      case 'obclear': OB.res = null; OB.q = ''; render(); return;
      case 'obgo': { if (!b) return; OBK.pos[b.id] = { i: +d.i }; obsv(); render(); var el = document.getElementById('obv-' + d.v); if (el) { el.scrollIntoView({ block: 'center' }); el.classList.add('flash'); } return; }
    }
    return actO(a, d);
  };
  var side5 = sideHtml;
  sideHtml = function () { return side5().replace('</nav>', '</nav><nav class="obnavs" aria-label="Other books"><h5 class="lb">Reference</h5><button data-act="obooks" class="' + (view === 'obooks' ? 'on' : '') + '" title="Other Books">' + ic('library') + '<span class="lb">Other Books</span></button></nav>'); };
  var renderO = render;
  render = function () { renderO(); if (view === 'obooks') { $('#main').innerHTML = obView(); var dr = $('#drawer'); if (dr) dr.classList.remove('open'); var tb = $('#tb'); if (tb) tb.style.display = 'none'; } };

  /* ============ 20. Other Books: a shared shelf the owner can add to ============ */
  // Books bundled with the app (books.json) are visible to everyone. Books the owner adds are parsed in the browser
  // (PDF via the bundled pdf.js, or plain text) and stored in the shared `shelf` collection, which every signed-in
  // viewer can read and only the owner can write.
  var SH = { db: null, owner: false, list: [], content: {}, loaded: false, add: null, edit: null, busy: '' };
  function shCol() { return SH.db.collection('shelf'); }
  function shRead(k) { var c = shCol(); return retry(function () { return c.doc(k).get(); }).then(function (d) { if (!d.exists) return null; var b = d.data() || {}, n = b.n || 1, parts = [b.c || ''], w = Promise.resolve(); for (var i = 1; i < n; i++) (function (i) { w = w.then(function () { return retry(function () { return c.doc(k + '~' + i).get(); }).then(function (x) { parts[i] = (x.exists && x.data().c) || ''; }); }); })(i); return w.then(function () { return parts.join(''); }); }); }
  function shWrite(k, v, prog) { var c = shCol(), n = Math.max(1, Math.ceil(v.length / CH)), w = Promise.resolve(); for (var i = 1; i < n; i++) (function (i) { w = w.then(function () { if (prog) prog(i / n); return retry(function () { return c.doc(k + '~' + i).set({ c: v.slice(i * CH, (i + 1) * CH) }); }); }); })(i); return w.then(function () { return retry(function () { return c.doc(k).set({ t: Date.now(), n: n, c: v.slice(0, CH) }); }); }); }
  function shDel(k) { var c = shCol(); return retry(function () { return c.doc(k).get(); }).then(function (d) { var n = d.exists ? (d.data().n || 1) : 0, w = Promise.resolve(); for (var i = 1; i < n; i++) (function (i) { w = w.then(function () { return c.doc(k + '~' + i).delete(); }); })(i); return w.then(function () { return d.exists ? c.doc(k).delete() : null; }); }); }
  function shLoad() {
    var cl = window.claude; if (!cl || typeof cl.use !== 'function') { SH.loaded = true; return; }
    Promise.all([cl.use('db'), cl.use('user')]).then(function (r) {
      SH.db = r[0]; var u = r[1];
      return Promise.all([u ? Promise.resolve(u.isOwner()).catch(function () { return false; }) : false, SH.db ? shRead('index').catch(function () { return null; }) : null]);
    }).then(function (r) { SH.owner = !!r[0]; try { SH.list = r[1] ? JSON.parse(r[1]).list || [] : []; } catch (e) { SH.list = []; } SH.loaded = true; if (view === 'obooks') render(); }).catch(function () { SH.loaded = true; });
  }
  setTimeout(shLoad, 0); window.__sh = function () { return SH; }; window.__obk = function () { return OBK; };
  function shIndexPut(fn) { return shRead('index').then(function (v) { var ix; try { ix = v ? JSON.parse(v) : { list: [] }; } catch (e) { ix = { list: [] }; } fn(ix); SH.list = ix.list; return shWrite('index', JSON.stringify(ix)); }); }
  // every book on the shelf: bundled ones first, then the owner's
  var obBookB = obBook;
  obBook = function (id) { var b = obBookB(id); if (b) return b; var m = SH.list.filter(function (x) { return x.id === id; })[0]; if (!m) return null; var base = { trans: '', licence: '', source: '', sub: '', about: [], short: m.title }, c = SH.content[id]; return c ? Object.assign(base, m, c) : Object.assign(base, { pending: true }, m); };
  function shAll() { return (OB.data ? OB.data.books : []).concat(SH.list.map(function (m) { return obBook(m.id); })); }
  obProg = function (b) { var r = OBK.read[b.id] || {}, n = Object.keys(r).length; return [n, b.ch ? b.ch.length : (b.nch || 1)]; };
  obLabel = function (s) { return s.c === 0 ? (s.note || 'Introduction') : s.c === -1 ? s.note : 'Chapter ' + s.c + (s.note ? ' (' + s.note.toLowerCase() + ')' : ''); };
  obShelf = function () {
    if (!OB.data && !OB.err) { obLoad(); return '<div class="home obk"><div class="greet"><button class="ib mobm" data-act="side" aria-label="Menu">' + ic('menu') + '</button><h1>Other Books</h1></div><p class="dim">Loading the books…</p></div>'; }
    var books = shAll();
    return '<div class="home obk"><div class="greet"><button class="ib mobm" data-act="side" aria-label="Menu">' + ic('menu') + '</button><div><h1>Other Books</h1></div>' + (SH.owner ? '<span class="sp"></span><button class="pri" data-act="shadd">' + ic('plus', 15) + ' Add a book</button>' : '') + '</div><p class="obintro">Writings outside the 66 books of the Bible, kept here as extra references for study. Read them alongside Scripture and weigh them by it.</p>' +
      (SH.add ? shAddHtml() : '') + (OB.err ? '<p class="dim">' + esc(OB.err) + '</p>' : '') +
      '<div class="obshelf">' + books.map(function (b) { var p = obProg(b), pos = OBK.pos[b.id], pc = Math.round(p[0] / p[1] * 100), mine = !OB.data || !OB.data.books.some(function (x) { return x.id === b.id; });
        if (SH.edit === b.id) return shEditHtml(b);
        return '<article class="obcard"><div class="obspine" aria-hidden="true"><span>' + esc(b.short || b.title) + '</span></div><div class="obbody"><h2>' + esc(b.title) + '</h2>' + (b.sub ? '<p class="obsub">' + esc(b.sub) + '</p>' : '') + (b.about || []).map(function (t) { return '<p>' + esc(t) + '</p>'; }).join('') + '<p class="obmeta">' + esc([b.trans, b.licence ? b.licence + '.' : ''].filter(Boolean).join(' ')) + ' ' + (b.nch || (b.ch && b.ch.length) || '') + ((b.nch || b.ch) ? ' sections.' : '') + '</p>' + (p[0] ? '<span class="rpg"><i style="width:' + pc + '%"></i></span><small class="dim">' + p[0] + ' of ' + p[1] + ' read</small>' : '') +
          '<div class="row" style="gap:8px;margin-top:12px;flex-wrap:wrap"><button class="pri" data-act="obopen" data-b="' + b.id + '">' + (pos ? 'Continue reading' : 'Start reading') + '</button>' + (pos ? '<button data-act="obopen" data-b="' + b.id + '" data-i="0">From the beginning</button>' : '') + (SH.owner && mine ? '<button data-act="shedit" data-b="' + b.id + '">Edit details</button><button data-act="shrm" data-b="' + b.id + '" class="' + (SH.cf === b.id ? 'warn' : '') + '">' + (SH.cf === b.id ? 'Tap again to remove' : 'Remove') + '</button>' : '') + '</div></div></article>'; }).join('') + '</div>' +
      (!SH.db && SH.loaded ? '<p class="dim small" style="margin-top:16px">Sign in to claude.ai to see books added to this shelf since the app was published.</p>' : '') + '</div>';
  };
  var obViewB = obView;
  obView = function () { var b = OBK.open && obBook(OBK.open); if (b && b.pending) { shOpen(b.id); return '<div class="obr"><p class="dim">Opening ' + esc(b.title) + '…</p></div>'; } return obViewB(); };
  function shOpen(id) { if (SH.content[id] || SH.opening === id) return; SH.opening = id; shRead('b~' + id).then(function (v) { SH.content[id] = JSON.parse(v); SH.opening = null; render(); }).catch(function () { SH.opening = null; OBK.open = null; toast('That book could not be opened right now'); render(); }); }

  /* ---- adding a book (owner) ---- */
  var ROMAN = { I: 1, V: 5, X: 10, L: 50, C: 100 };
  function roman(s) { var n = 0; for (var i = 0; i < s.length; i++) { var a = ROMAN[s[i]], b = ROMAN[s[i + 1]] || 0; if (!a) return NaN; n += a < b ? -a : a; } return n; }
  var CHRX = /^(?:chapter|chap\.?)\s+([0-9]{1,3}|[IVXLC]{1,7})\b\.?\s*(.*)$/i;
  function shExtractPdf(file, prog) {
    return import('./vendor/pdf.min.mjs').then(function (pdfjs) {
      pdfjs.GlobalWorkerOptions.workerSrc = new URL('vendor/pdf.worker.min.mjs', location.href).href;
      return file.arrayBuffer().then(function (buf) { return pdfjs.getDocument({ data: buf, isEvalSupported: false }).promise; }).then(function (doc) {
        var pages = [], w = Promise.resolve();
        for (var p = 1; p <= doc.numPages; p++) (function (p) { w = w.then(function () { return doc.getPage(p).then(function (pg) { return pg.getTextContent(); }).then(function (tc) { var lines = [], cur = ''; tc.items.forEach(function (it) { cur += it.str; if (it.hasEOL) { lines.push(cur); cur = ''; } }); if (cur) lines.push(cur); pages.push(lines.map(function (l) { return l.replace(/\s+/g, ' ').trim(); }).filter(Boolean)); if (prog) prog(p / doc.numPages); }); }); })(p);
        return w.then(function () { return doc.getMetadata().then(function (md) { pages.title = md && md.info && md.info.Title || ''; return pages; }, function () { return pages; }); });
      });
    });
  }
  function shExtractText(file) { return file.text().then(function (t) { var L = t.replace(/\r/g, '').split('\n'), pages = [], cur = []; L.forEach(function (l) { if (/\f/.test(l)) { pages.push(cur); cur = []; } cur.push(l.replace(/\f/g, '').trim()); }); pages.push(cur); return pages; }); }
  var HDRX = /^(chapter|chap\.?|book of [a-z][\w ]{0,24}?|section|part|psalm)\s+(\d{1,3}|[ivxlc]{1,7})\b\.?\s*(.{0,80})$/i;
  function shParse(pages) {
    // drop running headers and footers: short lines repeated on many pages (page numbers included)
    var freq = {}, norm = function (l) { return l.replace(/\d+/g, '#').toLowerCase(); };
    pages.forEach(function (pg) { var seen = {}; pg.forEach(function (l) { var k = norm(l); if (!seen[k]) { seen[k] = 1; freq[k] = (freq[k] || 0) + 1; } }); });
    var lim = Math.max(3, pages.length * 0.2), lines = [];
    pages.forEach(function (pg) { pg.forEach(function (l) { if (!l) { lines.push(''); return; } if (/^\d{1,4}$/.test(l) || /^page \d+/i.test(l)) return; if (l.length < 70 && freq[norm(l)] >= lim && !HDRX.test(l)) return; lines.push(l); }); lines.push(''); });
    // chapter headings: of the heading styles found, use the one whose numbers each appear once (running headers repeat)
    var cand = [], styles = {};
    lines.forEach(function (l, i) { var m = l.length < 90 && HDRX.exec(l); if (!m) return; var n = /^\d/.test(m[2]) ? +m[2] : roman(m[2].toUpperCase()); if (!n) return; var aft = l.slice(m[1].length).replace(/^\s+/, '').slice(m[2].length), key = m[1].toLowerCase().replace(/\s+/g, ' ') + ' #' + (/^\d/.test(m[2]) ? '' : 'r') + (aft[0] === '.' ? '.' : ''); if (/^\d+$/.test(m[3].trim())) key += ' #'; cand.push({ i: i, n: n, key: key, note: m[3].replace(/^[\s.:—-]+|[\s()]+$/g, '').replace(/^\(/, '') }); var st = styles[key] = styles[key] || { occ: 0, nums: {} }; st.occ++; st.nums[n] = 1; });
    var best = null, bs = 0; Object.keys(styles).forEach(function (k) { var st = styles[k], u = Object.keys(st.nums).length, sc = u * (u / st.occ); if (/ # #$/.test(k)) sc = 0; if (st.occ >= 2 && sc > bs) { bs = sc; best = k; } });
    var heads = best ? cand.filter(function (c, j) { if (c.key !== best) return false; var nx = cand[j + 1]; return !(nx && nx.key === best && nx.i - c.i <= 2); }) : [];
    var isHead = {}; cand.forEach(function (c) { isHead[c.i] = 1; });
    var secs = [], front = [];
    var toVerses = function (ls) {
      var v = [], last = 0;
      ls.forEach(function (l) { if (!l) { if (v.length && v[v.length - 1][0] == null) v[v.length - 1].brk = 1; return; } var m = /^([\[⌈<(]*)(\d{1,3})(?:[.)]\s*|\s+|(?=[A-Z“"'‘]))(\S.*)$/.exec(l); if (m && +m[2] === last + 1 && (last > 0 || +m[2] === 1 || !v.length)) { v.push([+m[2], m[1] + m[3]]); last = +m[2]; return; } var p = v[v.length - 1]; if (p && !(p[0] == null && p.brk)) p[1] += (p[1].endsWith('-') ? '' : ' ') + l; else v.push([null, l]); });
      return v.map(function (x) { return [x[0], x[1]]; });
    };
    var strip = function (ls) { return ls.filter(function (l, k) { return true; }); };
    if (heads.length >= 2) {
      front = lines.slice(0, heads[0].i);
      heads.forEach(function (h, k) { var body = []; for (var i = h.i + 1; i < (k < heads.length - 1 ? heads[k + 1].i : lines.length); i++) if (!isHead[i]) body.push(lines[i]); var v = toVerses(body); while (v.length && v[0][0] == null && v[0][1].length < 400 && v[0][1] === v[0][1].toUpperCase() && v.length > 1 && v[1][0] === 1) { h.title = (h.title ? h.title + ' ' : '') + v[0][1]; v.shift(); } secs.push({ c: h.n, note: h.note, v: v, title: h.title || '' }); });
    } else {
      var per = 8, buf = [];
      pages.forEach(function (pg, i) { buf = buf.concat(pg.filter(function (l) { return !/^\d{1,4}$/.test(l); })).concat(['']); if ((i + 1) % per === 0 || i === pages.length - 1) { secs.push({ c: -1, note: 'Pages ' + (i - (i % per) + 1) + '–' + (i + 1), v: toVerses(buf) }); buf = []; } });
    }
    var vcount = secs.reduce(function (a, s) { return a + s.v.filter(function (v) { return v[0] != null; }).length; }, 0);
    return { secs: secs, front: toVerses(front.filter(function (l, i) { return !isHead[i]; })).filter(function (v) { return v[1].trim(); }), heads: heads.length, verses: vcount };
  }
  function shTitleGuess(name, pages) { if (pages.title && pages.title.length < 120) return pages.title.trim(); return name.replace(/\.[a-z0-9]+$/i, '').replace(/^[0-9a-f]{6,}[-_ ]+/i, '').replace(/[-_]+/g, ' ').replace(/\b(free )?pdf( download)?\b/gi, '').replace(/\s+/g, ' ').trim(); }
  function shAddHtml() {
    var A = SH.add;
    if (A.stage === 'pick') return '<section class="shadd"><div class="row" style="justify-content:space-between"><h2>Add a book</h2><button class="ib" data-act="shaddx" aria-label="Cancel">' + ic('x', 16) + '</button></div><p>Choose a PDF or a text file. The book is read here in your browser, split into its chapters, and shown to you before anything is saved.</p><label class="dropz"><input type="file" id="shfile" accept=".pdf,.txt,.md,application/pdf,text/plain" hidden>' + ic('imp', 28) + '<b>Choose a file</b><span>PDF or plain text</span></label>' + (A.err ? '<p class="smbad">' + esc(A.err) + '</p>' : '') + '</section>';
    if (A.stage === 'reading') return '<section class="shadd"><h2>Reading ' + esc(A.name) + '…</h2><span class="rpg"><i style="width:' + Math.round((A.p || 0) * 100) + '%"></i></span></section>';
    var P = A.parsed, s0 = P.secs[A.prev || 0] || { v: [] };
    var f = function (k, l, ph, ta) { return '<label class="smf"><span class="sml">' + l + '</span>' + (ta ? '<textarea data-sha="' + k + '" rows="3" placeholder="' + esc(ph) + '">' + esc(A.m[k] || '') + '</textarea>' : '<input data-sha="' + k + '" value="' + esc(A.m[k] || '') + '" placeholder="' + esc(ph) + '">') + '</label>'; };
    return '<section class="shadd"><div class="row" style="justify-content:space-between"><h2>Check “' + esc(A.name) + '”</h2><button class="ib" data-act="shaddx" aria-label="Cancel">' + ic('x', 16) + '</button></div>' +
      '<p class="smnote' + (P.heads >= 2 ? ' ok' : '') + '">' + (P.heads >= 2 ? 'Found ' + P.heads + ' chapters' + (P.verses ? ' and ' + P.verses.toLocaleString() + ' numbered verses' : '') + '.' : 'No chapter headings were found, so the book is divided by pages (' + P.secs.length + ' sections).') + (P.front.length ? ' ' + P.front.length + ' paragraph' + (P.front.length > 1 ? 's' : '') + ' come before the first chapter (title page, introduction, and so on).' : '') + '</p>' +
      '<div class="shgrid">' + f('title', 'Title', 'e.g. The Book of Jubilees') + f('short', 'Short name', 'e.g. Jubilees') + f('sub', 'Subtitle (optional)', '') + f('trans', 'Translator or edition', 'e.g. Translated by R. H. Charles (1902)') + f('licence', 'Copyright status', 'e.g. Public domain') + f('about', 'About this book (optional)', 'A short, factual note for readers', 1) + '</div>' +
      (P.front.length ? '<label class="wzinl"><input type="checkbox" id="shfront"' + (A.front ? ' checked' : '') + '> Keep the text before chapter 1 as an introduction</label>' : '') +
      '<div class="shprev"><div class="row" style="gap:8px;align-items:center"><b>Preview</b><select id="shprev">' + P.secs.map(function (s, i) { return '<option value="' + i + '"' + (i === (A.prev || 0) ? ' selected' : '') + '>' + esc(obLabel(s)) + ' · ' + s.v.length + '</option>'; }).join('') + '</select></div><div class="obtext small">' + s0.v.slice(0, 8).map(function (v) { return '<p class="obv">' + (v[0] != null ? '<sup>' + v[0] + '</sup>' : '') + esc(v[1].slice(0, 400)) + '</p>'; }).join('') + (s0.v.length > 8 ? '<p class="dim">…and ' + (s0.v.length - 8) + ' more</p>' : '') + '</div></div>' +
      '<label class="wzinl shright"><input type="checkbox" id="shok"' + (A.ok ? ' checked' : '') + '> This text is in the public domain, or I have permission to share it. Everyone who opens this app will be able to read it.</label>' +
      '<div class="row" style="gap:8px">' + (A.saving ? '<span class="dim">' + esc(A.saving) + '</span>' : '<button class="pri" data-act="shsave">Add to the shelf</button><button data-act="shaddx">Cancel</button>') + '</div></section>';
  }
  function shEditHtml(b) {
    var f = function (k, l, ta) { var v = k === 'about' ? (b.about || []).join('\n\n') : (b[k] || ''); return '<label class="smf"><span class="sml">' + l + '</span>' + (ta ? '<textarea data-she="' + k + '" rows="3">' + esc(v) + '</textarea>' : '<input data-she="' + k + '" value="' + esc(v) + '">') + '</label>'; };
    return '<article class="obcard shedit"><div class="obbody" style="flex:1"><h2>Edit details</h2><div class="shgrid">' + f('title', 'Title') + f('short', 'Short name') + f('sub', 'Subtitle') + f('trans', 'Translator or edition') + f('licence', 'Copyright status') + f('about', 'About this book', 1) + '</div><div class="row" style="gap:8px"><button class="pri" data-act="shesave" data-b="' + b.id + '">Save</button><button data-act="sheclose">Cancel</button></div></div></article>';
  }
  document.addEventListener('change', function (e) {
    var t = e.target; if (!t) return;
    if (t.id === 'shfile' && t.files && t.files[0]) {
      var file = t.files[0], pdf = /\.pdf$/i.test(file.name) || file.type === 'application/pdf';
      SH.add = { stage: 'reading', name: file.name, p: 0 }; render();
      (pdf ? shExtractPdf(file, function (p) { SH.add.p = p; var el = document.querySelector('.shadd .rpg i'); if (el) el.style.width = Math.round(p * 100) + '%'; }) : shExtractText(file)).then(function (pages) {
        var P = shParse(pages), nm = file.name.replace(/\.[a-z0-9]+$/i, '');
        if (!P.secs.length || !P.secs.some(function (s) { return s.v.length; })) throw new Error('No readable text was found in this file. If it is a scanned book, it needs a version with real text.');
        var tg = shTitleGuess(nm, pages);
        SH.add = { stage: 'check', name: file.name, parsed: P, m: { title: tg, short: tg.replace(/^the (book of )?/i, '').split(/[\s:,(]/).slice(0, 2).join(' '), sub: '', trans: '', licence: 'Public domain', about: '' }, front: false, ok: false, prev: 0 };
        render();
      }).catch(function (err) { SH.add = { stage: 'pick', err: (err && err.message && err.message.length < 200 ? err.message : 'That file could not be read.') }; render(); });
      return;
    }
    if (t.id === 'shprev') { SH.add.prev = +t.value; render(); return; }
    if (t.id === 'shfront') { SH.add.front = t.checked; return; }
    if (t.id === 'shok') { SH.add.ok = t.checked; return; }
  });
  document.addEventListener('input', function (e) { var t = e.target; if (t && t.dataset && t.dataset.sha && SH.add && SH.add.m) SH.add.m[t.dataset.sha] = t.value; });
  var actSH = act;
  act = function (a, d) {
    d = d || {};
    switch (a) {
      case 'shadd': SH.add = { stage: 'pick' }; SH.edit = null; render(); return;
      case 'shaddx': SH.add = null; render(); return;
      case 'shsave': {
        var A = SH.add; if (!A || !A.parsed) return; var m = A.m;
        if (!(m.title || '').trim()) { toast('Give the book a title'); return; }
        if (!A.ok) { toast('Confirm that the text can be shared'); return; }
        if (!SH.db) { toast('Saving to the shelf needs you to be signed in'); return; }
        var id = 'u' + Date.now().toString(36), secs = (A.front && A.parsed.front.length ? [{ c: 0, note: 'Introduction', v: A.parsed.front }] : []).concat(A.parsed.secs);
        var meta = { id: id, title: m.title.trim(), short: (m.short || m.title).trim().slice(0, 24), sub: (m.sub || '').trim(), trans: (m.trans || '').trim(), licence: (m.licence || '').trim(), about: (m.about || '').split(/\n\s*\n/).map(function (x) { return x.trim(); }).filter(Boolean), nch: secs.length, at: Date.now() };
        A.saving = 'Saving…'; render();
        shWrite('b~' + id, JSON.stringify({ ch: secs }), function (p) { A.saving = 'Saving… ' + Math.round(p * 100) + '%'; var el = document.querySelector('.shadd .dim'); if (el) el.textContent = A.saving; })
          .then(function () { return shIndexPut(function (ix) { ix.list.push(meta); }); })
          .then(function () { SH.content[id] = { ch: secs }; SH.add = null; toast(meta.title + ' is on the shelf'); render(); })
          .catch(function (e) { A.saving = ''; toast(e && (e.code === 'permission_denied' || e.code === 'not_granted') ? 'Only the owner of this app can add books' : 'The book could not be saved right now. Try again.'); render(); });
        return;
      }
      case 'shedit': SH.edit = d.b; SH.add = null; render(); return;
      case 'sheclose': SH.edit = null; render(); return;
      case 'shesave': {
        var vals = {}; document.querySelectorAll('[data-she]').forEach(function (el) { vals[el.dataset.she] = el.value; });
        if (!(vals.title || '').trim()) { toast('Give the book a title'); return; }
        shIndexPut(function (ix) { ix.list.forEach(function (x) { if (x.id !== d.b) return; x.title = vals.title.trim(); x.short = (vals.short || vals.title).trim().slice(0, 24); x.sub = vals.sub.trim(); x.trans = vals.trans.trim(); x.licence = vals.licence.trim(); x.about = vals.about.split(/\n\s*\n/).map(function (y) { return y.trim(); }).filter(Boolean); }); }).then(function () { SH.edit = null; toast('Saved'); render(); }).catch(function () { toast('Could not save right now'); });
        return;
      }
      case 'shrm': {
        if (SH.cf !== d.b) { SH.cf = d.b; render(); return; } SH.cf = null;
        shDel('b~' + d.b).then(function () { return shIndexPut(function (ix) { ix.list = ix.list.filter(function (x) { return x.id !== d.b; }); }); }).then(function () { delete SH.content[d.b]; if (OBK.open === d.b) OBK.open = null; toast('Removed from the shelf'); render(); }).catch(function () { toast('Could not remove it right now'); });
        return;
      }
    }
    return actSH(a, d);
  };

  /* ============ 21. Accounts: sign in with Claude, then a profile ============ */
  // Identity comes from the reader's Claude account (its email is already verified by Claude). The profile lives in
  // the person's private space and syncs with the rest of their data; the username and display name are also kept in
  // the shared `profiles` collection so usernames stay unique. Reading is open to all; saving needs a profile.
  var ACC = { state: 'checking', uid: null, email: '', user: null, db: null, err: '', form: null, nudged: 0, hide: false };
  var GUARD = ['marks', 'notes', 'fav', 'mem', 'plans', 'rp', 'rpcb', 'jr', 'wb', 'pl', 'kids', 'qh', 'sermons', 'illus', 'wstudy', 'obk', 'tpl', 'prs', 'pal', 'u15'];
  var AGES = ['18–24', '25–34', '35–49', '50–64', '65 or older', 'Prefer not to say'];
  var ROLES = ['Church member', 'Pastor', 'Minister or elder', 'Bible teacher', 'Ministry leader', 'Student', 'Seeker', 'Other'];
  var LANGS = ['English', 'Portuguese', 'Shona', 'Ndebele', 'Zulu', 'Xhosa', 'Afrikaans', 'Swahili', 'Chichewa', 'French', 'Spanish', 'Other'];
  function accP() { return P && P.acct ? P.acct : null; }
  function accOk() { return ACC.state === 'ok'; }
  function accStart() {
    var cl = window.claude; if (!cl || typeof cl.use !== 'function') { ACC.state = 'local'; return; } // a copy opened outside Claude: no accounts, saves stay on the device
    Promise.all([cl.use('db'), cl.use('user')]).then(function (r) {
      ACC.db = r[0]; ACC.user = r[1];
      if (!ACC.user || !ACC.db) { ACC.state = 'guest'; accChanged(); return; }
      return Promise.all([ACC.user.id(), Promise.resolve(ACC.user.me ? ACC.user.me() : null).catch(function () { return null; })]).then(function (x) {
        ACC.uid = x[0]; var me = x[1] || {}; ACC.email = me.email || ''; ACC.cname = me.name || '';
        if (!ACC.uid) { ACC.state = 'guest'; accChanged(); return; }
        // wait for the private sync to finish its first pull, so a profile made on another device is found
        var tries = 0; (function wait() { if ((SY.state === 'starting' || SY.frozen) && tries++ < 25) return setTimeout(wait, 400); ACC.state = accP() ? 'ok' : 'noprofile'; accChanged(); })();
      });
    }).catch(function () { ACC.state = 'guest'; accChanged(); });
  }
  setTimeout(accStart, 0);
  function accChanged() { render(); }
  // saving needs a profile
  var storeS2 = store.s;
  store.s = function (k, v) {
    if (GUARD.indexOf(k) >= 0 && (ACC.state === 'guest' || ACC.state === 'noprofile')) { accNudge(); return; }
    return storeS2.call(store, k, v);
  };
  function accNudge() { var now = Date.now(); if (now - ACC.nudged < 20000) return; ACC.nudged = now; ACC.hide = false; toast(ACC.state === 'guest' ? 'Sign in to Claude and create your account to save this' : 'Create your account to save this'); var b = document.getElementById('accbar'); if (b) b.classList.add('pulse'); else render(); }
  function accBar() {
    if (ACC.hide || ACC.state === 'ok' || ACC.state === 'checking' || ACC.state === 'local' || view === 'account') return '';
    return '<div id="accbar" class="accbar" role="status">' + ic('user', 16) + '<span>' + (ACC.state === 'guest' ? 'You are reading as a guest. To save notes, highlights, plans and progress, open this app while signed in to Claude and create your account.' : 'Create your account to save your notes, highlights, plans and progress.') + '</span>' + (ACC.state === 'noprofile' ? '<button class="pri" data-act="account">Create account</button>' : '') + '<button class="ib" data-act="accbarx" aria-label="Dismiss">' + ic('x', 14) + '</button></div>';
  }
  function accField(k, l, h, el) { return '<label class="smf"><span class="sml">' + l + '</span>' + (h ? '<small>' + h + '</small>' : '') + el + '</label>'; }
  function accSel(k, opts, v, ph) { return '<select data-acc="' + k + '"><option value="">' + (ph || 'Choose…') + '</option>' + opts.map(function (o) { return '<option' + (v === o ? ' selected' : '') + '>' + esc(o) + '</option>'; }).join('') + '</select>'; }
  function accPage() {
    var a = accP(), f = ACC.form || (ACC.form = Object.assign({ username: '', display: ACC.cname || (P && P.name) || '', age: '', country: '', lang: 'English', church: '', role: '', bio: '' }, a || {}));
    var head = '<div class="greet"><button class="ib mobm" data-act="side" aria-label="Menu">' + ic('menu') + '</button><h1>' + (a && !ACC.editing ? 'Your account' : a ? 'Edit your profile' : 'Create your account') + '</h1></div>';
    if (ACC.state === 'checking') return '<div class="home acc">' + head + '<p class="dim">Checking your sign-in…</p></div>';
    if (ACC.state === 'guest') return '<div class="home acc">' + head + '<div class="acccard"><h2>Sign in with Claude</h2><p>Accounts in this app use your Claude account, so your email is already verified and there is no new password to remember.</p><ol class="wzul"><li>Open this app in your browser while signed in to Claude (claude.ai).</li><li>If you do not have a Claude account yet, create one at claude.ai: it asks for your email and sends you a code to verify it.</li><li>Come back to this page and create your profile.</li></ol><p class="dim small">You can keep reading the Bible and Other Books without an account. Saving your own notes, highlights, plans and progress needs an account.</p></div></div>';
    if (a && !ACC.editing) {
      var row = function (l, v) { return v ? '<div><dt>' + l + '</dt><dd>' + esc(v) + '</dd></div>' : ''; };
      return '<div class="home acc">' + head + '<div class="acccard"><div class="accid"><span class="av big">' + esc((a.display || '?')[0].toUpperCase()) + '</span><div><h2>' + esc(a.display) + '</h2><p class="dim">@' + esc(a.username) + (a.role ? ' · ' + esc(a.role) : '') + '</p></div></div>' + (a.bio ? '<p>' + esc(a.bio) + '</p>' : '') + '<dl class="accdl">' + row('Email', ACC.email ? ACC.email + ' (verified by Claude)' : 'Your Claude account email') + row('Age group', a.age) + row('Country', a.country) + row('Language', a.lang) + row('Church', a.church) + row('Member since', new Date(a.created).toLocaleDateString()) + '</dl><div class="row" style="gap:8px"><button class="pri" data-act="accedit">Edit profile</button><button data-act="accdel" class="' + (ACC.cf ? 'warn' : '') + '">' + (ACC.cf ? 'Tap again to delete your profile' : 'Delete profile') + '</button></div><p class="dim small">Your notes, plans and progress are saved privately to your account and sync to any device where you open this app. Only your username and display name are visible to the app\'s owner and other readers.</p></div></div>';
    }
    return '<div class="home acc">' + head + '<form class="acccard" id="accform" onsubmit="return false">' + (ACC.email ? '<p class="accmail">' + ic('check', 14) + ' Signed in as <b>' + esc(ACC.email) + '</b>, verified by Claude.</p>' : '<p class="accmail">' + ic('check', 14) + ' Signed in with your Claude account.</p>') +
      '<div class="shgrid">' + accField('username', 'Username', '3–20 letters, numbers, dots or underscores', '<input data-acc="username" value="' + esc(f.username) + '" autocomplete="username" maxlength="20" required><span class="accu" id="accu">' + (ACC.uMsg || '') + '</span>') + accField('display', 'Display name', 'How your name appears', '<input data-acc="display" value="' + esc(f.display) + '" maxlength="40" required>') +
      accField('age', 'Age group', '', accSel('age', AGES, f.age)) + accField('country', 'Country', '', '<input data-acc="country" value="' + esc(f.country) + '" maxlength="60" placeholder="e.g. Zimbabwe">') + accField('lang', 'Language', '', accSel('lang', LANGS, f.lang)) + accField('role', 'Role (optional)', '', accSel('role', ROLES, f.role, 'None')) + accField('church', 'Church (optional)', '', '<input data-acc="church" value="' + esc(f.church) + '" maxlength="80">') + accField('bio', 'Short bio (optional)', '', '<textarea data-acc="bio" rows="3" maxlength="300">' + esc(f.bio) + '</textarea>') + '</div>' +
      (ACC.err ? '<p class="smbad">' + esc(ACC.err) + '</p>' : '') + '<div class="row" style="gap:8px"><button class="pri" data-act="accsave"' + (ACC.saving ? ' disabled' : '') + '>' + (ACC.saving ? 'Saving…' : a ? 'Save profile' : 'Create account') + '</button>' + (a ? '<button data-act="acccancel">Cancel</button>' : '') + '</div><p class="dim small">Age group, country, language, church, role and bio are kept private in your account.</p></form></div>';
  }
  var URX = /^[a-z0-9._]{3,20}$/;
  function accCheckName(u) { // -> Promise<true if free or mine>
    if (!ACC.db) return Promise.resolve(true);
    return Promise.resolve(ACC.db.collection('profiles').where('u', '==', u).limit(1).get()).then(function (s) { var d = s && s.docs && s.docs[0]; return !d || d.id === ACC.uid; }).catch(function () { return true; });
  }
  document.addEventListener('input', function (e) { var t = e.target; if (!t || !t.dataset || !t.dataset.acc || !ACC.form) return; ACC.form[t.dataset.acc] = t.value; if (t.dataset.acc === 'username') { var u = t.value.trim().toLowerCase(), el = document.getElementById('accu'); clearTimeout(ACC.ut); if (!u) { if (el) el.textContent = ''; return; } if (!URX.test(u)) { ACC.uMsg = 'Use 3–20 letters, numbers, dots or underscores'; if (el) { el.textContent = ACC.uMsg; el.className = 'accu bad'; } return; } ACC.ut = setTimeout(function () { accCheckName(u).then(function (free) { ACC.uMsg = free ? '@' + u + ' is available' : '@' + u + ' is taken'; var el2 = document.getElementById('accu'); if (el2) { el2.textContent = ACC.uMsg; el2.className = 'accu ' + (free ? 'ok' : 'bad'); } }); }, 400); } });
  document.addEventListener('change', function (e) { var t = e.target; if (t && t.dataset && t.dataset.acc && ACC.form) ACC.form[t.dataset.acc] = t.value; });
  var actAcc = act;
  act = function (a, d) {
    d = d || {};
    switch (a) {
      case 'analyze': view = 'analyze'; if (innerWidth <= 800) side = false; sv(); render(); var mm = $('#main'); if (mm) mm.scrollTop = 0; return; // Analyze had been redirected to the Study Lab's Compare tool
      case 'prof': if (ACC.state === 'local') break;
      case 'account': view = 'account'; ACC.err = ''; ACC.cf = false; if (innerWidth <= 800) side = false; render(); return;
      case 'accbarx': ACC.hide = true; var b = document.getElementById('accbar'); if (b) b.remove(); return;
      case 'accedit': ACC.editing = true; ACC.form = Object.assign({}, accP()); render(); return;
      case 'acccancel': ACC.editing = false; ACC.form = null; ACC.err = ''; render(); return;
      case 'accsave': {
        var f = ACC.form || {}, u = (f.username || '').trim().toLowerCase(), dn = (f.display || '').trim();
        if (!URX.test(u)) { ACC.err = 'Choose a username of 3–20 letters, numbers, dots or underscores.'; render(); return; }
        if (!dn) { ACC.err = 'Enter a display name.'; render(); return; }
        if (!f.age) { ACC.err = 'Choose your age group.'; render(); return; }
        ACC.saving = true; ACC.err = ''; render();
        accCheckName(u).then(function (free) {
          if (!free) throw { msg: '@' + u + ' is already taken. Try another username.' };
          var prev = accP(), acct = { username: u, display: dn.slice(0, 40), age: f.age, country: (f.country || '').trim().slice(0, 60), lang: f.lang || '', church: (f.church || '').trim().slice(0, 80), role: f.role || '', bio: (f.bio || '').trim().slice(0, 300), created: prev ? prev.created : Date.now() };
          var pub = ACC.db ? Promise.resolve(ACC.db.collection('profiles').doc(ACC.uid).set({ u: u, d: acct.display, at: Date.now() })).catch(function (e) { if (e && (e.code === 'permission_denied' || e.code === 'not_granted')) return; throw e; }) : Promise.resolve();
          return pub.then(function () {
            P = P || { xp: 0, lv: 1, streak: 1, last: day() }; P.name = acct.display; P.acct = acct;
            ACC.state = 'ok'; ACC.editing = false; ACC.form = null; ACC.saving = false; sv(); store.s('profile', P);
            toast(prev ? 'Profile saved' : 'Welcome, ' + acct.display + '! Your account is ready.'); render();
          });
        }).catch(function (e) { ACC.saving = false; ACC.err = (e && e.msg) || 'Your profile could not be saved right now. Please try again.'; render(); });
        return;
      }
      case 'accdel': {
        if (!ACC.cf) { ACC.cf = true; render(); return; } ACC.cf = false;
        var done = function () { if (P) { delete P.acct; sv(); store.s('profile', P); } ACC.state = 'noprofile'; ACC.form = null; toast('Your profile was deleted'); render(); };
        if (ACC.db) Promise.resolve(ACC.db.collection('profiles').doc(ACC.uid).delete()).then(done, done); else done();
        return;
      }
    }
    return actAcc(a, d);
  };
  var side6 = sideHtml;
  sideHtml = function () {
    var a = accP(), lbl = accOk() && a ? a.display : ACC.state === 'noprofile' ? 'Create account' : ACC.state === 'guest' ? 'Guest · sign in to save' : (P ? P.name : '…');
    return side6().replace(/<button class="prof"[\s\S]*?<\/button>/, '<button class="prof' + (view === 'account' ? ' on' : '') + '" data-act="account" title="' + esc(lbl) + '"><span class="av">' + esc(accOk() && a ? a.display[0].toUpperCase() : '?') + '</span><span class="lb">' + esc(lbl) + (accOk() && a ? '<small>@' + esc(a.username) + '</small>' : '') + '</span></button>');
  };
  var renderA = render;
  render = function () {
    renderA();
    if (view === 'account') { $('#main').innerHTML = accPage(); var dr = $('#drawer'); if (dr) dr.classList.remove('open'); var tb = $('#tb'); if (tb) tb.style.display = 'none'; }
    var m = $('#main'), old = document.getElementById('accbar'); if (old) old.remove(); var bar = accBar(); if (m && bar) m.insertAdjacentHTML('afterbegin', bar);
  };
  // a profile pulled from another device turns the account on
  setInterval(function () { if (ACC.state === 'noprofile' && accP()) { ACC.state = 'ok'; render(); } }, 3000);
  window.__acc = ACC;

  /* ============ 22. Across Passages: Scripture connection intelligence ============ */
  // Builds on the section-12 engine (anCompute). Every line in the network is a doorway: clicking it opens the
  // evidence (original word, form, verses, why they connect, what differs) with links into the Word Study lab.
  var XL = 'ABCDEFGH';
  var XT = {
    same: { n: 'Exact original word', c: '#B8862A', dash: '', d: 'The same Hebrew or Greek word (lemma) appears in both passages.' },
    fam: { n: 'Same root or word family', c: '#D9822B', dash: '9 4', d: 'Different words traced to one source word in Strong\'s derivation notes.' },
    bridge: { n: 'Hebrew ↔ Greek bridge', c: '#A9502F', dash: '14 3 3 3', d: 'A Greek word that Strong\'s traces to a Hebrew word.' },
    concept: { n: 'Semantic connection', c: '#2A958D', dash: '', d: 'Different original words that the KJV translates the same way.' },
    xref: { n: 'Cross-reference', c: '#3769BD', dash: '', d: 'The cross-reference list links a verse in one passage to the other.' },
    theme: { n: 'Shared theme', c: '#7556BF', dash: '6 4', d: 'Both passages use words from the same biblical theme (for example salvation or covenant).' },
    imagery: { n: 'Shared imagery', c: '#4A8F4E', dash: '1 5', d: 'Both passages use the same picture or symbol (light, water, shepherd…), judged from the KJV wording.' },
    contrast: { n: 'Contrast', c: '#B5452F', dash: '10 3 2 3', d: 'One passage speaks of one side of a pair (light, life, righteous) and the other of its opposite.' },
    eng: { n: 'Shared English word only', c: '#8D96A8', dash: '4 4', d: 'The same English word in the KJV; the original words may be different.' }
  };
  var XORDER = ['same', 'bridge', 'xref', 'fam', 'concept', 'theme', 'imagery', 'contrast', 'eng'];
  var XMODES = { all: ['All connections', ['same', 'bridge', 'xref', 'fam', 'concept', 'theme', 'imagery', 'contrast', 'eng']], lang: ['Original language', ['same', 'fam', 'bridge', 'concept']], scr: ['Scripture connections', ['xref', 'same']], them: ['Thematic', ['theme', 'imagery', 'contrast', 'concept']], theo: ['Theological', ['theme', 'xref', 'bridge', 'same']], deep: ['Deep analysis', ['same', 'bridge', 'xref', 'fam', 'concept', 'theme', 'imagery', 'contrast', 'eng']], custom: ['Custom', null] };
  var XIMG = { light: ['light', 'lamp', 'candl', 'shine', 'shin'], water: ['water', 'river', 'well', 'fountain', 'spring', 'rain', 'sea'], bread: ['bread', 'manna', 'loaf', 'loav'], shepherd: ['shepherd', 'sheep', 'flock', 'fold', 'pastur'], lamb: ['lamb'], rock: ['rock', 'stone', 'cornerston'], vine: ['vine', 'branch', 'vineyard', 'grape'], fire: ['fire', 'flame', 'burn'], door: ['door', 'gate'], path: ['path', 'way', 'road', 'feet', 'foot', 'step'], seed: ['seed', 'sow', 'harvest', 'reap'], blood: ['blood'], serpent: ['serpent'], tree: ['tree', 'root'], mountain: ['mountain', 'hill', 'mount'], sword: ['sword'], crown: ['crown'], cloud: ['cloud'], oil: ['oil', 'anoint'], garment: ['garment', 'robe', 'raiment', 'cloth'], wings: ['wing'], bride: ['bride', 'bridegroom'], throne: ['throne'], salt: ['salt'], temple: ['templ', 'tabernacl', 'sanctuari'] };
  var XCON = [['light', ['light', 'lamp', 'shine'], 'darkness', ['dark', 'darkness']], ['life', ['life', 'live', 'aliv'], 'death', ['death', 'die', 'dead']], ['the righteous', ['righteou', 'just', 'upright'], 'the wicked', ['wick', 'wicked', 'ungodli', 'ungodly', 'sinner']], ['blessing', ['bless', 'blessed'], 'curse', ['curs', 'cursed', 'curse']], ['wisdom', ['wise', 'wisdom'], 'folly', ['fool', 'foolish', 'folli']], ['love', ['love', 'lov'], 'hatred', ['hate', 'hat', 'hatr']], ['the humble', ['humbl', 'lowli', 'meek'], 'the proud', ['proud', 'pride']], ['the rich', ['rich', 'riche'], 'the poor', ['poor']], ['peace', ['peace'], 'war', ['war']], ['the clean', ['clean', 'pure'], 'the unclean', ['unclean', 'defil']]];
  var XS = Object.assign({ mode: 'all', custom: null, tab: 'ov', hide: {}, pos: {}, view: null, sel: null, focus: null, ver: 'KJV', cmp: null, full: false, saved: [], recent: [], ai: [], paste: false, aiQ: '' }, store.g('xpv', {}));
  var xsv = function () { store.s('xpv', { mode: XS.mode, custom: XS.custom, tab: XS.tab, hide: XS.hide, ver: XS.ver, recent: XS.recent }); };
  XS.saved = store.g('anconn', []); SYNC_KEYS.push('anconn'); GUARD.push('anconn');
  // whole chapters ("Psalm 23") as well as verses and ranges
  var parseRngX = parseRng;
  parseRng = function (s) { var r = parseRngX(s); if (r) return r; var m = (s || '').trim().match(/^(.+?)\s*(\d+)$/); if (!m) return null; var p = parse(m[1] + ' ' + m[2] + ':1'); if (!p || !KJV[p.b] || !KJV[p.b][p.c]) return null; var n = KJV[p.b][p.c].length; return { b: p.b, c: p.c, v1: 1, v2: n, label: p.b + ' ' + p.c }; };
  function xTypes() { return XS.mode === 'custom' ? (XS.custom || XMODES.all[1]) : XMODES[XS.mode][1]; }
  function xStems(p) { var st = {}; p.vs.forEach(function (x) { plain(x[1]).split(/[^A-Za-z]+/).forEach(function (w) { var s = stemE(w); if (s) st[s] = w.toLowerCase(); }); }); return st; }
  function xImageWords(p, stems) { var out = []; p.vs.forEach(function (x) { x[1].replace(/([^\s{}]+)((?:\{[HG]\d+\})*)/g, function (m, w, tg) { var s = stemE(w); if (stems.some(function (z) { return s === z || s.indexOf(z) === 0; })) out.push({ w: w.replace(/[^\w'’-]/g, ''), ks: (tg.match(/[HG]\d+/g) || []), v: x[0] }); return m; }); }); return out; }
  function xAnalyze() {
    var R = anCompute(), ps = R.ps, n = ps.length, L = R.L.filter(function (l) { return l.t !== 'common'; }).map(function (l) { return Object.assign({}, l); });
    if (n < 2) return { ps: ps, L: [], pairs: {}, ed: {}, n: n };
    ps.forEach(function (p, i) { p.i = i; p.st = xStems(p); p.ot = BOOKS.indexOf(p.b) < 39; p.grp = wzGroup(p.b); });
    for (var i = 0; i < n; i++) for (var j = i + 1; j < n; j++) {
      var A = ps[i], B = ps[j];
      // themes: words from one theme group in both passages
      WZANCH.forEach(function (g) { var ka = g[1].filter(function (k) { return A.nums[k]; }), kb = g[1].filter(function (k) { return B.nums[k]; }); if (ka.length && kb.length) L.push({ t: 'theme', ks: ka.concat(kb.filter(function (k) { return ka.indexOf(k) < 0; })), ka: ka, kb: kb, ps: [i, j], w: 2, label: g[0].toLowerCase() }); });
      // imagery
      Object.keys(XIMG).forEach(function (img) { var st = XIMG[img], fa = xImageWords(A, st), fb = xImageWords(B, st); if (fa.length && fb.length) L.push({ t: 'imagery', ks: [], ia: fa, ib: fb, ps: [i, j], w: 1.5, label: img }); });
      // contrasts
      XCON.forEach(function (c) { var has = function (p, set) { return Object.keys(p.st).some(function (s) { return set.some(function (z) { return s === z; }); }); }; var a1 = has(A, c[1]), a2 = has(A, c[3]), b1 = has(B, c[1]), b2 = has(B, c[3]); if (a1 && !a2 && b2 && !b1) L.push({ t: 'contrast', ks: [], ps: [i, j], w: 2, label: c[0] + ' / ' + c[2], sa: c[0], sb: c[2] }); else if (a2 && !a1 && b1 && !b2) L.push({ t: 'contrast', ks: [], ps: [i, j], w: 2, label: c[2] + ' / ' + c[0], sa: c[2], sb: c[0] }); });
    }
    L.forEach(function (l, x) { l.id = x; });
    var ed = {}, pairs = {}; L.forEach(function (l) { for (var a = 0; a < l.ps.length; a++) for (var b = a + 1; b < l.ps.length; b++) { var x = Math.min(l.ps[a], l.ps[b]), y = Math.max(l.ps[a], l.ps[b]), k = x + '-' + y; (pairs[k] = pairs[k] || []).push(l); } });
    var T = xTypes(); Object.keys(pairs).forEach(function (k) { ed[k] = pairs[k].filter(function (l) { return T.indexOf(l.t) >= 0; }).reduce(function (a, l) { return a + l.w; }, 0); });
    return { ps: ps, L: L, pairs: pairs, ed: ed, n: n };
  }
  // where a word sits in a passage: verse, English rendering, Hebrew form
  function xCtx(p, k) {
    for (var q = 0; q < p.vs.length; q++) { var x = p.vs[q]; if (x[1].indexOf('{' + k + '}') >= 0) { var row = wzRow(p.b, p.c, x[0], x[1], k, BOOKS.indexOf(p.b)), hb = k[0] === 'H' ? wzHebAt(p.b, p.c, x[0], k) : []; return { v: x[0], ref: p.b + ' ' + p.c + ':' + x[0], t: x[1], ph: row.ph, hb: hb }; } }
    return null;
  }
  function xWord(k) { var e = LEX[k] || [], H = k[0] === 'H'; return '<a class="xpw" data-act="wsopen" data-k="' + k + '"><b class="' + (H ? 'hebw' : 'grk') + '" lang="' + (H ? 'he' : 'grc') + '">' + esc(wzScript(k)) + '</b> <i>' + esc(e[1] || '') + '</i> <small>' + k + '</small></a>'; }
  function xFreqNote(k) { var f = CI && CI[k] ? CI[k].n : 0; return f <= 20 ? 'a rare word (' + f + ' occurrences), so sharing it is a strong signal worth studying' : f <= 150 ? 'a moderately common word (' + f + ' occurrences); the link is meaningful when the contexts agree' : 'a common word (' + f.toLocaleString() + ' occurrences), so the shared word alone is a weak signal; the contexts matter more'; }
  function xQuote(A, B) { var sa = Object.keys(A.st), sb = B.st, sh = sa.filter(function (s) { return sb[s] && !STOPE[s] && s.length > 2; }); return sh; }
  function xLinkTitle(l, R) { var P = l.ps.map(function (i) { return XL[i]; }).join(' ↔ '); return XT[l.t].n + ' · ' + P + ' · ' + (l.ks.length ? l.ks.map(function (k) { return wzTr(k); }).join(' / ') : l.label); }

  /* ---- dossier for one connection ---- */
  function xDossier(R, l, pi, pj) {
    var A = R.ps[pi], B = R.ps[pj], T = XT[l.t], kA = null, kB = null, ctxA = null, ctxB = null;
    var head = '<div class="xdh" style="--c:' + T.c + '"><small>' + T.n + '</small><h3>' + XL[pi] + ' ' + esc(A.label) + ' <span>↔</span> ' + XL[pj] + ' ' + esc(B.label) + '</h3></div>';
    var sec = function (t, b) { return b ? '<section><h4>' + t + '</h4>' + b + '</section>' : ''; };
    var why = '', diff = [], sig = '', words = '', fur = '';
    if (l.ks.length) { kA = l.ks.filter(function (k) { return A.nums[k]; })[0] || l.ks[0]; kB = l.ks.filter(function (k) { return B.nums[k] && k !== kA; })[0] || (B.nums[kA] ? kA : l.ks[l.ks.length - 1]); ctxA = xCtx(A, kA); ctxB = xCtx(B, kB); }
    var ctxHtml = function (c, k, p, L) { if (!c) return ''; return '<div class="xctx"><div class="xctxh"><b>' + L + '</b> <a data-act="wzgo" data-r="' + esc(c.ref) + '">' + esc(c.ref) + '</a></div><p class="wzv">' + wzVerseHtml(c.t, k) + '</p><dl class="wzdl"><dt>Word</dt><dd>' + xWord(k) + '</dd><dt>English here</dt><dd>“' + esc(c.ph.join('”, “')) + '”</dd>' + (c.hb.length ? '<dt>Hebrew form</dt><dd><span class="hebw" lang="he">' + esc(c.hb[0].h) + '</span> <span class="wzmo">' + esc(morph(c.hb[0].mo)) + '</span></dd>' : k[0] === 'G' ? '<dt>Greek form</dt><dd class="dim">Not in the app\'s data</dd>' : '') + '<dt>Meaning (Strong\'s)</dt><dd>' + esc((LEX[k] || [])[3] || '') + '</dd></dl></div>'; };
    if (l.t === 'same') {
      why = 'Both passages use the same ' + wzLang(kA) + ' word, ' + xWord(kA) + '. It is ' + xFreqNote(kA) + '.';
      if (ctxA && ctxB) { if (ctxA.ph.join() !== ctxB.ph.join()) diff.push('The KJV renders it differently: “' + esc(ctxA.ph.join(', ')) + '” in ' + XL[pi] + ' and “' + esc(ctxB.ph.join(', ')) + '” in ' + XL[pj] + '. The translators read the contexts differently.'); if (ctxA.hb[0] && ctxB.hb[0] && morph(ctxA.hb[0].mo) !== morph(ctxB.hb[0].mo)) diff.push('The form differs: ' + esc(morph(ctxA.hb[0].mo)) + ' in ' + XL[pi] + ', ' + esc(morph(ctxB.hb[0].mo)) + ' in ' + XL[pj] + '.'); }
    } else if (l.t === 'fam') {
      why = xWord(kA) + ' and ' + xWord(kB) + ' are traced in Strong\'s derivation notes to the source word ' + xWord(l.root) + '. They are related by origin, not identical in meaning: check each word\'s own usage.';
    } else if (l.t === 'bridge') {
      var g = l.ks[0], h = l.ks[1]; kA = A.nums[g] ? g : h; kB = kA === g ? h : g; ctxA = xCtx(A, kA); ctxB = xCtx(B, kB);
      why = 'Strong\'s traces the Greek ' + xWord(g) + ' to the Hebrew ' + xWord(l.via) + (l.via !== h ? ', which belongs to the same family as ' + xWord(h) : '') + '. This is a dictionary link between an Old Testament word and a New Testament word; it does not by itself show a quotation.';
    } else if (l.t === 'concept') {
      why = 'Different original words, ' + xWord(kA) + ' and ' + xWord(kB) + ', that the KJV translates “' + esc(l.label) + '”. Shared English shows overlapping meaning, not the same word. Compare the definitions below.';
      diff.push('Different words: ' + esc(wzGloss(kA)) + ' (' + kA + ') and ' + esc(wzGloss(kB)) + ' (' + kB + ').');
    } else if (l.t === 'xref') {
      var sh = xQuote(A, B), ot = A.ot !== B.ot;
      why = 'The cross-reference list links these passages. ' + (sh.length >= 6 ? 'They share ' + sh.length + ' words in English (' + sh.slice(0, 8).map(function (s) { return A.st[s]; }).join(', ') + ')' + (ot ? ' across the Old and New Testaments, which suggests a quotation or close allusion. Compare the wording to decide.' : ', which suggests a parallel or a close allusion.') : 'The list does not say whether it is a quotation, an allusion or a parallel; read both to decide.');
    } else if (l.t === 'theme') {
      why = 'Both passages use words for <b>' + esc(l.label) + '</b>: ' + XL[pi] + ' ' + l.ka.map(xWord).join(', ') + '; ' + XL[pj] + ' ' + l.kb.map(xWord).join(', ') + '. Sharing a theme invites comparison; it does not mean the passages say the same thing.';
      kA = l.ka[0]; kB = l.kb[0]; ctxA = xCtx(A, kA); ctxB = xCtx(B, kB);
    } else if (l.t === 'imagery') {
      why = 'Both passages use the image of <b>' + esc(l.label) + '</b>: ' + XL[pi] + ' “' + esc(l.ia.map(function (x) { return x.w; }).join('”, “')) + '”; ' + XL[pj] + ' “' + esc(l.ib.map(function (x) { return x.w; }).join('”, “')) + '”. Judged from the KJV wording.';
      var ka2 = (l.ia[0].ks || [])[0], kb2 = (l.ib[0].ks || [])[0]; if (ka2 && kb2) { kA = ka2; kB = kb2; ctxA = xCtx(A, kA); ctxB = xCtx(B, kB); if (kA !== kB) diff.push('The original words behind the image differ: ' + xWord(kA) + ' and ' + xWord(kB) + '.'); else diff.push('The same original word carries the image in both: ' + xWord(kA) + '.'); }
    } else if (l.t === 'contrast') {
      why = XL[pi] + ' speaks of <b>' + esc(l.sa) + '</b>, ' + XL[pj] + ' of <b>' + esc(l.sb) + '</b>. The difference may be as instructive as any similarity.';
    } else if (l.t === 'eng') {
      var findK = function (p) { var hit = null; p.vs.forEach(function (x) { if (hit) return; x[1].replace(/([^\s{}]+)((?:\{[HG]\d+\})+)/g, function (m, w, tg) { if (!hit && stemE(w) === l.st) hit = tg.match(/[HG]\d+/g)[0]; return m; }); }); return hit; };
      kA = findK(A); kB = findK(B); if (kA) ctxA = xCtx(A, kA); if (kB) ctxB = xCtx(B, kB);
      why = 'The KJV uses “' + esc(l.label) + '” in both. ' + (kA && kB ? (kA === kB ? 'Here it translates the same word, ' + xWord(kA) + '.' : 'But the original words are different: ' + xWord(kA) + ' in ' + XL[pi] + ' and ' + xWord(kB) + ' in ' + XL[pj] + '. Treat this as an English echo, not an original-language link.') : 'At least one of these is not tagged to an original word.');
    }
    if (A.ot !== B.ot) diff.push(XL[pi] + ' is in the ' + (A.ot ? 'Old' : 'New') + ' Testament and ' + XL[pj] + ' in the ' + (B.ot ? 'Old' : 'New') + '.');
    if (A.grp && B.grp && A.grp !== B.grp) diff.push('Different kinds of writing: ' + esc(A.grp) + ' and ' + esc(B.grp) + '.');
    var k0 = kA || kB;
    sig = (k0 ? 'In ' + XL[pi] + ' the word is ' + (kA && CI && CI[kA] ? xFreqNote(kA) : 'tagged') + '. ' : '') + 'Read both contexts before concluding that a writer intended the link: shared vocabulary shows a connection to examine, not a proven dependence.';
    if (k0) { var others = wzOcc(k0).filter(function (x) { return x.r !== (ctxA && ctxA.ref) && x.r !== (ctxB && ctxB.ref); }).slice(0, 6); fur = (others.length ? '<p>Other passages with ' + xWord(k0) + ':</p><div class="wzrefs">' + others.map(function (x) { return '<span class="chip"><a data-act="wzgo" data-r="' + esc(x.r) + '">' + esc(x.r) + '</a> <button class="lnk" data-act="xpadd" data-r="' + esc(x.r) + '" title="Add as a passage">+</button></span>'; }).join('') + '</div>' : '') + (wzRels(k0).slice(0, 4).length ? '<p>Related words: ' + wzRels(k0).slice(0, 4).map(function (x) { return xWord(x.k); }).join(', ') + '</p>' : ''); }
    var acts = '<div class="xdacts">' + (k0 ? '<button data-act="wsopen" data-k="' + k0 + '" data-r="' + esc(ctxA ? ctxA.ref : '') + '">' + ic('spark', 14) + ' Open Word Study</button>' : '') + (kA && kB ? '<button data-act="xpcmp" data-ka="' + kA + '" data-kb="' + kB + '" data-i="' + pi + '" data-j="' + pj + '">' + ic('cols', 14) + ' Compare contexts</button>' : '') + '<button data-act="xpverses" data-i="' + pi + '" data-j="' + pj + '">' + ic('book', 14) + ' View full verses</button><button data-act="xpchap" data-i="' + pi + '" data-j="' + pj + '">Surrounding chapter</button><button data-act="xpsave" data-l="' + l.id + '">' + ic('bookmark', 14) + ' Save connection</button><button data-act="xpwb" data-l="' + l.id + '">Add to Bible study</button><button data-act="xpserm" data-l="' + l.id + '">Add to sermon</button><button data-act="xpaiexp" data-l="' + l.id + '">' + ic('bulb', 14) + ' Explain with AI</button></div>';
    var ctx = ctxA || ctxB ? '<div class="xctx2">' + ctxHtml(ctxA, kA, A, 'Context in ' + XL[pi]) + ctxHtml(ctxB, kB, B, 'Context in ' + XL[pj]) + '</div>' : '<div class="xctx2">' + [A, B].map(function (p) { return '<div class="xctx"><div class="xctxh"><b>' + XL[p.i] + '</b> <a data-act="wzgo" data-r="' + esc(p.label) + '">' + esc(p.label) + '</a></div><p class="wzv">' + esc(p.vs.map(function (x) { return plain(x[1]); }).join(' ').slice(0, 500)) + '</p></div>'; }).join('') + '</div>';
    return head + sec('Why they connect', '<p>' + why + '</p>') + ctx + sec('What is different', diff.length ? '<ul class="wzul">' + diff.map(function (d) { return '<li>' + d + '</li>'; }).join('') + '</ul>' : '<p class="dim">No clear difference in the data; compare the wider contexts.</p>') + sec('Significance', '<p>' + sig + '</p>') + sec('Further investigation', fur) + acts;
  }
  function xPairDossier(R, k) {
    var ab = k.split('-').map(Number), T = xTypes(), ls = (R.pairs[k] || []).filter(function (l) { return T.indexOf(l.t) >= 0 && !XS.hide[l.t]; }).sort(function (a, b) { return XORDER.indexOf(a.t) - XORDER.indexOf(b.t) || b.w - a.w; });
    if (!ls.length) return '<p class="dim">No connections of the selected kinds between ' + XL[ab[0]] + ' and ' + XL[ab[1]] + '.</p>';
    var cur = XS.sel && XS.sel.l != null ? R.L[XS.sel.l] : ls[0];
    return '<div class="xdlist"><small>' + ls.length + ' connection' + (ls.length > 1 ? 's' : '') + ' between ' + XL[ab[0]] + ' and ' + XL[ab[1]] + '</small>' + ls.map(function (l) { return '<button class="' + (l === cur ? 'on' : '') + '" data-act="xpsel" data-p="' + k + '" data-l="' + l.id + '" style="--c:' + XT[l.t].c + '"><i></i>' + esc(XT[l.t].n) + ': ' + esc(l.ks.length ? l.ks.slice(0, 2).map(function (q) { return wzTr(q); }).join(' / ') : l.label) + '</button>'; }).join('') + '</div>' + xDossier(R, cur, ab[0], ab[1]);
  }

  /* ---- network ---- */
  function xPos(R, W, H) {
    var n = R.ps.length, P = [];
    for (var i = 0; i < n; i++) { var a = i / n * Math.PI * 2 - Math.PI / 2 + (n === 2 ? Math.PI / 2 : 0) + (n === 4 ? 0 : 0); P.push(XS.pos[i] || [W / 2 + Math.cos(a) * W * 0.34, H / 2 + Math.sin(a) * H * 0.36]); }
    return P;
  }
  function xSvg(R) {
    var W = 900, H = 560, P = xPos(R, W, H), T = xTypes(), vb = XS.view || [0, 0, W, H], foc = XS.focus;
    var mx = Math.max.apply(null, [1].concat(Object.keys(R.ed).map(function (k) { return R.ed[k]; })));
    var lines = '', labels = '';
    Object.keys(R.pairs).forEach(function (k) {
      var ab = k.split('-').map(Number), a = P[ab[0]], b = P[ab[1]], byT = {};
      R.pairs[k].forEach(function (l) { if (T.indexOf(l.t) < 0 || XS.hide[l.t]) return; (byT[l.t] = byT[l.t] || []).push(l); });
      var ts = XORDER.filter(function (t) { return byT[t]; }), m = ts.length; if (!m) return;
      var dx = b[0] - a[0], dy = b[1] - a[1], len = Math.sqrt(dx * dx + dy * dy) || 1, nx = -dy / len, ny = dx / len, on = foc == null || ab.indexOf(foc) >= 0, sel = XS.sel && XS.sel.p === k;
      ts.forEach(function (t, q) {
        var off = (q - (m - 1) / 2) * 9, x1 = a[0] + nx * off, y1 = a[1] + ny * off, x2 = b[0] + nx * off, y2 = b[1] + ny * off, ls = byT[t], wsum = ls.reduce(function (s, l) { return s + l.w; }, 0), sw = (1.6 + Math.min(1, wsum / mx) * 5).toFixed(1);
        var tip = XT[t].n + ' (' + ls.length + '): ' + ls.slice(0, 3).map(function (l) { return l.ks.length ? l.ks.map(function (z) { return wzTr(z); }).join('/') : l.label; }).join(', ') + ' — click to open';
        lines += '<g class="xpe' + (on ? '' : ' dim') + (sel && XS.sel.t === t ? ' sel' : '') + '" data-act="xpedge" data-p="' + k + '" data-t="' + t + '" tabindex="0" role="button" aria-label="' + esc(XL[ab[0]] + ' to ' + XL[ab[1]] + ': ' + tip) + '"><title>' + esc(tip) + '</title><line x1="' + x1.toFixed(1) + '" y1="' + y1.toFixed(1) + '" x2="' + x2.toFixed(1) + '" y2="' + y2.toFixed(1) + '" class="hit"/><line x1="' + x1.toFixed(1) + '" y1="' + y1.toFixed(1) + '" x2="' + x2.toFixed(1) + '" y2="' + y2.toFixed(1) + '" stroke="' + XT[t].c + '" stroke-width="' + sw + '" stroke-dasharray="' + XT[t].dash + '" stroke-linecap="round" class="ln"/></g>';
      });
      if (on) { var t0 = ts[0], l0 = byT[t0].slice().sort(function (x, y) { return y.w - x.w; })[0], lab2 = l0.ks.length ? wzTr(l0.ks[0]) : l0.label, mxp = [(a[0] + b[0]) / 2 + nx * (m * 4.5 + 10), (a[1] + b[1]) / 2 + ny * (m * 4.5 + 10)]; labels += '<text x="' + mxp[0].toFixed(1) + '" y="' + mxp[1].toFixed(1) + '" text-anchor="middle" class="xpl" data-act="xpedge" data-p="' + k + '" data-t="' + t0 + '">' + esc(lab2.length > 22 ? lab2.slice(0, 21) + '…' : lab2) + (ts.length > 1 ? ' +' + (ts.length - 1) : '') + '</text>'; }
    });
    var nodes = R.ps.map(function (p, i) { var deg = Object.keys(R.ed).filter(function (k) { return k.split('-').map(Number).indexOf(i) >= 0 && R.ed[k] > 0; }).length, key = Object.keys(p.nums).filter(function (k) { return !isCommon(k) && LEX[k]; }).sort(function (x, y) { return idf(y) - idf(x); })[0], w = 176, h = 62, x = P[i][0] - w / 2, y = P[i][1] - h / 2, on = foc == null || foc === i;
      return '<g class="xpn' + (on ? '' : ' dim') + (foc === i ? ' foc' : '') + '" data-i="' + i + '" transform="translate(' + x.toFixed(1) + ',' + y.toFixed(1) + ')" tabindex="0" role="button" aria-label="Passage ' + XL[i] + ' ' + esc(p.label) + ', ' + deg + ' connected passages"><rect width="' + w + '" height="' + h + '" rx="14" class="xpnr"/><circle cx="22" cy="22" r="12" class="xpnb"/><text x="22" y="26.5" text-anchor="middle" class="xpnk">' + XL[i] + '</text><text x="42" y="27" class="xpnt">' + esc(p.label.length > 17 ? p.label.slice(0, 16) + '…' : p.label) + '</text>' + (key ? '<text x="42" y="47" class="xpns"><tspan class="' + (key[0] === 'H' ? 'hebw' : 'grk') + '">' + esc(wzScript(key)) + '</tspan> ' + esc(wzTr(key)) + '</text>' : '') + '</g>'; }).join('');
    return '<svg id="xpsvg" class="xpsvg" viewBox="' + vb.join(' ') + '" role="group" aria-label="Connection network: click a line to open its evidence, drag passages to move them"><rect class="xpbg" x="-5000" y="-5000" width="10000" height="10000"/>' + lines + labels + nodes + '</svg>';
  }
  function xLegend(R) { var T = xTypes(), cnt = {}; R.L.forEach(function (l) { cnt[l.t] = (cnt[l.t] || 0) + 1; }); return '<div class="xpleg">' + XORDER.filter(function (t) { return T.indexOf(t) >= 0; }).map(function (t) { return '<button class="' + (XS.hide[t] ? 'off' : '') + '" data-act="xphide" data-t="' + t + '" aria-pressed="' + !XS.hide[t] + '" title="' + esc(XT[t].d) + '"><svg width="30" height="8" aria-hidden="true"><line x1="1" y1="4" x2="29" y2="4" stroke="' + XT[t].c + '" stroke-width="3" stroke-dasharray="' + XT[t].dash + '" stroke-linecap="round"/></svg>' + XT[t].n + ' <b>' + (cnt[t] || 0) + '</b></button>'; }).join('') + '</div>'; }

  /* ---- views ---- */
  function xInputs() {
    var refs = AN.refs.length ? AN.refs.slice() : ['', ''];
    while (refs.length < 2) refs.push('');
    var rows = refs.map(function (r, i) { var p = r && parseRng(r), prev = p ? plain(KJV[p.b][p.c][p.v1 - 1] || '').replace(/\{\(?[HG]\d+\)?\}/g, '').slice(0, 110) : ''; return '<div class="xpin' + (r && !p ? ' bad' : '') + '"><span class="xpk">' + XL[i] + '</span><div class="xpinw"><input id="xp' + i + '" value="' + esc(r) + '" placeholder="e.g. John 3:14 or Psalm 23" list="xpbooks" aria-label="Passage ' + XL[i] + '" autocomplete="off"><small>' + (r ? (p ? esc(p.label) + ' · ' + esc(prev) + (prev.length >= 110 ? '…' : '') : 'Not found: try Book Chapter:Verse') : '') + '</small></div><div class="xpinb"><button class="ib" data-act="xpmv" data-i="' + i + '" data-d="-1" aria-label="Move up"' + (i ? '' : ' disabled') + '>↑</button><button class="ib" data-act="xpmv" data-i="' + i + '" data-d="1" aria-label="Move down"' + (i < refs.length - 1 ? '' : ' disabled') + '>↓</button><button class="ib" data-act="xprm" data-i="' + i + '" aria-label="Remove passage ' + XL[i] + '"' + (refs.length > 2 ? '' : ' disabled') + '>' + ic('x', 14) + '</button></div></div>'; }).join('');
    var T = xTypes();
    return '<section class="xpinput"><header><h2>Across Passages</h2><p>Discover the linguistic, scriptural, thematic and theological connections between passages.</p></header><datalist id="xpbooks">' + BOOKS.map(function (b) { return '<option value="' + b + ' ">'; }).join('') + '</datalist><div class="xpins">' + rows + '</div>' +
      '<div class="xprow">' + (refs.length < 8 ? '<button data-act="xpaddrow">' + ic('plus', 14) + ' Add passage</button>' : '') + '<button data-act="xppaste">Paste references</button>' + ANEX.map(function (x, i) { return '<button class="chip" data-act="anex" data-i="' + i + '">' + x[0] + '</button>'; }).join('') + (XS.recent.length ? '<select id="xprecent" aria-label="Recent studies"><option value="">Recent…</option>' + XS.recent.map(function (r, i) { return '<option value="' + i + '">' + esc(r.join('; ')) + '</option>'; }).join('') + '</select>' : '') + '</div>' +
      (XS.paste ? '<div class="xppaste"><textarea id="xppastet" rows="3" placeholder="Paste any text that contains references, e.g. a sermon outline. Up to 8 references are taken."></textarea><button data-act="xppastego">Use these references</button></div>' : '') +
      '<div class="xpctl"><label>Investigate <select id="xpmode">' + Object.keys(XMODES).map(function (m) { return '<option value="' + m + '"' + (XS.mode === m ? ' selected' : '') + '>' + XMODES[m][0] + '</option>'; }).join('') + '</select></label>' + (XS.mode === 'custom' ? '<div class="xpcus">' + XORDER.map(function (t) { return '<label><input type="checkbox" data-xpc="' + t + '"' + (T.indexOf(t) >= 0 ? ' checked' : '') + '> ' + XT[t].n + '</label>'; }).join('') + '</div>' : '') + '<label>Show text in <select id="xpver">' + VL.filter(function (v) { return v !== 'HEB'; }).map(function (v) { return '<option' + (XS.ver === v ? ' selected' : '') + '>' + esc(v) + '</option>'; }).join('') + '</select></label><span class="sp"></span><button class="pri" data-act="anrun">' + ic('target', 15) + ' Analyze passages</button></div><p class="dim small">The original-language analysis always uses the Strong\'s-tagged KJV and the Hebrew text, whatever translation you display.</p></section>';
  }
  function xOverview(R) {
    var T = xTypes(), L = R.L.filter(function (l) { return T.indexOf(l.t) >= 0; }), cnt = {}; L.forEach(function (l) { cnt[l.t] = (cnt[l.t] || 0) + 1; });
    var strong = L.filter(function (l) { return ['same', 'bridge', 'xref', 'fam', 'concept'].indexOf(l.t) >= 0; }).sort(function (a, b) { return b.w - a.w; })[0];
    var key = L.filter(function (l) { return l.t === 'same'; }).sort(function (a, b) { return b.ps.length - a.ps.length || b.w - a.w; })[0];
    var card = function (l, t) { if (!l) return ''; var ab = [l.ps[0], l.ps[1]]; return '<button class="xpcard" data-act="xpsel" data-p="' + Math.min(ab[0], ab[1]) + '-' + Math.max(ab[0], ab[1]) + '" data-l="' + l.id + '" style="--c:' + XT[l.t].c + '"><small>' + t + '</small><b>' + l.ps.map(function (i) { return XL[i] + ' ' + esc(R.ps[i].label); }).join(' ↔ ') + '</b><span>' + XT[l.t].n + (l.ks.length ? ': ' + l.ks.slice(0, 2).map(function (k) { return wzScript(k) + ' ' + wzTr(k) + ' (' + k + ')'; }).join(' / ') : ': ' + esc(l.label)) + '</span><em>' + (l.ks[0] ? esc(xFreqNote(l.ks[0])) : esc(XT[l.t].d)) + '</em><span class="xpgo">Open the evidence →</span></button>'; };
    var dif = R.ps.map(function (p, i) { var own = Object.keys(p.nums).filter(function (k) { return !isCommon(k) && LEX[k] && !R.ps.some(function (q, j) { return j !== i && q.nums[k]; }); }).sort(function (a, b) { return idf(b) - idf(a); }).slice(0, 3); return '<li><b>' + XL[i] + '</b> ' + esc(p.label) + ' <span class="dim">· ' + (p.ot ? 'Old' : 'New') + ' Testament · ' + esc(p.grp) + '</span>' + (own.length ? '<br><small>Words only here: ' + own.map(function (k) { return xWord(k); }).join(', ') + '</small>' : '') + '</li>'; }).join('');
    var cons = L.filter(function (l) { return l.t === 'contrast'; });
    var sugg = []; try { related(R.ps[0].b, R.ps[0].c, R.ps[0].v1, 8).forEach(function (o) { var r = o.r[0] + ' ' + o.r[1] + ':' + o.r[2]; if (!R.ps.some(function (p) { return p.b === o.r[0] && p.c === o.r[1] && o.r[2] >= p.v1 && o.r[2] <= p.v2; }) && sugg.length < 5) sugg.push([r, o.sh.slice(0, 2).map(lab).join(', ')]); }); } catch (e) {}
    var saved = XS.saved.filter(function (s) { return s; });
    return '<div class="xpov"><div class="xpstat"><div><b>' + R.n + '</b><small>passages analysed</small></div><div><b>' + L.length + '</b><small>connections found</small></div>' + XORDER.filter(function (t) { return cnt[t]; }).map(function (t) { return '<div style="--c:' + XT[t].c + '"><b>' + cnt[t] + '</b><small>' + XT[t].n.toLowerCase() + '</small></div>'; }).join('') + '</div>' +
      '<div class="xpgrid2">' + (card(strong, 'Strongest evidence-supported connection') || '<div class="xpcard"><small>Strongest connection</small><b>No original-language or cross-reference link found.</b></div>') + (key && key !== strong ? card(key, 'Key discovery: the word that runs through the most passages') : cons[0] ? card(cons[0], 'Key discovery: a contrast') : '') + '</div>' +
      '<div class="xpgrid2"><section class="xpbox"><h4>Differences</h4><ul class="xpdl">' + dif + '</ul>' + (cons.length ? '<p>Contrasts: ' + cons.map(function (l) { return XL[l.ps[0]] + ' ' + esc(l.sa) + ' / ' + XL[l.ps[1]] + ' ' + esc(l.sb); }).join('; ') + '</p>' : '') + '</section>' +
      '<section class="xpbox"><h4>Further investigation</h4>' + (sugg.length ? '<p class="dim small">Verses sharing rare original words with ' + esc(R.ps[0].label) + ':</p><ul class="xpdl">' + sugg.map(function (s) { return '<li><a data-act="wzgo" data-r="' + esc(s[0]) + '">' + esc(s[0]) + '</a> <small class="dim">' + esc(s[1]) + '</small> <button class="lnk" data-act="xpadd" data-r="' + esc(s[0]) + '">Add as a passage</button></li>'; }).join('') + '</ul>' : '<p class="dim">No suggestions.</p>') + '</section></div>' +
      (saved.length ? '<section class="xpbox"><h4>Saved connections</h4><ul class="xpdl">' + saved.map(function (s, i) { return '<li><b>' + esc(s.title) + '</b> <small class="dim">' + esc(s.refs.join(' ↔ ')) + '</small> <button class="lnk" data-act="xpload" data-i="' + i + '">Open</button><button class="lnk" data-act="xpunsave" data-i="' + i + '">Remove</button></li>'; }).join('') + '</ul></section>' : '') + '</div>';
  }
  function xConnList(R) {
    var T = xTypes(), L = R.L.filter(function (l) { return T.indexOf(l.t) >= 0 && !XS.hide[l.t]; });
    return XORDER.filter(function (t) { return T.indexOf(t) >= 0; }).map(function (t) { var ls = L.filter(function (l) { return l.t === t; }); if (!ls.length) return ''; return '<section class="alg2" style="--c:' + XT[t].c + '"><h5><i></i>' + XT[t].n + ' <b>' + ls.length + '</b></h5><p class="dim small" style="margin:0 0 8px">' + XT[t].d + '</p>' + ls.slice(0, 80).map(function (l) { var pr = Math.min(l.ps[0], l.ps[1]) + '-' + Math.max(l.ps[0], l.ps[1]); return '<button class="xpli" data-act="xpsel" data-p="' + pr + '" data-l="' + l.id + '"><span class="lps">' + l.ps.map(function (i) { return '<span class="lp">' + XL[i] + '</span>'; }).join('') + '</span><span class="xplw">' + (l.ks.length ? l.ks.slice(0, 3).map(function (k) { return '<b class="' + (k[0] === 'H' ? 'hebw' : 'grk') + '">' + esc(wzScript(k)) + '</b> ' + esc(wzTr(k)) + ' <small>' + k + '</small>'; }).join(' · ') : esc(l.label)) + '</span><span class="xpgo">Evidence →</span></button>'; }).join('') + '</section>'; }).join('') || '<p class="dim">No connections of the selected kinds.</p>';
  }
  function xMatrix(R) {
    var n = R.n, T = xTypes(), mx = Math.max.apply(null, [1].concat(Object.keys(R.ed).map(function (k) { return R.ed[k]; })));
    var h = '<div class="wztbl"><table class="xpmx"><tr><th></th>' + R.ps.map(function (p, i) { return '<th>' + XL[i] + '<small>' + esc(p.label) + '</small></th>'; }).join('') + '</tr>';
    for (var i = 0; i < n; i++) { h += '<tr><th>' + XL[i] + '<small>' + esc(R.ps[i].label) + '</small></th>'; for (var j = 0; j < n; j++) { if (i === j) { h += '<td class="self"></td>'; continue; } var k = Math.min(i, j) + '-' + Math.max(i, j), ls = (R.pairs[k] || []).filter(function (l) { return T.indexOf(l.t) >= 0; }), by = {}; ls.forEach(function (l) { by[l.t] = (by[l.t] || 0) + 1; }); h += '<td data-act="xpedge" data-p="' + k + '" style="--a:' + ((R.ed[k] || 0) / mx).toFixed(2) + '" tabindex="0" role="button"><b>' + ls.length + '</b><small>strength ' + Math.round(R.ed[k] || 0) + '</small><span class="xpmb">' + XORDER.filter(function (t) { return by[t]; }).map(function (t) { return '<i style="background:' + XT[t].c + ';flex:' + by[t] + '" title="' + XT[t].n + ': ' + by[t] + '"></i>'; }).join('') + '</span></td>'; } h += '</tr>'; }
    return h + '</table></div><p class="dim small">Each square counts the connections between two passages; the strength score weights rare shared words and cross-references above common or English-only links. The bar shows the kinds of connection. Click a square to open its evidence.</p>';
  }
  function xLangs(R) {
    var ks = {}; R.L.forEach(function (l) { if (['same', 'fam', 'bridge', 'concept', 'theme'].indexOf(l.t) >= 0) l.ks.forEach(function (k) { ks[k] = 1; }); });
    var list = Object.keys(ks).filter(function (k) { return LEX[k]; }).sort(function (a, b) { return R.ps.filter(function (p) { return p.nums[b]; }).length - R.ps.filter(function (p) { return p.nums[a]; }).length || idf(b) - idf(a); });
    if (!list.length) return '<p class="dim">No shared original-language words.</p>';
    return '<p class="dim small">Every original word involved in a connection. Hebrew forms come from the Hebrew text\'s morphology; the app has no Greek parsing data, so Greek forms are not shown. Click a word to open its Word Study.</p><div class="wztbl"><table class="xplang"><thead><tr><th>Word</th><th>Meaning</th><th>Part of speech</th><th>Uses</th>' + R.ps.map(function (p, i) { return '<th>' + XL[i] + '</th>'; }).join('') + '</tr></thead><tbody>' + list.map(function (k) { var e = LEX[k]; return '<tr><td>' + xWord(k) + '</td><td>' + esc(wzGloss(k)) + '</td><td>' + esc(wzPos(k)) + '</td><td>' + (CI && CI[k] ? CI[k].n : 0) + '</td>' + R.ps.map(function (p) { var c = p.nums[k] && xCtx(p, k); return '<td>' + (c ? '<small>v' + c.v + ' “' + esc(c.ph.join(', ')) + '”</small>' + (c.hb[0] ? '<br><span class="hebw" lang="he">' + esc(c.hb[0].h) + '</span> <span class="wzmo">' + esc(morph(c.hb[0].mo)) + '</span>' : '') : '') + '</td>'; }).join('') + '</tr>'; }).join('') + '</tbody></table></div>';
  }
  function xCompare(R) {
    var C = XS.cmp, ver = XS.ver, cols = '<div class="xpcols" style="--n:' + R.n + '">' + R.ps.map(function (p, i) { return '<div class="xpcol"><h4><span class="xpk">' + XL[i] + '</span> ' + esc(p.label) + ' <small>' + esc(ver) + '</small></h4>' + p.vs.map(function (x) { var t = ver === 'KJV' ? x[1] : gv(ver, p.b, p.c, x[0]); return '<p class="wzv"><sup>' + x[0] + '</sup> ' + (ver === 'KJV' ? xHl(x[1], R, i) : esc(t ? plain(t) : (BIB[ver] ? '' : 'Loading…'))) + '</p>'; }).join('') + '</div>'; }).join('') + '</div>';
    var tbl = '';
    if (C && R.ps[C.i] && R.ps[C.j]) {
      var A = R.ps[C.i], B = R.ps[C.j], ca = xCtx(A, C.ka), cb = xCtx(B, C.kb), row = function (l, a, b) { return '<tr><th>' + l + '</th><td>' + a + '</td><td>' + b + '</td></tr>'; }, ea = LEX[C.ka] || [], eb = LEX[C.kb] || [];
      var rec = WZ.words[C.ka] || { cm: {} }, recb = WZ.words[C.kb] || { cm: {} }, cmA = ca ? (rec.cm[ca.ref] || {}).mean || '' : '', cmB = cb ? (recb.cm[cb.ref] || {}).mean || '' : '';
      var same = C.ka === C.kb, sameR = ca && cb && ca.ph.join() === cb.ph.join();
      tbl = '<section class="xpbox"><h4>Word comparison</h4><div class="wztbl"><table class="xpcmp"><thead><tr><th></th><th>' + XL[C.i] + ' ' + esc(A.label) + '</th><th>' + XL[C.j] + ' ' + esc(B.label) + '</th></tr></thead><tbody>' +
        row('Reference', ca ? esc(ca.ref) : '—', cb ? esc(cb.ref) : '—') + row('Original word', ca && ca.hb[0] ? '<span class="hebw" lang="he">' + esc(ca.hb[0].h) + '</span>' : xWord(C.ka), cb && cb.hb[0] ? '<span class="hebw" lang="he">' + esc(cb.hb[0].h) + '</span>' : xWord(C.kb)) + row('Transliteration (lemma)', esc(ea[1] || ''), esc(eb[1] || '')) + row('Lemma', xWord(C.ka), xWord(C.kb)) + row('Strong\'s', C.ka, C.kb) + row('Root (Strong\'s)', wzRoot(C.ka) !== C.ka ? xWord(wzRoot(C.ka)) : 'Primary word', wzRoot(C.kb) !== C.kb ? xWord(wzRoot(C.kb)) : 'Primary word') +
        row('Morphology', ca && ca.hb[0] ? esc(morph(ca.hb[0].mo)) : (C.ka[0] === 'G' ? '<span class="dim">Not in the app\'s data</span>' : '—'), cb && cb.hb[0] ? esc(morph(cb.hb[0].mo)) : (C.kb[0] === 'G' ? '<span class="dim">Not in the app\'s data</span>' : '—')) + row('Lexical definition', esc(ea[3] || ''), esc(eb[3] || '')) + row('Translation (KJV here)', ca ? '“' + esc(ca.ph.join(', ')) + '”' : '', cb ? '“' + esc(cb.ph.join(', ')) + '”' : '') +
        row('Contextual meaning <small>(yours, shared with Word Study)</small>', ca ? '<textarea data-wzk="' + C.ka + '" data-wzcm2="' + esc(ca.ref) + '" rows="2">' + esc(cmA) + '</textarea>' : '', cb ? '<textarea data-wzk="' + C.kb + '" data-wzcm2="' + esc(cb.ref) + '" rows="2">' + esc(cmB) + '</textarea>' : '') + '</tbody></table></div>' +
        '<h4>Same word, different context?</h4><ul class="wzul"><li>' + (same ? 'Both passages use the same word, ' + xWord(C.ka) + '.' : 'These are different words: ' + xWord(C.ka) + ' and ' + xWord(C.kb) + '.') + '</li>' + (ca && cb ? '<li>' + (sameR ? 'The KJV renders it the same way in both (“' + esc(ca.ph.join(', ')) + '”).' : 'The KJV renders it differently (“' + esc(ca.ph.join(', ')) + '” and “' + esc(cb.ph.join(', ')) + '”), a sign the translators saw a different nuance in each context.') + '</li>' : '') + (ca && cb && ca.hb[0] && cb.hb[0] ? '<li>' + (morph(ca.hb[0].mo) === morph(cb.hb[0].mo) ? 'Same grammatical form in both.' : 'Different forms: ' + esc(morph(ca.hb[0].mo)) + ' and ' + esc(morph(cb.hb[0].mo)) + '.') + '</li>' : '') + '<li>' + (A.ot === B.ot ? 'Both in the ' + (A.ot ? 'Old' : 'New') + ' Testament.' : 'One Old Testament, one New Testament passage.') + '</li></ul>' +
        '<h4>What does the comparison reveal?</h4><p class="dim small">Read both verses above in context and record what you see. Or ask the AI to compare them using this evidence.</p><button data-act="xpaicmp">' + ic('bulb', 14) + ' Compare with AI</button></section>';
    }
    return tbl + cols;
  }
  function xHl(t, R, i) { t = (t || '').replace(/\{\([HG]\d+\)\}/g, ''); var col = {}; R.L.forEach(function (l) { if (['same', 'fam', 'bridge', 'concept', 'theme'].indexOf(l.t) >= 0 && l.ps.indexOf(i) >= 0) l.ks.forEach(function (k) { if (!col[k]) col[k] = XT[l.t].c; }); }); return esc(t).replace(/([^\s{}]+)((?:\{[HG]\d+\})+)/g, function (m, w, tg) { var ks = tg.match(/[HG]\d+/g), k = ks.filter(function (x) { return col[x]; })[0]; return k ? '<span class="xphl" data-act="wsopen" data-k="' + k + '" style="--c:' + col[k] + '" title="' + k + ' ' + esc(wzTr(k)) + '">' + w + '</span>' : w; }).replace(/\{[HG]\d+\}/g, ''); }
  function xAnalytics(R) {
    var T = xTypes(), L = R.L.filter(function (l) { return T.indexOf(l.t) >= 0; }), cnt = {}; L.forEach(function (l) { cnt[l.t] = (cnt[l.t] || 0) + 1; });
    var deg = R.ps.map(function (p, i) { return [XL[i] + ' ' + esc(p.label), L.filter(function (l) { return l.ps.indexOf(i) >= 0; }).length]; });
    var prs = Object.keys(R.ed).map(function (k) { var ab = k.split('-').map(Number); return [XL[ab[0]] + ' ↔ ' + XL[ab[1]], Math.round(R.ed[k]), { a: 'xpedge', p: k }]; }).sort(function (a, b) { return b[1] - a[1]; });
    var H = 0, G = 0; R.ps.forEach(function (p) { Object.keys(p.nums).forEach(function (k) { if (k[0] === 'H') H++; else G++; }); });
    return '<div class="wzgrid2"><div><h3>Connections by kind</h3>' + wzBars(XORDER.filter(function (t) { return cnt[t]; }).map(function (t) { return ['<i class="wzsw" style="background:' + XT[t].c + '"></i>' + XT[t].n, cnt[t]]; })) + '</div><div><h3>How connected each passage is</h3>' + wzBars(deg) + '</div><div><h3>Strongest pairs</h3><small class="dim">Strength weights rare shared words and cross-references</small>' + wzBars(prs) + '</div><div><h3>Vocabulary</h3>' + wzBars([['Hebrew words (tagged)', H], ['Greek words (tagged)', G]]) + '<p class="dim small">' + R.ps.filter(function (p) { return p.ot; }).length + ' Old Testament and ' + R.ps.filter(function (p) { return !p.ot; }).length + ' New Testament passages.</p></div></div>';
  }
  function xAI(R) {
    return '<p class="dim small">Ask about these passages. Answers draw on the passage texts, the connections found and the original-language data; references are checked against the Bible.</p><div class="wzchat" id="xpchat">' + XS.ai.map(function (m, i) { return '<div class="wzq">' + esc(m.q) + '</div><div class="wza">' + wzAnsHtml(m.a) + (m.err ? '<p class="dim small">' + esc(m.err) + '</p>' : '') + '</div>'; }).join('') + (XAI.busy ? '<div class="wzq">' + esc(XAI.q) + '</div><div class="wza" id="xplive">' + (XAI.live ? wzAnsHtml(XAI.live) : '<p class="dim">Studying the passages…</p>') + '</div>' : '') + '</div>' +
      (!XS.ai.length && !XAI.busy ? '<div class="wzchips">' + ['How do these passages relate to one another?', 'Is any of these a quotation of another?', 'What does the strongest shared word mean in each passage?', 'How do these passages differ?', 'What theme ties these passages together, and where do they part ways?'].map(function (q) { return '<button class="chip" data-act="xpaiq" data-q="' + esc(q) + '">' + esc(q) + '</button>'; }).join('') + '</div>' : '') +
      '<div class="wzform"><textarea id="xpaiq" rows="2" placeholder="Ask about these passages…" aria-label="Your question"></textarea>' + (XAI.busy ? '<button data-act="xpaistop">Stop</button>' : '<button class="pri" data-act="xpaiq">Ask</button>') + (XS.ai.length && !XAI.busy ? '<button class="lnk" data-act="xpaiclr">Clear</button>' : '') + '</div>';
  }
  var XTABS = [['ov', 'Overview'], ['con', 'Connections'], ['net', 'Network'], ['mx', 'Matrix'], ['lang', 'Original languages'], ['cmp', 'Comparison'], ['an', 'Analytics'], ['ai', 'AI study']];
  analyzeHtml = function () {
    var R = xAnalyze(), inp = xInputs();
    var head = '<div class="top" style="border:0;background:none;padding:12px 16px 0"><button class="ib" data-act="side">' + ic('menu') + '</button><h2 class="lt">' + ic('target', 20) + ' Analyze</h2></div>';
    if (R.n < 2) return head + '<div class="xpwrap">' + inp + '<p class="dim">Add at least two valid passages, then choose Analyze passages.</p></div>';
    var tab = XS.tab, body = tab === 'ov' ? xOverview(R) : tab === 'con' ? xConnList(R) : tab === 'net' ? '' : tab === 'mx' ? xMatrix(R) : tab === 'lang' ? xLangs(R) : tab === 'cmp' ? xCompare(R) : tab === 'an' ? xAnalytics(R) : xAI(R);
    var net = '<div class="xpnet' + (XS.full ? ' full' : '') + '"><div class="xpnettools"><b>Connection network</b><span class="dim small">Click a line to open its evidence · drag passages · scroll to zoom</span><span class="sp"></span><button class="ib" data-act="xpzoom" data-d="-1" aria-label="Zoom in">+</button><button class="ib" data-act="xpzoom" data-d="1" aria-label="Zoom out">−</button><button data-act="xpreset">Reset layout</button><button data-act="xpfull">' + (XS.full ? 'Exit full screen' : 'Full screen') + '</button></div><div class="xpnetbody"><div class="xpcanvas">' + xSvg(R) + '</div>' + (XS.sel ? '<aside class="xpdoss" aria-label="Connection evidence"><button class="ib xpx" data-act="xpclose" aria-label="Close">' + ic('x', 15) + '</button>' + xPairDossier(R, XS.sel.p) + '</aside>' : '<aside class="xpdoss empty"><p><b>Every line is evidence.</b></p><p class="dim">Click a line to see the original word, the verses, why the passages connect, what differs, and where to study next. Click a passage to highlight its connections.</p></aside>') + '</div>' + xLegend(R) + '</div>';
    var showNet = tab === 'ov' || tab === 'net' || tab === 'con';
    return head + '<div class="xpwrap">' + inp + (showNet ? net : '') + '<nav class="wztabs xptabs" role="tablist">' + XTABS.map(function (t) { return '<button role="tab" aria-selected="' + (t[0] === tab) + '" class="' + (t[0] === tab ? 'on' : '') + '" data-act="xptab" data-v="' + t[0] + '">' + t[1] + '</button>'; }).join('') + '</nav><section class="xpbody">' + (tab === 'net' ? '<p class="dim small">The network is above. Use the legend to hide kinds of connection.</p>' : body) + '</section>' + (tab === 'cmp' || tab === 'ov' ? '' : '') + '</div>';
  };

  /* ---- AI ---- */
  var XAI = { busy: false, live: '', ctl: null, q: '' };
  function xAICtx(R) {
    var T = xTypes();
    return 'PASSAGES:\n' + R.ps.map(function (p, i) { return XL[i] + ' ' + p.label + ' (KJV): ' + p.vs.map(function (x) { return x[0] + ' ' + plain(x[1]); }).join(' '); }).join('\n') + '\n\nCONNECTIONS FOUND (computed from the Strong\'s-tagged KJV, the Strong\'s dictionary, the Hebrew text and the cross-reference list):\n' +
      R.L.filter(function (l) { return T.indexOf(l.t) >= 0; }).slice(0, 60).map(function (l) { return '- ' + XT[l.t].n + ' between ' + l.ps.map(function (i) { return XL[i]; }).join('+') + ': ' + (l.ks.length ? l.ks.map(function (k) { return k + ' ' + wzScript(k) + ' ' + wzTr(k) + ' "' + wzGloss(k) + '"'; }).join(' / ') : l.label); }).join('\n');
  }
  var XRULES = 'You are a careful Bible-study assistant comparing passages. Rules: ground every claim in the passages and data given, or in what the tools return; cite verses as Book Chapter:Verse and only verses you have seen. Distinguish what the text explicitly says, a strong textual conclusion, interpretation and application. Shared vocabulary shows a connection to examine, not proof of intentional dependence. Do not derive meaning from roots; let context decide. The app has Hebrew morphology but no Greek morphology and no Septuagint data: say so if relevant. Point out differences as well as similarities. Be concise, with short paragraphs or bullets.';
  async function xAsk(q) {
    if (XAI.busy) return; var R = xAnalyze(); if (R.n < 2) return;
    var sample = await hasAI(); if (!sample) { XS.ai.push({ q: q, a: '', err: 'AI is not available in this view.' }); XS.tab = 'ai'; render(); return; }
    XAI = { busy: true, live: '', ctl: new AbortController(), q: q }; XS.tab = 'ai'; render();
    var msgs = [], prev = XS.ai.slice(-3); prev.forEach(function (m) { if (m.a) { msgs.push({ role: 'user', content: m.q }); msgs.push({ role: 'assistant', content: m.a }); } });
    var first = XRULES + '\n\n' + xAICtx(R) + '\n\nQuestion: ';
    if (msgs.length) msgs[0].content = first + msgs[0].content; msgs.push({ role: 'user', content: (msgs.length ? '' : first) + q });
    var tools = [{ name: 'read_passage', description: 'Read a Bible passage in the KJV (up to 40 verses), e.g. "Isaiah 53:1-12".', inputSchema: { type: 'object', properties: { ref: { type: 'string' } }, required: ['ref'] }, execute: function (a) { var n = normRef(a && a.ref); if (!n) throw new Error('Reference not found'); var out = []; (runits(n) || []).forEach(function (u) { for (var v = u.v1; v <= u.v2 && out.length < 40; v++) { var t = KJV[u.b] && KJV[u.b][u.c] && KJV[u.b][u.c][v - 1]; if (t) out.push(u.b + ' ' + u.c + ':' + v + ' ' + plain(t)); } }); return { ref: n, verses: out }; } },
      { name: 'word_entry', description: 'Dictionary entry and usage for a Strong\'s number (e.g. H216).', inputSchema: { type: 'object', properties: { strong: { type: 'string' } }, required: ['strong'] }, execute: function (a) { var k = wzKey(a && a.strong); if (!k) throw new Error('No such Strong\'s number'); var e = LEX[k] || []; return { strong: k, word: e[0], translit: e[1], definition: e[3], derivation: e[5], renderings: wzRend(k).slice(0, 8), occurrences: CI && CI[k] ? CI[k].n : 0 }; } },
      { name: 'hebrew_form', description: 'The Hebrew word form and morphology for a Strong\'s number in a given verse.', inputSchema: { type: 'object', properties: { ref: { type: 'string' }, strong: { type: 'string' } }, required: ['ref', 'strong'] }, execute: function (a) { var p = parse(a.ref || ''), k = wzKey(a.strong); if (!p || !k) throw new Error('Bad input'); return { forms: wzHebAt(p.b, p.c, p.v, k).map(function (h) { return { hebrew: h.h, morphology: morph(h.mo) }; }) }; } }];
    var ans = '', err = '';
    try { var r = await sample(msgs, { signal: XAI.ctl.signal, cache: false, tools: tools, onText: function (o) { XAI.live = o.text; var el = document.getElementById('xplive'); if (el) el.innerHTML = wzAnsHtml(o.text); } }); ans = r.text; }
    catch (e) { var c = e && e.code; ans = (e && e.text) || ''; err = c === 'not_granted' ? 'AI access was declined for this app.' : c === 'rate_limited' ? 'Too many requests just now. Please wait a moment.' : c === 'aborted' || c === 'canceled' || (e && e.name === 'AbortError') ? 'Stopped.' : 'That didn\'t work. Please try again in a moment.'; }
    XS.ai.push({ q: q, a: ans, err: err }); if (XS.ai.length > 20) XS.ai = XS.ai.slice(-20); XAI = { busy: false, live: '' }; render();
  }

  /* ---- interactions ---- */
  function xReadInputs() { var out = []; for (var i = 0; i < 8; i++) { var el = document.getElementById('xp' + i); if (el) out.push(el.value.trim()); } return out; }
  var XDRAG = null;
  function xSvgPoint(svg, e) { var pt = svg.createSVGPoint(); pt.x = e.clientX; pt.y = e.clientY; return pt.matrixTransform(svg.getScreenCTM().inverse()); }
  function xRedraw() { var c = document.querySelector('.xpcanvas'); if (!c) return; var R = XS._R || xAnalyze(); XS._R = R; c.innerHTML = xSvg(R); }
  document.addEventListener('pointerdown', function (e) {
    var svg = e.target.closest && e.target.closest('#xpsvg'); if (!svg) return;
    var node = e.target.closest('.xpn');
    if (node) { var i = +node.dataset.i, P = xPos(XS._R || xAnalyze(), 900, 560), pt = xSvgPoint(svg, e); XDRAG = { k: 'node', i: i, ox: pt.x - P[i][0], oy: pt.y - P[i][1], moved: false, x0: e.clientX, y0: e.clientY }; XS._R = XS._R || xAnalyze(); }
    else if (!e.target.closest('.xpe') && !e.target.closest('.xpl')) { XDRAG = { k: 'pan', x0: e.clientX, y0: e.clientY, vb: (XS.view || [0, 0, 900, 560]).slice(), sc: (XS.view || [0, 0, 900, 560])[2] / svg.getBoundingClientRect().width, moved: false }; }
    if (XDRAG) { try { svg.setPointerCapture(e.pointerId); } catch (x) {} }
  });
  document.addEventListener('pointermove', function (e) {
    if (!XDRAG) return; var svg = document.getElementById('xpsvg'); if (!svg) return;
    if (Math.abs(e.clientX - XDRAG.x0) + Math.abs(e.clientY - XDRAG.y0) > 4) XDRAG.moved = true; if (!XDRAG.moved) return;
    if (XDRAG.k === 'node') { var pt = xSvgPoint(svg, e); XS.pos[XDRAG.i] = [pt.x - XDRAG.ox, pt.y - XDRAG.oy]; xRedraw(); }
    else { XS.view = [XDRAG.vb[0] - (e.clientX - XDRAG.x0) * XDRAG.sc, XDRAG.vb[1] - (e.clientY - XDRAG.y0) * XDRAG.sc, XDRAG.vb[2], XDRAG.vb[3]]; svg.setAttribute('viewBox', XS.view.join(' ')); }
  });
  document.addEventListener('pointerup', function (e) { if (!XDRAG) return; var d = XDRAG; XDRAG = null; if (!d.moved && d.k === 'node') { XS.focus = XS.focus === d.i ? null : d.i; xRedraw(); } });
  document.addEventListener('wheel', function (e) { var svg = e.target.closest && e.target.closest('#xpsvg'); if (!svg) return; e.preventDefault(); var vb = (XS.view || [0, 0, 900, 560]).slice(), f = e.deltaY > 0 ? 1.12 : 0.89, pt = xSvgPoint(svg, e); var w = Math.min(3000, Math.max(250, vb[2] * f)), h = w * 560 / 900; XS.view = [pt.x - (pt.x - vb[0]) * w / vb[2], pt.y - (pt.y - vb[1]) * h / vb[3], w, h]; svg.setAttribute('viewBox', XS.view.join(' ')); }, { passive: false });
  document.addEventListener('keydown', function (e) { if (e.key !== 'Enter' && e.key !== ' ') return; var g = e.target.closest && e.target.closest('.xpe,.xpn,.xpmx td[data-act]'); if (!g) return; e.preventDefault(); if (g.classList.contains('xpn')) { var i = +g.dataset.i; XS.focus = XS.focus === i ? null : i; xRedraw(); } else act(g.dataset.act, g.dataset); });
  document.addEventListener('change', function (e) {
    var t = e.target; if (!t) return;
    if (t.id === 'xpmode') { XS.mode = t.value; if (t.value === 'custom' && !XS.custom) XS.custom = XMODES.all[1].slice(); XS.sel = null; xsv(); render(); return; }
    if (t.dataset && t.dataset.xpc) { var c = XS.custom || [], i = c.indexOf(t.dataset.xpc); if (t.checked && i < 0) c.push(t.dataset.xpc); if (!t.checked && i >= 0) c.splice(i, 1); XS.custom = c; xsv(); render(); return; }
    if (t.id === 'xpver') { XS.ver = t.value; xsv(); if (t.value !== 'KJV' && !BIB[t.value]) loadVer(t.value).then(render); render(); return; }
    if (t.id === 'xprecent' && t.value !== '') { AN.refs = XS.recent[+t.value].slice(); XS.sel = null; XS.pos = {}; XS.view = null; render(); return; }
  });
  document.addEventListener('input', function (e) { var t = e.target; if (t && t.dataset && t.dataset.wzcm2 != null) { var r = wzW(t.dataset.wzk); (r.cm[t.dataset.wzcm2] = r.cm[t.dataset.wzcm2] || {}).mean = t.value; wzsv(); } });
  document.addEventListener('keydown', function (e) { if (e.key === 'Enter' && e.target && /^xp\d$/.test(e.target.id)) { e.preventDefault(); act('anrun', {}); } });
  function xLink(id) { var R = XS._R || xAnalyze(); return R.L[+id]; }
  function xLinkText(l, R) { var ab = l.ps.map(function (i) { return R.ps[i].label; }); return XT[l.t].n + ': ' + ab.join(' ↔ ') + (l.ks.length ? ' — ' + l.ks.map(function (k) { return k + ' ' + wzScript(k) + ' (' + wzTr(k) + ', ' + wzGloss(k) + ')'; }).join(' / ') : ' — ' + l.label); }
  var actX = act;
  act = function (a, d) {
    d = d || {};
    switch (a) {
      case 'anrun': { var refs = xReadInputs().filter(function (x) { return x; }); if (document.getElementById('xp0')) { if (refs.length < 2) { toast('Enter at least two passages'); return; } var bad = refs.filter(function (r) { return !parseRng(r); }); if (bad.length) { toast('Not found: ' + bad[0]); render(); return; } AN.refs = refs; } else return actX(a, d); XS.sel = null; XS.focus = null; XS.pos = {}; XS.view = null; XS._R = null; AN.ai = ''; XS.recent = [AN.refs.slice()].concat(XS.recent.filter(function (r) { return r.join('|') !== AN.refs.join('|'); })).slice(0, 8); xsv(); render(); return; }
      case 'anex': XS.sel = null; XS.focus = null; XS.pos = {}; XS.view = null; XS._R = null; return actX(a, d);
      case 'xpaddrow': AN.refs = xReadInputs(); if (AN.refs.length < 8) AN.refs.push(''); render(); var el = document.getElementById('xp' + (AN.refs.length - 1)); if (el) el.focus(); return;
      case 'xprm': AN.refs = xReadInputs(); AN.refs.splice(+d.i, 1); XS.pos = {}; XS.sel = null; render(); return;
      case 'xpmv': { AN.refs = xReadInputs(); var i = +d.i, j = i + +d.d; if (j < 0 || j >= AN.refs.length) return; var tmp = AN.refs[i]; AN.refs[i] = AN.refs[j]; AN.refs[j] = tmp; XS.pos = {}; XS.sel = null; render(); return; }
      case 'xpadd': { var cur0 = AN.refs.filter(function (x) { return x; }); if (cur0.length >= 8) { toast('Up to 8 passages'); return; } AN.refs = cur0.concat([d.r]); XS.sel = null; XS.pos = {}; XS._R = null; render(); toast('Added ' + d.r + ' as passage ' + XL[AN.refs.length - 1]); return; }
      case 'xppaste': XS.paste = !XS.paste; render(); return;
      case 'xppastego': { var txt = ($('#xppastet') || {}).value || '', found = [], rx = /\b((?:[1-3]\s?)?[A-Z][a-z]+(?: of [A-Z][a-z]+)?\.?)\s(\d{1,3})(?::(\d{1,3})(?:\s?[-–]\s?(\d{1,3}))?)?/g, m; while ((m = rx.exec(txt)) && found.length < 8) { var s = m[1].replace(/\.$/, '') + ' ' + m[2] + (m[3] ? ':' + m[3] + (m[4] ? '-' + m[4] : '') : ''); var p = parseRng(s); if (p && found.indexOf(p.label) < 0) found.push(p.label); } if (found.length < 2) { toast('Fewer than two references found'); return; } AN.refs = found; XS.paste = false; XS.sel = null; XS.pos = {}; XS._R = null; render(); toast(found.length + ' references found'); return; }
      case 'xptab': XS.tab = d.v; xsv(); render(); return;
      case 'xpedge': { var R = xAnalyze(); XS._R = R; var ls = (R.pairs[d.p] || []).filter(function (l) { return (!d.t || l.t === d.t) && xTypes().indexOf(l.t) >= 0; }).sort(function (x, y) { return y.w - x.w; }); if (!ls.length) return; XS.sel = { p: d.p, t: ls[0].t, l: ls[0].id }; if (XS.tab !== 'ov' && XS.tab !== 'net' && XS.tab !== 'con') XS.tab = 'net'; render(); var ds = document.querySelector('.xpdoss'); if (ds && innerWidth <= 900) ds.scrollIntoView({ block: 'start' }); return; }
      case 'xpsel': { var l = xLink(d.l); XS.sel = { p: d.p, t: l ? l.t : null, l: +d.l }; if (XS.tab !== 'ov' && XS.tab !== 'net' && XS.tab !== 'con') XS.tab = 'net'; render(); var ds2 = document.querySelector('.xpdoss'); if (ds2) ds2.scrollIntoView({ block: 'nearest' }); return; }
      case 'xpclose': XS.sel = null; render(); return;
      case 'xphide': XS.hide[d.t] = !XS.hide[d.t]; xsv(); render(); return;
      case 'xpzoom': { var vb = (XS.view || [0, 0, 900, 560]).slice(), f = +d.d > 0 ? 1.25 : 0.8, cx = vb[0] + vb[2] / 2, cy = vb[1] + vb[3] / 2, w = Math.min(3000, Math.max(250, vb[2] * f)), h = w * 560 / 900; XS.view = [cx - w / 2, cy - h / 2, w, h]; xRedraw(); return; }
      case 'xpreset': XS.pos = {}; XS.view = null; XS.focus = null; XS._R = null; render(); return;
      case 'xpfull': XS.full = !XS.full; render(); return;
      case 'xpcmp': XS.cmp = { ka: d.ka, kb: d.kb, i: +d.i, j: +d.j }; XS.tab = 'cmp'; render(); var b = document.querySelector('.xpbody'); if (b) b.scrollIntoView({ block: 'start' }); return;
      case 'xpverses': XS.cmp = XS.cmp && XS.cmp.i === +d.i && XS.cmp.j === +d.j ? XS.cmp : null; XS.tab = 'cmp'; render(); var b2 = document.querySelector('.xpbody'); if (b2) b2.scrollIntoView({ block: 'start' }); return;
      case 'xpchap': { var R2 = XS._R || xAnalyze(), p0 = R2.ps[+d.i]; if (p0) go({ b: p0.b, c: p0.c, v: p0.v1 }, true); return; }
      case 'xpsave': { var R3 = XS._R || xAnalyze(), l3 = R3.L[+d.l]; if (!l3) return; XS.saved.push({ title: XT[l3.t].n + (l3.ks.length ? ': ' + l3.ks.map(function (k) { return wzTr(k); }).join(' / ') : ': ' + l3.label), refs: l3.ps.map(function (i) { return R3.ps[i].label; }), all: AN.refs.slice(), text: xLinkText(l3, R3), at: Date.now() }); store.s('anconn', XS.saved); toast('Connection saved'); return; }
      case 'xpunsave': XS.saved.splice(+d.i, 1); store.s('anconn', XS.saved); render(); return;
      case 'xpload': { var s = XS.saved[+d.i]; if (s) { AN.refs = s.all.slice(); XS.sel = null; XS.pos = {}; XS._R = null; render(); } return; }
      case 'xpwb': { var R4 = XS._R || xAnalyze(), l4 = R4.L[+d.l]; if (!l4) return; l4.ps.forEach(function (i) { wbAdd({ t: 'v', r: R4.ps[i].label, v: mainV() }); }); l4.ks.slice(0, 2).forEach(function (k) { wbAdd({ t: 'w', k: k }); }); return; }
      case 'xpserm': { var sl = typeof SM !== 'undefined' ? SM.list : []; if (!sl.length) { toast('Create a sermon in the Sermon Workshop first'); return; } var R5 = XS._R || xAnalyze(), l5 = R5.L[+d.l]; if (!l5) return; var s5 = sl.filter(function (x) { return x.id === SW.open; })[0] || sl.slice().sort(function (a, b) { return (b.updated || 0) - (a.updated || 0); })[0]; s5.refs = s5.refs || []; l5.ps.forEach(function (i) { var lbl = R5.ps[i].label; if (!s5.refs.some(function (x) { return x.ref === lbl; })) s5.refs.push({ cat: l5.t === 'xref' ? 'xref' : 'sup', ref: lbl, ev: l5.t === 'same' || l5.t === 'xref' ? 'strong' : 'interp', note: xLinkText(l5, R5) }); }); s5.updated = Date.now(); store.s('sermons', SM); toast('Added to “' + ((s5.f && s5.f.title) || 'sermon') + '” (stage 05)'); return; }
      case 'xpaiq': { var q = d.q || (($('#xpaiq') || {}).value || '').trim(); if (!q) { toast('Type a question'); return; } xAsk(q); return; }
      case 'xpaistop': if (XAI.ctl) XAI.ctl.abort(); return;
      case 'xpaiclr': XS.ai = []; render(); return;
      case 'xpaiexp': { var R6 = XS._R || xAnalyze(), l6 = R6.L[+d.l]; if (!l6) return; xAsk('Explain this connection from the evidence, including what differs between the contexts: ' + xLinkText(l6, R6)); return; }
      case 'xpaicmp': { var C = XS.cmp; if (!C) return; xAsk('Compare how ' + C.ka + (C.ka !== C.kb ? ' and ' + C.kb : '') + ' are used in passage ' + XL[C.i] + ' and passage ' + XL[C.j] + '. Does the context change the nuance? Use the hebrew_form tool where helpful.'); return; }
    }
    return actX(a, d);
  };
  var renderX = render;
  render = function () { XS._R = null; renderX(); if (XS.full && (view === 'analyze' || view === 'study')) document.body.classList.add('xpfullon'); else document.body.classList.remove('xpfullon'); };

  // ===== 23. Pane header: one solid sticky bar with every pane control =====
  try {
    var phBase = paneHtml;
    paneHtml = function (v, i) {
      var h = phBase(v, i);
      if (h.indexOf('<div class="ph">') < 0 && h.indexOf('<div class="ph"') < 0) return h;
      h = h.replace(/<div class="ph"/, '<div class="phead"><div class="ph"');
      return h.replace('</div><div class="txt', '</div></div><div class="txt');
    };
    var phPad = function () { var rd = document.getElementById('rd'); if (rd) rd.style.setProperty('--rdpad', getComputedStyle(rd).paddingTop); };
    var phStuck = function (e) {
      var sc = e && e.target && e.target.nodeType === 1 ? e.target : null; if (!sc) return;
      sc.querySelectorAll && sc.querySelectorAll('.phead').forEach(function (hd) {
        var pane = hd.closest('.pane'); if (!pane) return;
        var st = pane.getBoundingClientRect().top < hd.getBoundingClientRect().top - 1 || (pane.scrollTop || 0) > 2;
        hd.classList.toggle('stuck', st);
      });
    };
    document.addEventListener('scroll', phStuck, true);
    window.addEventListener('resize', phPad);
    new MutationObserver(function () { if (document.querySelector('.phead')) phPad(); }).observe(document.body, { childList: true, subtree: true });
    phPad();
  } catch (e) { console.warn('pane header', e); }

  // ===== 24. Owner and admin: the creator is recognised automatically through their Claude sign-in =====
  try {
    ACC.owner = false; ACC.members = null;
    var ownerCheck = function () {
      var cl = window.claude; if (!cl || typeof cl.use !== 'function') return;
      cl.use('user').then(function (u) { if (!u || !u.isOwner) return; return Promise.resolve(u.isOwner()).then(function (o) { if (!!o !== ACC.owner) { ACC.owner = !!o; render(); } }); }).catch(function () {});
    };
    setTimeout(ownerCheck, 0);
    var loadMembers = function () {
      if (ACC.members === 'loading') return; if (!ACC.db) { ACC.members = []; return; } ACC.members = 'loading';
      Promise.resolve(ACC.db.collection('profiles').get()).then(function (sn) {
        ACC.members = ((sn && sn.docs) || []).map(function (d) { var x = d.data ? d.data() : d; return { u: x.u || '', d: x.d || '', at: x.at || 0 }; }).filter(function (m) { return m.u; }).sort(function (a, b) { return b.at - a.at; });
        if (view === 'account') render();
      }).catch(function () { ACC.members = []; if (view === 'account') render(); });
    };
    var adminCard = function () {
      if (!ACC.owner) return '';
      if (ACC.members === null) loadMembers();
      var M = Array.isArray(ACC.members) ? ACC.members : null;
      return '<div class="acccard admincard"><div class="adminh"><span class="adminbadge">' + ic('check', 13) + ' Owner · Admin</span><h2>You run this app</h2></div>' +
        '<p>You are signed in as the app\'s creator. The app recognises you automatically whenever you open it while signed in to Claude, on any device. Your username and profile below are how you appear to readers.</p>' +
        '<div class="admingrid"><button data-act="obooks">' + ic('library', 18) + '<b>Other Books shelf</b><span>Add or remove reference books everyone can read</span></button>' +
        '<button data-act="library">' + ic('book', 18) + '<b>Bible library</b><span>Your imported Bible versions</span></button>' +
        '<button data-act="kingdom">' + ic('target', 18) + '<b>Kingdom Games</b><span>Chess, Kingdom Eights, Word Treasures and more</span></button></div>' +
        '<h3 class="adminsub">Members' + (M ? ' <small>' + M.length + '</small>' : '') + '</h3>' +
        (M === null ? '<p class="dim small">Loading members…</p>' : !M.length ? '<p class="dim small">No one has created an account yet. People who open your shared link while signed in to Claude can create one.</p>' :
          '<div class="memlist">' + M.slice(0, 200).map(function (m) { return '<div><span class="av">' + esc((m.d || m.u || '?')[0].toUpperCase()) + '</span><span><b>' + esc(m.d || m.u) + '</b><small>@' + esc(m.u) + (m.at ? ' · joined ' + new Date(m.at).toLocaleDateString() : '') + '</small></span></div>'; }).join('') + '</div>') +
        '<p class="dim small">Members see only usernames and display names. Their notes, plans, ages and other details stay private to them.</p></div>';
    };
    var accPage0 = accPage;
    accPage = function () {
      var h = accPage0();
      if (!ACC.owner) return h;
      if (ACC.state === 'noprofile' || (accP() && ACC.editing)) h = h.replace('<form class="acccard" id="accform"', '<p class="adminnote">' + ic('check', 14) + ' You are the owner and admin of this app. Create your profile so readers see your username.</p><form class="acccard" id="accform"');
      var i = h.lastIndexOf('</div>'); return h.slice(0, i) + adminCard() + h.slice(i);
    };
    var side7 = sideHtml;
    sideHtml = function () {
      var h = side7(); if (!ACC.owner) return h;
      return h.replace(/(<button class="prof[^"]*"[^>]*>[\s\S]*?<span class="lb">)([\s\S]*?)(<\/span><\/button>)/, function (all, a, b, c) { return a + b.replace(/<small>/, '<small><em class="adminpill">Admin</em> ') + (b.indexOf('<small>') < 0 ? '<small><em class="adminpill">Admin</em> Owner</small>' : '') + c; });
    };
    // the account page is always reachable from the sign-in button, even in a copy opened outside Claude
    var actAdm = act;
    act = function (a, d) { if (a === 'prof' && ACC.state === 'local') { view = 'account'; render(); return; } return actAdm(a, d); };
    var accPage1 = accPage;
    accPage = function () { if (ACC.state === 'local') return '<div class="home acc"><div class="greet"><button class="ib mobm" data-act="side" aria-label="Menu">' + ic('menu') + '</button><h1>Sign in</h1></div><div class="acccard"><h2>Sign in with Claude</h2><p>This copy of the app is open outside Claude, so accounts are off and your work is saved on this device only. To sign in with your username and profile, open the app from its claude.ai link while signed in to Claude.</p></div></div>'; return accPage1(); };
    window.__acc = ACC;
  } catch (e) { console.warn('admin', e); }

  // ===== 25. Audio Bible: one recording per chapter, verse-by-verse sync with the text, original background music =====
  try {
    var AUDM = {"Genesis":{"title":"Genesis","ch":[{"f":"audio/genesis/01.mp3","d":294.98,"v":[0.0,11.1,19.55,26.45,31.85,38.8,47.05,54.8,60.0,70.1,77.65,91.45,101.9,106.55,118.05,126.05,134.3,137.9,145.05,149.7,158.95,170.8,179.8,182.5,194.35,205.15,225.4,233.15,249.6,266.9,280.05],"lo":false},{"f":"audio/genesis/02.mp3","d":191.05,"v":[0.0,4.27,11.88,20.18,27.27,39.12,43.93,53.22,58.73,70.48,76.72,82.82,87.43,93.97,102.38,107.52,113.68,124.93,132.47,145.27,154.62,163.02,169.23,177.47,183.72],"lo":false},{"f":"audio/genesis/03.mp3","d":235.65,"v":[0.0,12.73,17.68,26.08,29.48,41.58,54.83,62.73,73.52,78.08,84.33,92.77,100.18,110.03,126.58,137.28,151.78,169.93,177.38,190.88,195.63,201.08,216.23,222.68],"lo":false},{"f":"audio/genesis/04.mp3","d":215.92,"v":[0.0,7.18,13.52,19.52,27.93,34.33,39.98,55.18,63.18,71.73,79.27,86.68,97.23,101.37,114.62,127.62,133.23,142.12,151.43,157.88,163.58,169.08,177.48,189.83,195.83,206.83],"lo":false},{"f":"audio/genesis/05.mp3","d":178.43,"v":[0.0,9.55,16.6,24.35,30.8,35.9,39.55,45.75,50.7,53.4,59.7,64.6,68.05,74.05,78.45,82.15,87.8,93.3,97.2,102.5,107.5,111.55,117.9,121.8,126.4,131.3,137.9,143.5,147.35,157.4,163.9,169.2],"lo":false},{"f":"audio/genesis/06.mp3","d":208.88,"v":[0.0,5.92,12.67,22.92,35.67,44.08,49.42,64.42,67.78,75.83,79.28,84.42,91.28,105.42,113.03,125.83,139.88,156.78,168.62,179.68,192.92,203.28],"lo":false},{"f":"audio/genesis/07.mp3","d":200.45,"v":[0.0,12.45,24.25,32.55,45.35,49.2,53.7,61.2,67.75,74.75,79.9,91.1,95.15,105.45,119.0,125.7,132.7,141.5,148.5,155.3,160.6,171.3,177.85,194.0],"lo":false},{"f":"audio/genesis/08.mp3","d":190.73,"v":[0.0,13.4,19.2,26.5,32.3,40.65,46.35,52.9,58.2,70.75,75.75,86.0,92.75,107.15,112.5,114.7,120.9,139.5,144.45,153.2,161.35,178.95],"lo":false},{"f":"audio/genesis/09.mp3","d":238.8,"v":[0.0,10.27,26.27,36.07,42.12,56.12,64.17,71.92,75.47,82.82,96.47,109.02,119.82,126.62,134.67,146.72,159.07,168.17,175.32,179.67,183.57,188.17,194.07,206.02,210.42,216.32,221.97,229.02,232.72],"lo":false},{"f":"audio/genesis/10.mp3","d":196.18,"v":[0.0,9.43,16.58,21.08,26.48,34.43,38.98,48.68,52.93,60.33,67.33,73.03,77.68,82.68,88.48,91.98,95.03,98.38,105.67,116.57,123.22,130.72,136.82,141.78,145.82,155.42,160.72,163.82,166.67,172.03,177.67,183.88],"lo":false},{"f":"audio/genesis/11.mp3","d":198.12,"v":[0.0,4.05,10.2,17.65,27.95,32.5,47.35,53.8,60.1,71.3,78.25,83.65,87.35,93.55,96.45,102.05,105.65,111.3,114.45,120.15,123.75,129.35,133.0,138.1,141.6,147.15,152.0,158.4,163.85,174.75,177.35,192.6],"lo":false},{"f":"audio/genesis/12.mp3","d":182.97,"v":[0.0,12.97,21.77,30.72,39.32,53.17,60.07,69.42,82.32,85.57,92.92,103.37,115.27,124.38,131.12,137.97,147.22,152.82,161.22,172.97],"lo":false},{"f":"audio/genesis/13.mp3","d":155.5,"v":[0.0,6.45,10.45,18.15,24.75,28.85,36.6,44.95,55.95,71.3,84.7,91.85,98.3,103.05,117.2,124.35,135.3,143.75],"lo":false},{"f":"audio/genesis/14.mp3","d":205.55,"v":[0.0,9.15,20.25,24.4,28.45,39.85,44.95,54.25,65.0,75.3,84.2,89.05,95.15,105.6,115.45,124.8,131.9,141.65,147.9,155.45,163.2,168.9,178.75,191.5],"lo":false},{"f":"audio/genesis/15.mp3","d":172.72,"v":[0.0,11.1,20.05,27.85,37.95,49.35,53.8,62.35,66.95,78.5,86.95,91.45,99.4,111.25,120.7,127.35,135.4,144.15,156.25,163.95,165.75],"lo":false},{"f":"audio/genesis/16.mp3","d":147.07,"v":[0.0,9.02,23.07,33.27,40.27,54.57,66.02,71.88,82.52,88.82,96.97,108.67,118.57,126.47,132.38,138.72],"lo":false},{"f":"audio/genesis/17.mp3","d":263.35,"v":[0.0,11.55,17.2,20.65,27.7,38.0,46.65,62.7,74.5,83.35,93.5,101.5,116.5,129.65,140.95,151.35,163.95,176.35,181.55,197.1,212.55,220.4,224.6,239.4,245.0,250.75,255.65],"lo":false},{"f":"audio/genesis/18.mp3","d":305.9,"v":[0.0,8.1,17.5,25.25,32.65,45.85,55.5,62.75,70.75,76.7,87.7,94.25,101.8,110.7,121.65,130.35,136.45,141.5,149.1,165.0,173.25,183.4,189.25,194.95,205.0,219.7,227.75,236.25,250.35,258.5,269.9,281.85,294.55],"lo":false},{"f":"audio/genesis/19.mp3","d":344.35,"v":[0.0,10.7,24.4,33.2,41.55,50.5,54.05,57.8,71.1,88.15,93.4,100.95,110.8,118.05,129.3,140.85,152.95,166.4,169.6,183.25,194.3,205.3,214.9,218.55,224.25,231.25,236.2,240.95,249.95,261.55,271.4,280.9,287.4,296.4,312.65,321.3,325.0,331.65],"lo":false},{"f":"audio/genesis/20.mp3","d":183.62,"v":[0.0,7.4,14.25,24.9,31.5,42.95,56.35,73.85,82.1,98.25,104.0,112.5,122.0,139.1,146.7,153.15,167.6,174.2],"lo":false},{"f":"audio/genesis/21.mp3","d":250.85,"v":[0.0,5.62,11.92,17.77,23.17,27.67,33.22,42.32,47.97,53.22,62.52,66.32,82.32,88.17,100.02,104.38,116.47,129.97,137.32,144.38,149.27,155.07,165.92,181.38,185.67,191.88,199.92,205.02,208.68,215.22,224.88,229.88,239.07,245.47],"lo":false},{"f":"audio/genesis/22.mp3","d":219.48,"v":[0.0,12.62,25.98,38.28,43.23,53.23,62.48,73.63,82.57,93.28,97.13,106.23,122.73,134.93,143.32,147.33,157.73,173.23,181.98,190.38,198.73,203.53,208.48,213.43],"lo":false},{"f":"audio/genesis/23.mp3","d":179.82,"v":[0.0,11.0,18.85,23.6,34.15,37.15,49.95,55.3,66.05,79.95,89.65,103.0,106.55,120.3,122.75,132.75,143.75,154.8,161.55,169.7],"lo":false},{"f":"audio/genesis/24.mp3","d":598.3,"v":[0.0,6.07,14.62,28.78,37.32,47.48,54.12,75.93,86.07,92.23,103.32,111.48,120.98,129.18,150.78,162.07,171.12,177.32,183.43,190.38,197.88,204.32,214.23,221.98,228.33,233.88,237.23,251.62,255.32,261.07,274.98,282.62,291.98,300.32,303.32,315.53,325.07,333.93,341.38,345.53,359.48,369.32,378.23,390.53,401.98,417.38,429.43,442.88,455.38,465.82,473.28,480.57,487.38,497.12,506.53,514.38,521.93,526.82,532.98,538.12,547.82,555.82,561.12,569.12,573.98,584.57,587.82],"lo":false},{"f":"audio/genesis/25.mp3","d":242.65,"v":[0.0,6.88,13.12,20.12,28.07,30.93,40.73,46.93,55.23,63.68,70.32,77.57,84.62,92.82,97.68,102.88,110.32,118.62,127.32,132.18,140.57,148.82,156.23,170.68,175.27,180.98,190.48,197.48,202.43,206.57,215.73,219.02,225.98,232.52],"lo":false},{"f":"audio/genesis/26.mp3","d":290.0,"v":[0.0,12.17,20.07,35.97,47.77,56.22,57.92,70.47,79.62,91.27,100.72,108.62,115.07,119.67,126.32,134.07,139.62,145.12,157.62,161.97,171.62,177.17,190.17,192.82,206.12,214.52,221.67,228.42,239.87,252.17,255.27,263.12,271.77,276.67,285.42],"lo":false},{"f":"audio/genesis/27.mp3","d":439.85,"v":[0.0,14.77,21.97,33.07,42.72,49.07,56.22,62.67,68.42,78.47,83.77,89.07,99.67,107.52,113.17,120.62,125.52,130.57,137.72,150.07,159.07,170.12,180.02,186.57,190.97,201.82,206.92,218.62,227.72,245.27,257.57,267.77,274.67,290.37,300.27,305.27,320.32,337.72,348.37,358.27,372.02,384.37,396.98,405.38,408.97,422.07],"lo":false},{"f":"audio/genesis/28.mp3","d":203.85,"v":[0.0,8.42,27.42,36.97,45.07,53.17,66.22,70.27,74.22,84.07,87.27,97.62,106.57,120.12,135.07,150.02,156.42,166.42,174.47,179.97,189.07,195.27],"lo":false},{"f":"audio/genesis/29.mp3","d":251.75,"v":[0.0,9.12,18.77,27.62,33.47,38.52,44.67,53.82,62.02,66.92,79.88,83.42,90.17,100.82,107.97,116.77,122.22,126.12,132.02,139.17,145.47,152.12,155.92,162.32,166.67,178.93,184.62,190.97,196.47,201.12,208.47,213.62,223.02,232.67,242.77],"lo":false},{"f":"audio/genesis/30.mp3","d":324.45,"v":[0.0,8.93,17.82,26.07,30.57,33.12,42.17,46.47,54.27,59.72,62.42,66.42,69.27,75.27,86.12,98.42,108.92,113.32,120.27,123.57,132.82,136.42,140.72,146.22,150.93,160.62,168.42,177.77,180.67,187.07,199.97,210.47,225.92,242.92,247.52,259.97,266.22,275.42,284.27,289.77,301.38,310.72,317.12],"lo":false},{"f":"audio/genesis/31.mp3","d":484.18,"v":[0.0,11.62,17.07,24.52,28.52,37.93,42.57,51.18,63.57,68.02,81.47,87.62,100.02,113.22,120.27,126.47,134.62,138.43,148.43,153.43,159.02,165.88,169.43,176.32,185.52,193.02,203.62,215.18,223.12,233.27,243.68,253.27,265.38,276.07,284.27,294.88,304.62,316.18,327.52,337.07,344.77,358.77,374.02,391.43,398.88,402.02,409.47,414.38,421.97,428.32,438.27,445.72,456.47,465.97,473.57],"lo":false},{"f":"audio/genesis/32.mp3","d":263.15,"v":[0.0,3.7,10.75,16.2,26.7,36.5,45.05,53.1,59.9,72.8,86.6,96.65,104.35,109.9,114.4,120.7,131.2,141.45,151.6,159.8,175.35,180.4,187.75,191.75,197.15,205.3,212.5,216.8,226.5,236.3,244.25,249.55],"lo":false},{"f":"audio/genesis/33.mp3","d":166.15,"v":[0.0,10.95,17.65,23.8,30.05,40.9,45.4,53.1,61.15,67.2,83.3,94.9,99.6,111.0,124.6,134.6,137.6,145.05,153.35,161.25],"lo":false},{"f":"audio/genesis/34.mp3","d":249.75,"v":[0.0,8.2,14.8,20.85,25.5,34.1,38.25,49.45,58.4,66.05,75.4,83.25,91.75,98.4,106.45,113.4,121.3,128.2,131.4,138.95,144.55,158.05,167.75,175.9,184.9,197.2,203.95,209.05,214.75,222.05,241.8],"lo":false},{"f":"audio/genesis/35.mp3","d":210.52,"v":[0.0,13.25,23.6,33.2,42.2,49.45,55.8,63.4,70.55,74.95,85.95,98.15,106.45,109.7,118.1,122.4,129.2,134.3,144.85,149.1,154.0,157.75,167.85,174.55,177.5,181.35,189.1,196.2,199.05],"lo":false},{"f":"audio/genesis/36.mp3","d":286.55,"v":[0.0,3.68,11.02,15.33,19.78,27.28,39.48,46.12,49.93,54.62,61.83,67.33,76.08,84.53,93.53,102.88,111.08,123.12,134.38,138.33,146.23,151.93,157.12,163.53,172.73,177.48,183.23,188.23,192.12,198.93,206.78,212.38,217.23,222.58,227.48,235.83,240.43,244.88,249.23,259.88,268.98,272.08,275.38],"lo":false},{"f":"audio/genesis/37.mp3","d":271.42,"v":[0.0,7.67,20.82,27.12,33.88,38.27,42.23,51.57,61.92,70.88,84.27,87.88,90.62,99.88,111.27,117.82,122.48,130.52,136.23,140.27,151.57,155.67,166.77,173.82,178.27,188.98,194.62,204.17,214.82,219.77,225.22,229.62,238.27,249.23,254.57,265.52],"lo":false},{"f":"audio/genesis/38.mp3","d":237.05,"v":[0.0,9.0,15.2,19.15,23.35,29.45,33.3,37.9,44.55,54.2,59.1,72.35,82.1,88.2,99.85,103.95,115.85,122.25,134.2,139.75,146.5,154.6,162.25,169.9,183.9,195.2,206.55,210.95,219.6,230.55],"lo":false},{"f":"audio/genesis/39.mp3","d":184.08,"v":[0.0,13.05,18.9,24.65,32.85,45.5,54.4,61.2,70.6,82.25,89.05,96.2,102.85,107.8,117.1,124.7,130.45,138.0,143.05,152.0,159.75,165.15,173.3],"lo":false},{"f":"audio/genesis/40.mp3","d":169.9,"v":[0.0,6.88,12.98,18.62,25.23,35.93,40.52,46.38,56.38,63.83,72.43,79.02,84.88,96.27,105.83,112.93,122.83,131.47,137.38,146.68,156.18,161.77,165.43],"lo":false},{"f":"audio/genesis/41.mp3","d":434.47,"v":[0.0,9.12,15.47,23.38,29.67,36.07,40.97,47.72,60.37,65.77,72.92,81.62,93.42,100.47,109.38,119.02,124.88,130.42,137.87,149.72,154.27,162.12,168.27,174.62,181.97,188.72,195.62,205.57,211.82,219.82,230.32,237.07,243.67,251.02,258.77,267.22,276.22,280.72,287.17,294.38,302.52,307.88,316.22,324.47,333.02,344.02,352.47,356.07,366.67,373.27,380.82,388.88,394.77,398.67,407.22,417.38,427.22],"lo":false},{"f":"audio/genesis/42.mp3","d":320.5,"v":[0.0,10.0,25.6,28.9,36.05,41.45,51.35,62.65,65.35,72.45,77.35,82.8,87.2,98.7,103.75,110.65,123.15,126.0,130.95,138.9,146.5,160.2,171.1,175.9,184.9,194.05,197.35,204.95,217.0,222.85,228.8,233.25,242.7,256.55,269.25,279.25,294.9,303.15],"lo":false},{"f":"audio/genesis/43.mp3","d":327.52,"v":[0.0,3.0,16.1,23.65,28.25,36.7,44.4,62.8,73.5,84.75,88.85,110.8,130.85,139.35,158.9,167.2,175.95,180.1,195.5,200.65,205.45,219.9,227.05,238.65,245.6,251.25,258.2,266.35,273.75,283.75,291.2,295.65,308.25,315.55],"lo":false},{"f":"audio/genesis/44.mp3","d":282.93,"v":[0.0,8.28,16.33,20.53,31.12,38.68,42.33,50.08,61.73,68.77,78.53,83.83,89.88,95.13,100.98,107.38,123.33,132.53,145.73,149.23,162.38,168.28,176.13,185.08,192.03,195.93,207.88,214.38,221.38,229.98,238.78,251.88,261.13,273.48],"lo":false},{"f":"audio/genesis/45.mp3","d":235.67,"v":[0.0,14.15,17.9,26.55,36.6,47.3,53.75,61.35,72.0,83.1,93.9,104.5,110.75,117.9,123.25,128.85,136.0,144.3,153.3,162.65,168.75,176.3,183.95,193.6,199.75,204.3,214.35,223.6],"lo":false},{"f":"audio/genesis/46.mp3","d":266.58,"v":[0.0,9.68,17.78,27.58,36.03,44.93,52.12,59.48,66.73,71.62,80.33,84.88,96.38,101.68,106.03,114.98,122.73,133.88,141.03,144.92,153.03,162.68,167.27,169.78,175.53,183.23,191.73,200.62,207.28,217.42,226.98,238.28,245.08,250.67],"lo":false},{"f":"audio/genesis/47.mp3","d":310.58,"v":[0.0,11.65,16.1,24.65,40.4,45.1,58.8,64.5,67.4,88.95,93.95,103.75,110.3,118.6,127.6,138.95,143.65,155.05,169.6,185.45,195.15,201.1,211.0,220.7,234.2,243.05,252.4,259.7,266.65,289.25,302.5],"lo":false},{"f":"audio/genesis/48.mp3","d":261.07,"v":[0.0,10.82,17.97,26.72,43.27,62.62,73.32,97.52,101.72,110.82,119.72,129.97,134.72,144.17,154.72,168.42,188.32,198.02,205.77,223.52,236.17,245.88],"lo":false},{"f":"audio/genesis/49.mp3","d":399.6,"v":[0.0,10.75,17.3,34.6,47.6,52.8,67.15,79.7,93.25,109.9,122.1,137.6,141.8,149.9,151.6,161.1,166.1,184.7,193.85,208.4,230.05,234.95,248.95,255.55,284.7,301.3,317.1,327.55,335.95,348.5,366.8,380.45,387.6],"lo":true},{"f":"audio/genesis/50.mp3","d":228.1,"v":[0.0,4.55,10.45,19.45,30.35,45.9,51.65,59.55,67.35,72.0,82.15,93.55,96.85,108.7,115.95,124.6,132.5,150.45,156.85,163.8,171.2,181.7,187.2,195.3,207.9,216.15],"lo":false}]}};
    var AUS = (function () { try { return JSON.parse(localStorage.getItem('audset') || '{}'); } catch (e) { return {}; } })();
    AUS = Object.assign({ music: true, mv: 0.3, rate: 1, follow: true, pos: {} }, AUS);
    if (!AUS.f2) { AUS.f2 = 1; AUS.follow = true; try { localStorage.setItem('audset', JSON.stringify(AUS)); } catch (e) {} } // auto-scroll back on for everyone once
    var ausSave = function () { try { localStorage.setItem('audset', JSON.stringify(AUS)); } catch (e) {} };
    var AU = { book: null, c: 1, el: new Audio(), bar: null, drag: false, lastSave: 0, vi: -1, userScroll: 0, open: false };
    var REP = { mode: 'off', a: 1, b: 1, rc: 1, ca: 1, cb: 1, books: [], times: 0, done: 0 };
    AU.el.preload = 'auto';
    var SVGI = {
      play: '<svg viewBox="0 0 24 24" width="22" height="22" fill="currentColor" aria-hidden="true"><path d="M7 4.5v15l13-7.5z"/></svg>',
      pause: '<svg viewBox="0 0 24 24" width="22" height="22" fill="currentColor" aria-hidden="true"><path d="M6 4h4.5v16H6zM13.5 4H18v16h-4.5z"/></svg>',
      back: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M4 12a8 8 0 1 0 2.3-5.6"/><path d="M4 4v4h4"/><text x="12" y="15.5" font-size="7" text-anchor="middle" fill="currentColor" stroke="none" font-family="system-ui">15</text></svg>',
      fwd: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M20 12a8 8 0 1 1-2.3-5.6"/><path d="M20 4v4h-4"/><text x="12" y="15.5" font-size="7" text-anchor="middle" fill="currentColor" stroke="none" font-family="system-ui">30</text></svg>',
      music: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M9 18V5l11-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="17" cy="16" r="3"/></svg>',
      rep: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M17 2l4 4-4 4"/><path d="M3 11V9a3 3 0 013-3h15M7 22l-4-4 4-4"/><path d="M21 13v2a3 3 0 01-3 3H3"/></svg>',
      dl: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M12 4v11M7 10l5 5 5-5M5 20h14"/></svg>'
    };
    var fmt = function (t) { t = Math.max(0, Math.floor(t || 0)); var h = Math.floor(t / 3600), m = Math.floor(t % 3600 / 60), s = t % 60; return (h ? h + ':' + (m < 10 ? '0' : '') : '') + m + ':' + (s < 10 ? '0' : '') + s; };
    var aBook = function () { return AU.book && AUDM[AU.book]; };
    var aCh = function () { var B = aBook(); return B ? B.ch[AU.c - 1] : null; };
    var aVerseAt = function (t) { var C = aCh(); if (!C) return 0; var i = 0; for (var k = 0; k < C.v.length; k++) if (C.v[k] <= t + 0.15) i = k; return i; };
    var aLoad = function (c, t, play) {
      var B = aBook(); if (!B || c < 1 || c > B.ch.length) return; var same = AU.c === c && AU.el.src;
      AU.c = c; AU.vi = -1;
      var go = function () { try { AU.el.currentTime = t || 0; } catch (e) {} if (play) aPlay(); abUpdate(true); aSync(true); };
      if (!same) { AU.el.src = B.ch[c - 1].f; AU.el.playbackRate = AUS.rate; AU.el.addEventListener('loadedmetadata', function h() { AU.el.removeEventListener('loadedmetadata', h); go(); }); AU.el.load(); }
      else go();
    };
    var aPlay = function () { var p = AU.el.play(); if (p && p.catch) p.catch(function () { abUpdate(); }); if (AUS.music) muOn(); };
    var aPause = function () { AU.el.pause(); muOff(); abUpdate(); };
    AU.el.addEventListener('ended', function () { var B = aBook(); if (!B) return; var nx = repNext(); if (nx) { if (nx.book !== AU.book) { AU.book = nx.book; AU.el.removeAttribute('src'); } aLoad(nx.c, 0, true); return; } if (AU.c < B.ch.length) aLoad(AU.c + 1, 0, true); else { muOff(); clearHL(); abUpdate(); } });
    // what to play when a chapter ends, given the repeat setting (null = carry on normally)
    var repCount = function () { REP.done++; if (REP.times && REP.done >= REP.times) { REP.mode = 'off'; REP.done = 0; abUpdate(true); toast('Repeat finished'); return false; } return true; };
    var repNext = function () {
      var B = aBook(), last = B.ch.length;
      if (REP.mode === 'ch') return repCount() ? { book: AU.book, c: AU.c } : null;
      if (REP.mode === 'book' && AU.c >= last) return repCount() ? { book: AU.book, c: 1 } : null;
      if (REP.mode === 'chs') { if (AU.c >= REP.cb || AU.c < REP.ca) return repCount() ? { book: AU.book, c: REP.ca } : null; return { book: AU.book, c: AU.c + 1 }; }
      if (REP.mode === 'books' && REP.books.length && AU.c >= last) { var i = REP.books.indexOf(AU.book), nb = REP.books[(i + 1) % REP.books.length]; if (i === REP.books.length - 1 || i < 0) { if (!repCount()) return null; } return { book: nb, c: 1 }; }
      return null;
    };
    // verse repeat: jump back to the first verse when the last one finishes
    var repVerseTick = function () {
      if (REP.mode !== 'vs' || !AU.open || AU.el.paused || AU.c !== REP.rc) return; var C = aCh(); if (!C) return;
      var end = REP.b < C.v.length ? C.v[REP.b] : (AU.el.duration || C.d) - 0.25, t = AU.el.currentTime;
      if (t >= end - 0.05 || t < C.v[REP.a - 1] - 1.5) { if (t >= end - 0.05) { if (!repCount()) return; } AU.el.currentTime = C.v[REP.a - 1] || 0; aSync(true); }
    };
    AU.el.addEventListener('timeupdate', repVerseTick);
    AU.el.addEventListener('timeupdate', function () { abUpdate(); aSync(); var n = Date.now(); if (n - AU.lastSave > 5000 && AU.book) { AU.lastSave = n; AUS.pos[AU.book] = { c: AU.c, t: AU.el.currentTime }; ausSave(); } });
    AU.el.addEventListener('play', function () { abUpdate(); if (AUS.music) muOn(); AU.userScroll = 0; AU.starting = true; aSync(true); setTimeout(function () { AU.starting = false; }, 1500); });
    AU.el.addEventListener('pause', function () { abUpdate(); muOff(); });
    AU.el.addEventListener('error', function () { if (AU.el.src) toast('This recording could not load. Check your connection and try again.'); });
    /* ---- follow along: highlight the verse being read and keep it in view ---- */
    var clearHL = function () { document.querySelectorAll('.vs.aunow').forEach(function (e) { e.classList.remove('aunow'); }); };
    document.addEventListener('wheel', function () { AU.userScroll = Date.now(); }, { passive: true });
    document.addEventListener('touchmove', function () { AU.userScroll = Date.now(); }, { passive: true });
    var aSync = function (force) {
      if (!AU.book || !AU.open) return; var i = aVerseAt(AU.el.currentTime || 0);
      if (!force && i === AU.vi && document.querySelector('.vs.aunow')) return; AU.vi = i;
      clearHL(); if (!(view === 'read' && cur && cur.b === AU.book && +cur.c === AU.c)) return;
      var els = document.querySelectorAll('.vs[data-vk$="|' + AU.book + ' ' + AU.c + ':' + (i + 1) + '"]'); els.forEach(function (e) { e.classList.add('aunow'); });
      var main = Array.prototype.filter.call(els, function (e) { return e.closest('#rd'); })[0] || els[0];
      if (main && AUS.follow && Date.now() - AU.userScroll > 3000 && (!AU.el.paused || AU.starting)) aScrollTo(main);
    };
    // scroll the reading area itself (scrollIntoView can move the wrong container inside an embedded page on phones)
    var aScrollTo = function (el) {
      var sc = el.parentElement; while (sc && sc !== document.body) { var cs = getComputedStyle(sc); if (/(auto|scroll)/.test(cs.overflowY) && sc.scrollHeight > sc.clientHeight + 4) break; sc = sc.parentElement; }
      var r = el.getBoundingClientRect();
      if (!sc || sc === document.body) { try { el.scrollIntoView({ block: 'center', behavior: 'smooth' }); } catch (e) { el.scrollIntoView(); } return; }
      var cr = sc.getBoundingClientRect(), target = sc.scrollTop + (r.top - cr.top) - cr.height * 0.35;
      if (Math.abs(r.top - cr.top - cr.height * 0.35) > 24) sc.scrollTo({ top: Math.max(0, target), behavior: 'smooth' });
      // if that did not bring the verse on screen (for example when the page is shown inside another window), let the browser do it
      setTimeout(function () { var q = el.getBoundingClientRect(); if (q.bottom < 60 || q.top > (window.visualViewport ? visualViewport.height : innerHeight) - 140) { try { el.scrollIntoView({ block: 'center', behavior: 'smooth' }); } catch (e) { el.scrollIntoView(); } } }, 700);
    };
    // a steady check: keeps the highlight current and turns the page when the recording has moved to another chapter
    setInterval(function () {
      if (!AU.open || !AU.book) return;
      if (AUS.follow && view === 'read' && cur && cur.b === AU.book && AU.followC !== AU.c) {
        if (AU.followC == null || +cur.c === AU.followC) { AU.followC = AU.c; if (+cur.c !== AU.c) { go({ b: AU.book, c: AU.c, v: 1 }, true); return; } }
        else AU.followC = AU.c; // the reader moved elsewhere on purpose: leave them there
      }
      if (!AU.el.paused) { aSync(); repVerseTick(); }
    }, 250);
    /* ---- original background music, generated live (no recorded music is used) ---- */
    var MU = { ctx: null, out: null, timer: null, step: 0 };
    var hz = function (n) { return 440 * Math.pow(2, (n - 69) / 12); };
    var CHORDS = [[50, 57, 62, 65, 69], [46, 53, 62, 65, 70], [53, 60, 65, 69, 72], [48, 55, 64, 67, 72], [50, 57, 62, 65, 69], [43, 50, 62, 67, 70], [45, 52, 61, 64, 69], [50, 57, 62, 66, 69]];
    var muBuild = function () {
      var C = window.AudioContext || window.webkitAudioContext; if (!C) return false;
      var ctx = MU.ctx = new C(), out = MU.out = ctx.createGain(); out.gain.value = 0;
      var verb = ctx.createConvolver(), len = ctx.sampleRate * 4.5, ir = ctx.createBuffer(2, len, ctx.sampleRate);
      for (var ch = 0; ch < 2; ch++) { var d = ir.getChannelData(ch); for (var i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 3.2); }
      verb.buffer = ir; var wet = ctx.createGain(); wet.gain.value = 0.85; var dry = ctx.createGain(); dry.gain.value = 0.35;
      MU.bus = ctx.createBiquadFilter(); MU.bus.type = 'lowpass'; MU.bus.frequency.value = 1500; MU.bus.Q.value = 0.4;
      MU.bus.connect(dry); MU.bus.connect(verb); verb.connect(wet); dry.connect(out); wet.connect(out); out.connect(ctx.destination);
      // a low drone under everything
      var dr = ctx.createOscillator(), dg = ctx.createGain(); dr.type = 'sine'; dr.frequency.value = hz(38); dg.gain.value = 0.05; dr.connect(dg); dg.connect(MU.bus); dr.start();
      return true;
    };
    var muChord = function () {
      var ctx = MU.ctx; if (!ctx) return; var t = ctx.currentTime, ch = CHORDS[MU.step % CHORDS.length], L = 11;
      ch.forEach(function (n, k) {
        [-5, 5].forEach(function (det) {
          var o = ctx.createOscillator(), g = ctx.createGain(); o.type = k === 0 ? 'triangle' : 'sawtooth'; o.frequency.value = hz(n); o.detune.value = det + (k ? 0 : 0);
          var lvl = k === 0 ? 0.05 : 0.018; g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(lvl, t + 3.5); g.gain.setValueAtTime(lvl, t + L - 1); g.gain.linearRampToValueAtTime(0, t + L + 3.5);
          o.connect(g); g.connect(MU.bus); o.start(t); o.stop(t + L + 4);
        });
      });
      if (MU.step % 4 === 3) { // a soft drum swell for drama
        var nb = ctx.createBuffer(1, ctx.sampleRate * 3, ctx.sampleRate), nd = nb.getChannelData(0); for (var i = 0; i < nd.length; i++) nd[i] = Math.random() * 2 - 1;
        var src = ctx.createBufferSource(), f = ctx.createBiquadFilter(), g2 = ctx.createGain(); src.buffer = nb; f.type = 'lowpass'; f.frequency.value = 140;
        g2.gain.setValueAtTime(0, t + 6); g2.gain.linearRampToValueAtTime(0.35, t + 8.6); g2.gain.exponentialRampToValueAtTime(0.001, t + 9.6); src.connect(f); f.connect(g2); g2.connect(MU.bus); src.start(t + 6); src.stop(t + 9.7);
      }
      MU.step++;
    };
    var muOn = function () {
      if (!MU.ctx && !muBuild()) return; if (MU.ctx.state === 'suspended') MU.ctx.resume();
      MU.out.gain.cancelScheduledValues(MU.ctx.currentTime); MU.out.gain.setTargetAtTime(AUS.mv * 0.5, MU.ctx.currentTime, 1.2);
      if (!MU.timer) { muChord(); MU.timer = setInterval(muChord, 10000); }
    };
    var muOff = function () { if (!MU.ctx) return; MU.out.gain.setTargetAtTime(0, MU.ctx.currentTime, 0.6); clearInterval(MU.timer); MU.timer = null; };

    /* ---- the player bar ---- */
    var abBuild = function () {
      if (AU.bar) return AU.bar; var b = document.createElement('div'); b.id = 'abar'; b.className = 'abar'; b.setAttribute('role', 'region'); b.setAttribute('aria-label', 'Audio Bible player');
      b.innerHTML = '<div class="abmain"><button class="abs" data-ab="prev" aria-label="Previous chapter">' + ic('cl', 16) + '</button><button class="abpp" data-ab="pp" aria-label="Play">' + SVGI.play + '</button><button class="abs" data-ab="next" aria-label="Next chapter">' + ic('cr', 16) + '</button><button class="abs" data-ab="back" aria-label="Back 15 seconds">' + SVGI.back + '</button>' +
        '<div class="abinfo"><div class="abtitle"><b data-abf="title"></b> <span data-abf="vs"></span> <em data-abf="lo" title="Verse timing in this chapter is less certain">sync approximate</em></div><input type="range" class="abseek" data-ab="seek" min="0" max="1000" step="1" value="0" aria-label="Position in the chapter"><div class="abtime"><span data-abf="now">0:00</span><span data-abf="tot">0:00</span></div></div></div>' +
        '<div class="abside"><label class="abch">Chapter <select data-ab="chap" aria-label="Chapter"></select></label>' +
        '<select data-ab="rate" aria-label="Speed"><option value="0.75">0.75×</option><option value="0.9">0.9×</option><option value="1">1×</option><option value="1.15">1.15×</option><option value="1.3">1.3×</option><option value="1.5">1.5×</option></select>' +
        '<button class="abtg" data-ab="follow" aria-pressed="true" title="Highlight the verse being read and scroll with it">' + ic('book', 16) + '<span data-abf="fl">Auto-scroll: On</span></button>' +
        '<button class="abtg" data-ab="music" aria-pressed="false" title="Background music">' + SVGI.music + '<span>Music</span></button><input type="range" class="abvol" data-ab="mv" min="0" max="100" value="30" aria-label="Music volume">' +
        '<button class="abtg" data-ab="repm" title="Repeat">' + SVGI.rep + '<span data-abf="repl">Repeat</span></button>' +
        '<button class="abtg" data-ab="dlm" title="Download">' + SVGI.dl + '<span>Download</span></button>' +
        '<button class="ib abx" data-ab="close" aria-label="Close player">' + ic('x', 16) + '</button></div>' +
        '<div class="abdl" data-abf="dl" hidden></div><div class="abrep" data-abf="rep" hidden></div>';
      b.addEventListener('click', function (e) {
        var t = e.target.closest('[data-ab]'); if (!t) return; var k = t.dataset.ab;
        if (k === 'pp') { if (AU.el.paused) aPlay(); else aPause(); }
        else if (k === 'back') { AU.el.currentTime = Math.max(0, AU.el.currentTime - 15); aSync(true); }
        else if (k === 'prev' || k === 'next') { var c = AU.c + (k === 'next' ? 1 : -1), B = aBook(); if (c >= 1 && c <= B.ch.length) { if (view === 'read' && cur && cur.b === AU.book) AU.followC = +cur.c; aLoad(c, 0, true); } }
        else if (k === 'follow') { AUS.follow = !AUS.follow; ausSave(); abUpdate(true); if (AUS.follow) { AU.userScroll = 0; AU.followC = (cur && cur.b === AU.book) ? +cur.c : null; aSync(true); } }
        else if (k === 'music') { AUS.music = !AUS.music; ausSave(); if (AUS.music && !AU.el.paused) muOn(); else muOff(); abUpdate(true); }
        else if (k === 'dlm') { var dl = b.querySelector('[data-abf="dl"]'); dl.hidden = !dl.hidden; }
        else if (k === 'repm') { var rp = b.querySelector('[data-abf="rep"]'); rp.hidden = !rp.hidden; b.querySelector('[data-abf="dl"]').hidden = true; if (!rp.hidden) repPanel(); }
        else if (k === 'rmode') { repSet(t.dataset.v); }
        else if (k === 'rtimes') { REP.times = +t.dataset.v; REP.done = 0; repPanel(); abUpdate(true); }
        else if (k === 'rsel') { var r = repFromSel(); if (r) { REP.rc = r.c; REP.a = r.a; REP.b = r.b; repSet('vs'); if (AU.c !== r.c) aLoad(r.c, aBook().ch[r.c - 1].v[r.a - 1], true); else { AU.el.currentTime = aCh().v[r.a - 1]; aSync(true); } } }
        else if (k === 'close') { aPause(); clearHL(); b.remove(); document.body.classList.remove('abopen'); AU.open = false; }
      });
      b.addEventListener('input', function (e) { var t = e.target; if (t.dataset.ab === 'seek') { AU.drag = true; b.querySelector('[data-abf="now"]').textContent = fmt(t.value / 1000 * (aCh() ? aCh().d : 0)); } if (t.dataset.ab === 'mv') { AUS.mv = t.value / 100; ausSave(); if (MU.out && MU.timer) MU.out.gain.setTargetAtTime(AUS.mv * 0.5, MU.ctx.currentTime, 0.2); } });
      b.addEventListener('change', function (e) { var t = e.target, k = t.dataset.ab;
        if (k === 'ra' || k === 'rb') { REP[k === 'ra' ? 'a' : 'b'] = +t.value; if (REP.b < REP.a) { if (k === 'ra') REP.b = REP.a; else REP.a = REP.b; } REP.rc = AU.c; REP.done = 0; if (REP.mode === 'vs') { AU.el.currentTime = aCh().v[REP.a - 1]; aSync(true); } repPanel(); abUpdate(true); }
        if (k === 'rca' || k === 'rcb') { REP[k === 'rca' ? 'ca' : 'cb'] = +t.value; if (REP.cb < REP.ca) { if (k === 'rca') REP.cb = REP.ca; else REP.ca = REP.cb; } REP.done = 0; repPanel(); abUpdate(true); }
        if (k === 'rbook') { var bk = t.value; REP.books = REP.books.filter(function (x) { return x !== bk; }); if (t.checked) REP.books.push(bk); var order = Object.keys(AUDM); REP.books.sort(function (x, y) { return BOOKS.indexOf(x) - BOOKS.indexOf(y); }); repPanel(); abUpdate(true); }
        if (k === 'seek') { AU.drag = false; AU.el.currentTime = t.value / 1000 * (AU.el.duration || aCh().d); AU.userScroll = 0; aSync(true); }
        if (k === 'chap') { var c = +t.value; if (view === 'read' && cur && cur.b === AU.book) AU.followC = +cur.c; aLoad(c, 0, true); }
        if (k === 'rate') { AUS.rate = +t.value; ausSave(); AU.el.playbackRate = AUS.rate; }
      });
      return AU.bar = b;
    };
    var abUpdate = function (full) {
      var b = AU.bar, B = aBook(), C = aCh(); if (!b || !B || !C || !document.body.contains(b)) return; var t = AU.el.currentTime || 0, T = AU.el.duration || C.d;
      var pp = b.querySelector('[data-ab="pp"]'), playing = !AU.el.paused; if (pp.dataset.st !== String(playing)) { pp.dataset.st = String(playing); pp.innerHTML = playing ? SVGI.pause : SVGI.play; pp.setAttribute('aria-label', playing ? 'Pause' : 'Play'); }
      b.querySelector('[data-abf="title"]').textContent = B.title + ' ' + AU.c; b.querySelector('[data-abf="vs"]').textContent = 'verse ' + (aVerseAt(t) + 1) + ' of ' + C.v.length;
      b.querySelector('[data-abf="lo"]').hidden = !C.lo;
      if (!AU.drag) { b.querySelector('[data-ab="seek"]').value = T ? Math.round(t / T * 1000) : 0; b.querySelector('[data-abf="now"]').textContent = fmt(t); }
      b.querySelector('[data-abf="tot"]').textContent = fmt(T);
      var cs = b.querySelector('[data-ab="chap"]'); if (cs.options.length !== B.ch.length) cs.innerHTML = B.ch.map(function (_, i) { return '<option value="' + (i + 1) + '">' + (i + 1) + '</option>'; }).join('');
      if (document.activeElement !== cs) cs.value = String(AU.c);
      b.querySelector('[data-ab="prev"]').disabled = AU.c <= 1; b.querySelector('[data-ab="next"]').disabled = AU.c >= B.ch.length;
      b.querySelector('[data-ab="rate"]').value = String(AUS.rate);
      var RL = { off: 'Repeat', ch: 'Repeat chapter', vs: 'Repeat ' + AU.book + ' ' + REP.rc + ':' + REP.a + (REP.b > REP.a ? '–' + REP.b : ''), book: 'Repeat ' + AU.book, chs: 'Repeat chapters ' + REP.ca + '–' + REP.cb, books: 'Playing ' + REP.books.length + ' book' + (REP.books.length === 1 ? '' : 's') };
      b.querySelector('[data-abf="repl"]').textContent = RL[REP.mode] + (REP.mode !== 'off' && REP.times ? ' ×' + REP.times : ''); b.querySelector('[data-ab="repm"]').classList.toggle('on', REP.mode !== 'off');
      var fb = b.querySelector('[data-ab="follow"]'); fb.setAttribute('aria-pressed', String(!!AUS.follow)); fb.classList.toggle('on', !!AUS.follow); b.querySelector('[data-abf="fl"]').textContent = 'Auto-scroll: ' + (AUS.follow ? 'On' : 'Off');
      var mb = b.querySelector('[data-ab="music"]'); mb.setAttribute('aria-pressed', String(!!AUS.music)); mb.classList.toggle('on', !!AUS.music); b.querySelector('[data-ab="mv"]').value = Math.round(AUS.mv * 100); b.querySelector('[data-ab="mv"]').disabled = !AUS.music;
      if (full) b.querySelector('[data-abf="dl"]').innerHTML = '<p>Save chapters to your device as MP3 files (1–4 MB each). The background music is added live in the app and is not in the files.</p><div class="abdlg">' + B.ch.map(function (x, i) { return '<a href="' + x.f + '" download="' + B.title + ' ' + (i + 1) + '.mp3"' + (i + 1 === AU.c ? ' class="cur"' : '') + '>' + SVGI.dl + ' ' + B.title + ' ' + (i + 1) + ' <small>' + fmt(x.d) + '</small></a>'; }).join('') + '</div>';
      if ('mediaSession' in navigator) { try { navigator.mediaSession.metadata = new MediaMetadata({ title: B.title + ' ' + AU.c, artist: 'Audio Bible (KJV)', album: B.title }); } catch (e) {} }
    };
    var repSet = function (m) {
      REP.mode = m; REP.done = 0;
      if (m === 'vs' && REP.rc !== AU.c) { REP.rc = AU.c; var cv = aVerseAt(AU.el.currentTime || 0) + 1; REP.a = REP.b = cv; }
      if (m === 'chs' && (REP.ca > aBook().ch.length || REP.cb < REP.ca)) { REP.ca = AU.c; REP.cb = AU.c; }
      if (m === 'books' && !REP.books.length) REP.books = [AU.book];
      repPanel(); abUpdate(true);
    };
    var repFromSel = function () {
      if (typeof sel === 'undefined' || !sel.length) return null; var vs = [];
      sel.forEach(function (x) { var m = /\|(.+) (\d+):(\d+)$/.exec(x[0]); if (m && m[1] === AU.book) vs.push([+m[2], +m[3]]); });
      if (!vs.length) return null; var c = vs[0][0]; vs = vs.filter(function (x) { return x[0] === c; }).map(function (x) { return x[1]; });
      return { c: c, a: Math.min.apply(null, vs), b: Math.max.apply(null, vs) };
    };
    var repPanel = function () {
      var b = AU.bar, B = aBook(), C = aCh(); if (!b || !B || !C) return; var box = b.querySelector('[data-abf="rep"]'); if (!box || box.hidden) return;
      var opt = function (n, v) { var h = ''; for (var i = 1; i <= n; i++) h += '<option value="' + i + '"' + (i === v ? ' selected' : '') + '>' + i + '</option>'; return h; };
      var M = function (v, l) { return '<button data-ab="rmode" data-v="' + v + '" class="' + (REP.mode === v ? 'on' : '') + '">' + l + '</button>'; };
      var sr = repFromSel(), vc = REP.rc === AU.c ? REP : { a: aVerseAt(AU.el.currentTime || 0) + 1, b: aVerseAt(AU.el.currentTime || 0) + 1 };
      var all = (typeof BOOKS !== 'undefined' ? BOOKS : Object.keys(AUDM)).filter(function (x) { return AUDM[x]; });
      box.innerHTML = '<div class="rpmodes">' + M('off', 'Off') + M('vs', 'Verses') + M('ch', 'This chapter') + M('chs', 'Chapters') + M('book', 'Whole book') + M('books', 'Books') + '</div>' +
        (REP.mode === 'vs' ? '<div class="rprow">' + esc(AU.book) + ' ' + AU.c + ': verse <select data-ab="ra">' + opt(C.v.length, vc.a) + '</select> to <select data-ab="rb">' + opt(C.v.length, vc.b) + '</select></div>' + (sr ? '<button class="rpsel" data-ab="rsel">Use the verses I selected (' + esc(AU.book + ' ' + sr.c + ':' + sr.a + (sr.b > sr.a ? '–' + sr.b : '')) + ')</button>' : '<p class="rpnote">Tip: select verses in the text, then come back here to repeat exactly those.</p>') : '') +
        (REP.mode === 'chs' ? '<div class="rprow">' + esc(AU.book) + ' chapter <select data-ab="rca">' + opt(B.ch.length, REP.ca) + '</select> to <select data-ab="rcb">' + opt(B.ch.length, REP.cb) + '</select></div>' : '') +
        (REP.mode === 'books' ? '<div class="rprow rpbooks">' + all.map(function (x) { return '<label><input type="checkbox" data-ab="rbook" value="' + esc(x) + '"' + (REP.books.indexOf(x) >= 0 ? ' checked' : '') + '> ' + esc(x) + '</label>'; }).join('') + '</div><p class="rpnote">Books play in Bible order, then start again. Only books with audio are listed; more appear here as their recordings are added.</p>' : '') +
        (REP.mode !== 'off' ? '<div class="rprow">Times: ' + [[1, '1'], [2, '2'], [3, '3'], [5, '5'], [10, '10'], [0, 'Until I stop']].map(function (x) { return '<button data-ab="rtimes" data-v="' + x[0] + '" class="' + (REP.times === x[0] ? 'on' : '') + '">' + x[1] + '</button>'; }).join('') + (REP.times ? ' <small>' + REP.done + ' done</small>' : '') + '</div>' : '');
    };
    var aOpen = function (book, chap, verse) {
      var b = abBuild(); if (AU.book !== book) { AU.book = book; AU.el.removeAttribute('src'); }
      if (!document.body.contains(b)) document.body.appendChild(b); document.body.classList.add('abopen'); AU.open = true; AU.userScroll = 0; AU.followC = chap || 1;
      var C = AUDM[book].ch[(chap || 1) - 1], t = verse && C ? (C.v[verse - 1] || 0) : 0; aLoad(chap || 1, t, true);
    };
    if ('mediaSession' in navigator) { try { navigator.mediaSession.setActionHandler('play', aPlay); navigator.mediaSession.setActionHandler('pause', aPause); navigator.mediaSession.setActionHandler('previoustrack', function () { if (AU.c > 1) aLoad(AU.c - 1, 0, true); }); navigator.mediaSession.setActionHandler('nexttrack', function () { var B = aBook(); if (B && AU.c < B.ch.length) aLoad(AU.c + 1, 0, true); }); } catch (e) {} }
    // tap a verse number while listening to jump the recording there
    document.addEventListener('click', function (e) {
      var vn = e.target.closest && e.target.closest('.vs .vn'); if (!vn || !AU.open || !AU.book) return;
      var vs = vn.closest('.vs'), m = /\|(.+) (\d+):(\d+)$/.exec(vs.dataset.vk || ''); if (!m || m[1] !== AU.book) return;
      var C = AUDM[AU.book].ch[+m[2] - 1]; if (!C) return; if (+m[2] !== AU.c) aLoad(+m[2], C.v[+m[3] - 1] || 0, !AU.el.paused); else { AU.el.currentTime = C.v[+m[3] - 1] || 0; aSync(true); }
    }, true);
    /* ---- read aloud with the device's voice, for books without a recording ---- */
    var TTS = { on: false };
    var ttsStop = function () { try { speechSynthesis.cancel(); } catch (e) {} TTS.on = false; };
    var ttsRead = function (book, c) {
      if (!('speechSynthesis' in window)) { toast('Read-aloud is not available on this device'); return; }
      if (TTS.on) { ttsStop(); render(); return; }
      var vs = (KJV[book] || {})[c] || []; TTS.on = true; speechSynthesis.cancel();
      vs.forEach(function (v, i) { var u = new SpeechSynthesisUtterance(plain(v)); u.rate = 0.92; if (i === vs.length - 1) u.onend = function () { TTS.on = false; render(); }; speechSynthesis.speak(u); });
      render();
    };

    /* ---- no recording yet: apologise and offer a verse card ---- */
    var vcOpen = function (again) {
      var vs = (KJV[cur.b] || {})[cur.c] || []; if (!vs.length) return;
      var idx = vs.map(function (v, i) { return [i, plain(v).trim()]; }).filter(function (x) { return x[1].length >= 50 && x[1].length <= 260; }); if (!idx.length) idx = vs.map(function (v, i) { return [i, plain(v).trim()]; });
      var prev = window.__vcLast, pick; do { pick = idx[Math.floor(Math.random() * idx.length)]; } while (idx.length > 1 && prev && pick[0] === prev);
      window.__vcLast = pick[0];
      var old = document.getElementById('vcard'); if (old) old.remove();
      var o = document.createElement('div'); o.id = 'vcard'; o.className = 'vcwrap'; o.setAttribute('role', 'dialog'); o.setAttribute('aria-modal', 'true'); o.setAttribute('aria-label', 'Verse card');
      o.innerHTML = '<div class="vcbox"><p class="vcsorry">' + (again ? 'Here is another verse from ' + esc(cur.b) + ' ' + cur.c + '.' : 'Sorry, audio for ' + esc(cur.b) + ' hasn\'t been added yet. Here is a verse to read in the meantime.') + '</p>' +
        '<figure class="vcc"><span class="vcq" aria-hidden="true">“</span><blockquote>' + esc(pick[1]) + '</blockquote><figcaption>' + esc(cur.b) + ' ' + cur.c + ':' + (pick[0] + 1) + ' <small>KJV</small></figcaption></figure>' +
        '<div class="vcbtns"><button data-act="vcnext">Another verse</button><button class="pri" data-act="vcx">Close</button></div></div>';
      o.addEventListener('click', function (e) { if (e.target === o) o.remove(); });
      document.body.appendChild(o); var f = o.querySelector('.pri'); if (f) f.focus();
    };
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') { var o = document.getElementById('vcard'); if (o) o.remove(); } });
    var readAU = readHtml;
    readHtml = function () {
      var h = readAU(); if (!cur || !KJV[cur.b]) return h;
      var btn = AUDM[cur.b] ? '<button class="alisten" data-act="aplay" data-c="' + cur.c + '">' + SVGI.play + ' Listen to ' + esc(cur.b) + ' ' + cur.c + '</button>' :
        '<button class="anoaud" data-act="anoaud">' + SVGI.music + ' Audio not added yet</button>';
      if (h.indexOf('</header>') > 0 && h.indexOf('class="chead"') > 0) return h.replace('</header>', btn + '</header>');
      return h;
    };
    var actAU = act;
    act = function (a, d) {
      d = d || {};
      if (a === 'aplay') { ttsStop(); aOpen(cur.b, +d.c || cur.c); return; }
      if (a === 'anoaud' || a === 'vcnext') { vcOpen(a === 'vcnext'); return; }
      if (a === 'vcx') { var o = document.getElementById('vcard'); if (o) o.remove(); return; }
      if ((a === 'nc' || a === 'pc' || a === 'go') && TTS.on) ttsStop();
      return actAU(a, d);
    };
    var renderAU = render;
    render = function () { renderAU(); if (AU.open && AU.bar && !document.body.contains(AU.bar)) document.body.appendChild(AU.bar); AU.vi = -1; if (AU.open) aSync(true); };
    window.__audio = { AU: AU, AUDM: AUDM, open: aOpen, verseAt: aVerseAt, MU: MU };
  } catch (e) { console.warn('audio', e); }

  // ===== 26. Display mode: show the tablet or desktop layout on a phone, scaled to fit =====
  try {
    var DMW = { tablet: 1024, desktop: 1280 };
    var DMN = { auto: 'Auto', tablet: 'Tablet', desktop: 'Desktop' };
    var dmd = function (o, k) { return Object.getOwnPropertyDescriptor(o, k) || Object.getOwnPropertyDescriptor(Window.prototype, k); };
    var iwD = dmd(window, 'innerWidth'), ihD = dmd(window, 'innerHeight');
    var realW = function () { return iwD && iwD.get ? iwD.get.call(window) : document.documentElement.clientWidth; };
    var realH = function () { return ihD && ihD.get ? ihD.get.call(window) : document.documentElement.clientHeight; };
    var DM = { mode: (function () { try { return localStorage.getItem('dispmode') || 'auto'; } catch (e) { return 'auto'; } })(), z: 1, vw: null, rules: null };
    if (!DMN[DM.mode]) DM.mode = 'auto';
    try {
      Object.defineProperty(window, 'innerWidth', { configurable: true, get: function () { return DM.vw || realW(); } });
      Object.defineProperty(window, 'innerHeight', { configurable: true, get: function () { return DM.z < 1 ? Math.round(realH() / DM.z) : realH(); } });
    } catch (e) {}
    // gather the width-based media rules once, and make vh heights follow the scale
    var dmCollect = function () {
      var out = [];
      var walk = function (list) { for (var i = 0; i < list.length; i++) { var r = list[i];
        if (r.type === 4) { if (r.__dmo == null) r.__dmo = r.media.mediaText; if (/width/.test(r.__dmo)) out.push(r); walk(r.cssRules); }
        else if (r.type === 1 && r.style && !r.__dmvh) { r.__dmvh = 1; for (var j = 0; j < r.style.length; j++) { var p = r.style[j], v = r.style.getPropertyValue(p); if (/\d(?:\.\d+)?d?vh/.test(v)) r.style.setProperty(p, v.replace(/(\d+(?:\.\d+)?)(d?vh)/g, 'calc($1$2 / var(--dz, 1))'), r.style.getPropertyPriority(p)); } }
      } };
      for (var i = 0; i < document.styleSheets.length; i++) { try { walk(document.styleSheets[i].cssRules); } catch (e) {} }
      return out;
    };
    var dmEval = function (text, w) { // true/false for a media query list at virtual width w
      return text.split(',').some(function (q) {
        var ok = true; q.replace(/\(\s*(min|max)-width\s*:\s*(\d+(?:\.\d+)?)px\s*\)/g, function (_, mm, n) { n = +n; if (mm === 'max' ? w > n : w < n) ok = false; return ''; });
        var rest = q.replace(/\(\s*(min|max)-width\s*:[^)]*\)/g, '').replace(/\band\b/g, ' ').trim();
        if (ok && rest && rest !== 'screen' && rest !== 'all') { try { ok = matchMedia(rest.replace(/^only\s+/, '')).matches; } catch (e) {} }
        return ok;
      });
    };
    var dmApply = function (rerender) {
      var rw = realW(), tw = DMW[DM.mode], html = document.documentElement;
      if (!DM.rules) DM.rules = dmCollect();
      if (DM.mode !== 'auto' && tw && tw > rw + 1) { DM.vw = tw; DM.z = rw / tw; } else { DM.vw = null; DM.z = 1; }
      html.style.zoom = DM.z < 1 ? String(DM.z) : ''; html.style.setProperty('--dz', String(DM.z)); html.classList.toggle('dmz', DM.z < 1);
      DM.rules.forEach(function (r) { var want = DM.vw ? (dmEval(r.__dmo, DM.vw) ? 'all' : 'not all') : r.__dmo; if (r.media.mediaText !== want) r.media.mediaText = want; });
      if (rerender) render();
    };
    var dmSet = function (m) { DM.mode = m; try { localStorage.setItem('dispmode', m); } catch (e) {} dmApply(true); toast(m === 'auto' ? 'Display fits this screen' : DMN[m] + ' layout' + (DM.z < 1 ? ', scaled to fit. Turn your phone sideways for larger text.' : '. Your screen already shows this layout.')); };
    var dmT; var onResize = function () { clearTimeout(dmT); dmT = setTimeout(function () { if (DM.mode !== 'auto') dmApply(true); }, 150); };
    window.addEventListener('resize', onResize); window.addEventListener('orientationchange', onResize);
    var dmSeg = function (cls) { return '<div class="dmseg ' + (cls || '') + '" role="group" aria-label="Display layout">' + Object.keys(DMN).map(function (k) { return '<button data-act="dmode" data-m="' + k + '" class="' + (DM.mode === k ? 'on' : '') + '" aria-pressed="' + (DM.mode === k) + '">' + DMN[k] + '</button>'; }).join('') + '</div>'; };
    var actDM = act;
    act = function (a, d) { if (a === 'dmode') { dmSet((d && d.m) || 'auto'); return; } return actDM(a, d); };
    var sideDM = sideHtml;
    sideHtml = function () { var h = sideDM(); var row = '<div class="dmside"><h5 class="lb">Layout</h5>' + dmSeg('sm') + '</div>'; var i = h.indexOf('<nav class="obnavs"'); if (i < 0) return h; var j = h.indexOf('</nav>', i); return h.slice(0, j + 6) + row + h.slice(j + 6); };
    var renderDM = render;
    render = function () {
      renderDM();
      var aa = document.getElementById('aa'); if (aa && !aa.querySelector('.dmrow')) { var mwb = aa.querySelector('[data-act="mw"]'), blk = mwb && mwb.closest('div') && mwb.closest('div').parentElement; var html = '<div class="dmrow"><h6>Layout</h6>' + dmSeg() + '<small>Tablet and Desktop show the bigger layouts on a phone, scaled to fit.</small></div>'; if (blk) blk.insertAdjacentHTML('afterend', html); else aa.insertAdjacentHTML('beforeend', html); }
    };
    dmApply(DM.mode !== 'auto');
    window.__dm = DM;
  } catch (e) { console.warn('display mode', e); }

  // ===== 27. Book introductions and chapter summaries =====
  try {
    var SUM = { v: (function () { try { var m = /[?&]v=(\d+)/.exec((document.currentScript && document.currentScript.src) || ''); return m ? m[1] : String(Date.now()); } catch (e) { return '1'; } })(), data: null, loading: false, off: (function () { try { return localStorage.getItem('sumoff') === '1'; } catch (e) { return false; } })() };
    var sumLoad = function () {
      if (SUM.data || SUM.loading) return; SUM.loading = true;
      fetch('summaries.json?v=' + SUM.v).then(function (r) { return r.json(); }).then(function (d) { SUM.data = d; if (view === 'read') render(); }).catch(function () { SUM.loading = false; });
    };
    var sumHtml = function () {
      if (!cur || !KJV[cur.b]) return '';
      if (!SUM.data) { sumLoad(); return ''; }
      var I = SUM.data.intro[cur.b], C = (SUM.data.ch[cur.b] || [])[cur.c - 1], first = +cur.c === 1;
      if (!C && !(first && I)) return '';
      if (SUM.off) return '<div class="sumbar off"><button data-act="sumtog">' + ic('book', 14) + ' Show the ' + (first && I ? 'book introduction and ' : '') + 'chapter summary</button></div>';
      var h = '<section class="sumbox" aria-label="Summary">';
      if (first && I) {
        var m = /(.+) (\d+):(\d+)$/.exec(I.k || ''), kv = m && KJV[m[1]] && KJV[m[1]][m[2]] ? KJV[m[1]][m[2]][+m[3] - 1] : '';
        h += '<div class="sumintro"><h3>About the book of ' + esc(cur.b) + '</h3><dl><div><dt>Written by</dt><dd>' + esc(I.a) + '</dd></div><div><dt>When</dt><dd>' + esc(I.d) + '</dd></div></dl><p>' + esc(I.s) + '</p>' +
          (kv ? '<blockquote class="sumkey"><span>Key verse</span>' + esc(plain(kv).trim()) + ' <cite>' + esc(I.k) + '</cite></blockquote>' : '') + '</div>';
      }
      if (C) h += '<div class="sumch"><h4>In this chapter</h4><p>' + esc(C) + '</p></div>';
      h += '<div class="sumfoot"><small>A summary to guide you; read the chapter for the full text.</small><button data-act="sumtog">Hide summaries</button></div></section>';
      return h;
    };
    var readSUM = readHtml;
    readHtml = function () { var h = readSUM(), x = sumHtml(); if (!x) return h; var i = h.indexOf('</header>'); return i > 0 ? h.slice(0, i + 9) + x + h.slice(i + 9) : h; };
    var actSUM = act;
    act = function (a, d) { if (a === 'sumtog') { SUM.off = !SUM.off; try { localStorage.setItem('sumoff', SUM.off ? '1' : '0'); } catch (e) {} render(); return; } return actSUM(a, d); };
    window.__sum = SUM;
  } catch (e) { console.warn('summaries', e); }

  // ===== 28. What I learned: personal reflections at the end of each chapter =====
  try {
    SYNC_KEYS.push('refl'); if (typeof GUARD !== 'undefined') GUARD.push('refl');
    var RF = { draft: {}, kv: {}, cf: null };
    var rfAll = function () { return store.g('refl', null) || {}; };
    var rfKey = function () { return cur.b + ' ' + cur.c; };
    var rfDate = function (t) { try { return new Date(t).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' }); } catch (e) { return ''; } };
    var rfVerse = function (book, c, v) { var x = KJV[book] && KJV[book][c] && KJV[book][c][v - 1]; return x ? plain(x).trim() : ''; };
    var rfCard = function (book, c, e, showRef) {
      var vt = e.v ? rfVerse(book, c, e.v) : '';
      return '<article class="rfcard"><header><span>' + (showRef ? '<b>' + esc(book + ' ' + c) + '</b> · ' : '') + esc(rfDate(e.at)) + '</span><button class="rfdel' + (RF.cf === e.id ? ' warn' : '') + '" data-act="rfdel" data-k="' + esc(book + ' ' + c) + '" data-id="' + e.id + '">' + (RF.cf === e.id ? 'Tap again to delete' : ic('trash', 14)) + '</button></header>' +
        (e.t ? '<p>' + esc(e.t).replace(/\n/g, '<br>') + '</p>' : '') +
        (vt ? '<blockquote>' + esc(vt) + ' <cite>' + esc(book + ' ' + c + ':' + e.v) + '</cite></blockquote>' : '') + '</article>';
    };
    var rfHtml = function () {
      if (!cur || !KJV[cur.b] || !KJV[cur.b][cur.c]) return '';
      var k = rfKey(), list = (rfAll()[k] || []).slice().sort(function (a, b) { return b.at - a.at; }), n = KJV[cur.b][cur.c].length, all = rfAll(), tot = 0;
      for (var q in all) tot += (all[q] || []).length;
      var kv = RF.kv[k] || '', kvt = kv ? rfVerse(cur.b, cur.c, +kv) : '';
      return '<section class="rfbox" aria-label="What I learned"><h3>What I learned from ' + esc(cur.b) + ' ' + cur.c + '</h3>' +
        '<p class="rfhint">Write a conclusion in your own words, and pick a key verse to keep. Each note is saved under this chapter and they build up as you read.</p>' +
        '<textarea id="rftext" rows="3" placeholder="What did God show you in this chapter?">' + esc(RF.draft[k] || '') + '</textarea>' +
        '<div class="rfrow"><label>Key verse <select id="rfkv"><option value="">None</option>' + Array.apply(null, Array(n)).map(function (_, i) { var t = rfVerse(cur.b, cur.c, i + 1); return '<option value="' + (i + 1) + '"' + (String(i + 1) === kv ? ' selected' : '') + '>' + (i + 1) + ': ' + esc(t.slice(0, 46)) + (t.length > 46 ? '…' : '') + '</option>'; }).join('') + '</select></label><button class="pri" data-act="rfsave">Save what I learned</button></div>' +
        (kvt ? '<blockquote class="rfpre">' + esc(kvt) + ' <cite>' + esc(cur.b + ' ' + cur.c + ':' + kv) + '</cite></blockquote>' : '') +
        (list.length ? '<div class="rflist">' + list.map(function (e) { return rfCard(cur.b, cur.c, e, false); }).join('') + '</div>' : '') +
        (tot ? '<button class="rfall" data-act="rfall">' + ic('book', 14) + ' All my reflections (' + tot + ')</button>' : '') + '</section>';
    };
    var rfPage = function () {
      var all = rfAll(), keys = Object.keys(all).filter(function (k) { return (all[k] || []).length; }), items = [];
      keys.forEach(function (k) { var m = /^(.+) (\d+)$/.exec(k); if (m) all[k].forEach(function (e) { items.push({ b: m[1], c: +m[2], e: e }); }); });
      items.sort(function (a, b) { return b.e.at - a.e.at; });
      return '<div class="home rfpage"><div class="greet"><button class="ib mobm" data-act="side" aria-label="Menu">' + ic('menu') + '</button><h1>What I learned</h1></div>' +
        '<p class="dim">' + (items.length ? items.length + ' reflection' + (items.length > 1 ? 's' : '') + ' across ' + keys.length + ' chapter' + (keys.length > 1 ? 's' : '') + ', newest first.' : 'Nothing yet. At the end of any chapter, write what you learned and it will appear here.') + '</p>' +
        '<div class="rflist">' + items.map(function (x) { return '<div class="rfwrap">' + rfCard(x.b, x.c, x.e, true) + '<button class="rfopen" data-act="rfopen" data-b="' + esc(x.b) + '" data-c="' + x.c + '">Open ' + esc(x.b + ' ' + x.c) + '</button></div>'; }).join('') + '</div></div>';
    };
    document.addEventListener('input', function (e) { if (e.target && e.target.id === 'rftext' && cur) RF.draft[rfKey()] = e.target.value; });
    document.addEventListener('change', function (e) { if (e.target && e.target.id === 'rfkv' && cur) { RF.kv[rfKey()] = e.target.value; render(); } });
    var readRF = readHtml;
    readHtml = function () { var h = readRF(), x = rfHtml(); if (!x) return h; var i = h.lastIndexOf('<div class="nav">'); return i > 0 ? h.slice(0, i) + x + h.slice(i) : h + x; };
    var actRF = act;
    act = function (a, d) {
      d = d || {};
      if (a === 'rfsave') {
        var k = rfKey(), t = (RF.draft[k] || '').trim(), v = +(RF.kv[k] || 0);
        if (!t && !v) { toast('Write what you learned or choose a key verse first'); return; }
        var all = rfAll(); all[k] = all[k] || []; all[k].push({ id: Date.now().toString(36) + Math.random().toString(36).slice(2, 6), t: t.slice(0, 3000), v: v || 0, at: Date.now() });
        var before = JSON.stringify(store.g('refl', null) || {}); store.s('refl', all);
        if (JSON.stringify(store.g('refl', null) || {}) === before) return; // saving was blocked (needs an account)
        RF.draft[k] = ''; RF.kv[k] = ''; toast('Saved to what you learned from ' + k); render(); return;
      }
      if (a === 'rfdel') { if (RF.cf !== d.id) { RF.cf = d.id; render(); return; } var all2 = rfAll(); all2[d.k] = (all2[d.k] || []).filter(function (e) { return e.id !== d.id; }); if (!all2[d.k].length) delete all2[d.k]; RF.cf = null; store.s('refl', all2); render(); return; }
      if (a === 'rfall') { view = 'reflall'; if (innerWidth <= 800) side = false; render(); var mm = $('#main'); if (mm) mm.scrollTop = 0; return; }
      if (a === 'rfopen') { view = 'read'; go({ b: d.b, c: +d.c, v: 1 }, true); setTimeout(function () { var bx = document.querySelector('.rfbox'); if (bx) bx.scrollIntoView({ block: 'start' }); }, 300); return; }
      return actRF(a, d);
    };
    var renderRF = render;
    render = function () { renderRF(); if (view === 'reflall') { $('#main').innerHTML = rfPage(); var dr = $('#drawer'); if (dr) dr.classList.remove('open'); var tb = $('#tb'); if (tb) tb.style.display = 'none'; } };
    var sideRF = sideHtml;
    sideHtml = function () { var h = sideRF(), all = rfAll(), n = 0; for (var q in all) n += (all[q] || []).length; var btn = '<button data-act="rfall" class="' + (view === 'reflall' ? 'on' : '') + '" title="What I learned">' + ic('pen') + '<span class="lb">What I learned' + (n ? ' <small class="rfn">' + n + '</small>' : '') + '</span></button>'; return h.replace('<span class="lb">Other Books</span></button>', '<span class="lb">Other Books</span></button>' + btn); };
  } catch (e) { console.warn('reflections', e); }

  // ===== 29. Keep the reading pane on the same chapter as the heading =====
  // The reading position syncs between devices, but each pane keeps its own position; with one pane they must always match.
  try {
    var readPS = readHtml;
    readHtml = function () {
      try {
        if (cur && KJV[cur.b] && LAY.length === 1 && PS[0] && (PS[0].b !== cur.b || +PS[0].c !== +cur.c)) { PS[0].b = cur.b; PS[0].c = +cur.c; PS[0].v = +cur.v || 1; store.s('ps', PS); }
      } catch (e) {}
      return readPS();
    };
  } catch (e) { console.warn('pane sync', e); }

  // ===== 30. Verse card studio: the verse of the day as a designed card, saved as an image =====
  try {
    var VC = { bg: null, font: 0, shape: 'sq', marks: {}, ref: null, text: '', open: false, url: null };
    var VCB = [
      ['auto', 'For this verse'], ['glory', 'Glory'], ['creation', 'Creation'], ['shepherd', 'Shepherd'], ['cross', 'The cross'], ['redsea', 'Red Sea'], ['eden', 'Garden'], ['throne', 'Throne'], ['crown', 'Crown'], ['burningbush', 'Burning bush'], ['tomb', 'Empty tomb'], ['pentecost', 'Pentecost'],
      ['midnight', 'Midnight'], ['parchment', 'Parchment'], ['olive', 'Olive'], ['royal', 'Royal'], ['sunrise', 'Sunrise'], ['ocean', 'Ocean']
    ];
    var VCS = { // colour styles: background stops, text, accent 1 (God's names), accent 2 (key words), frame
      midnight: [['#0B1430', '#1D2B5C'], '#F6F1E4', '#F2C15B', '#7FD8C9', '#C9A24A'],
      parchment: [['#F6ECD6', '#E3CFA4'], '#2C2014', '#9A5A12', '#2F6F64', '#8A6A2E'],
      olive: [['#1F3A2A', '#3E6346'], '#F4F1E6', '#F2D27A', '#BFE3A5', '#D9BC84'],
      royal: [['#2A1240', '#5A2A78'], '#FBF4FF', '#F5C75B', '#FF9CC0', '#D9B25A'],
      sunrise: [['#F7B267', '#E8608A'], '#FFFFFF', '#FFF3B0', '#3B1F4A', '#FFF1D6'],
      ocean: [['#06324A', '#0E7490'], '#F0FBFF', '#FFD27A', '#9BE7FF', '#BFE9F7'],
      scene: [null, '#FFFFFF', '#FFD66B', '#9EF0E0', '#F3DDA4']
    };
    var VCF = [['Cormorant Garamond', '700', 'Elegant'], ['Libre Caslon Display', '400', 'Classic'], ['EB Garamond', 'italic 400', 'Book'], ['Lora', '700', 'Warm'], ['Merriweather', '700', 'Bold'], ['Fredoka', '600', 'Friendly'], ['Inter', '600', 'Modern']];
    var DIV = /^(LORD|GOD|God|Lord|Jesus|Christ|JESUS|Spirit|Ghost|Father|Almighty|Saviour|Redeemer|Lamb)$/;
    var STOP = 'the,and,of,to,in,that,for,unto,shall,with,thee,thou,thy,them,they,their,him,his,her,not,but,all,are,was,were,will,have,hath,from,this,which,when,what,then,than,there,these,those,upon,into,also,even,shalt,said,saith,your,you,our,ye,are,be,is,it,as,at,by,on,or,an,a,i,me,my,we,us,he,she,so,if,no,do,did,let,may,might,would,could,should,every,any,one'.split(',');
    var vcWords = function (t) { return t.split(/\s+/).filter(Boolean); };
    var vcAuto = function (words) { // God's names in accent 1; the two longest key words in accent 2
      var m = {}, cand = [];
      words.forEach(function (w, i) { var c = w.replace(/[^A-Za-z']/g, ''); if (DIV.test(c)) m[i] = 1; else if (c.length >= 5 && STOP.indexOf(c.toLowerCase()) < 0) cand.push([i, c.length]); });
      cand.sort(function (a, b) { return b[1] - a[1]; }).slice(0, 2).forEach(function (x) { m[x[0]] = 2; });
      return m;
    };
    var vcBgId = function () { return VC.bg === 'auto' || !VC.bg ? (window.KGScenes ? KGScenes.forText(VC.text) : 'midnight') : VC.bg; };
    var vcStyle = function () { var id = vcBgId(); return VCS[id] ? VCS[id] : VCS.scene; };
    var vcImg = function (id, W, H) {
      return new Promise(function (res) {
        if (!window.KGScenes || VCS[id]) return res(null);
        var sv = KGScenes.svg(id).replace('<svg ', '<svg xmlns="http://www.w3.org/2000/svg" width="' + W + '" height="' + H + '" ');
        var im = new Image(); im.onload = function () { res(im); }; im.onerror = function () { res(null); }; im.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(sv);
      });
    };
    var vcFontStr = function (f, px) { var F = VCF[f]; return F[1] + ' ' + px + 'px "' + F[0] + '", Georgia, serif'; };
    var vcLayout = function (ctx, words, f, px, maxW) {
      ctx.font = vcFontStr(f, px); var sp = ctx.measureText(' ').width, lines = [], line = [], w = 0;
      words.forEach(function (wd, i) { var ww = ctx.measureText(wd).width; if (line.length && w + sp + ww > maxW) { lines.push({ ws: line, w: w }); line = []; w = 0; } w += (line.length ? sp : 0) + ww; line.push([i, wd, ww]); });
      if (line.length) lines.push({ ws: line, w: w }); return { lines: lines, sp: sp };
    };
    var vcDraw = function (cv) {
      var W = 1080, H = VC.shape === 'st' ? 1920 : 1080; cv.width = W; cv.height = H;
      var ctx = cv.getContext('2d'), st = vcStyle(), id = vcBgId(), F = VCF[VC.font];
      return Promise.all([vcImg(id, W, H), document.fonts ? document.fonts.load(vcFontStr(VC.font, 60)).catch(function () {}) : null, document.fonts ? document.fonts.load('600 30px "Inter"').catch(function () {}) : null]).then(function (r) {
        var im = r[0];
        if (im) { ctx.drawImage(im, 0, 0, W, H); var g = ctx.createLinearGradient(0, 0, 0, H); g.addColorStop(0, 'rgba(8,10,20,.35)'); g.addColorStop(.45, 'rgba(8,10,20,.62)'); g.addColorStop(1, 'rgba(8,10,20,.78)'); ctx.fillStyle = g; ctx.fillRect(0, 0, W, H); }
        else { var g2 = ctx.createLinearGradient(0, 0, W, H); g2.addColorStop(0, st[0][0]); g2.addColorStop(1, st[0][1]); ctx.fillStyle = g2; ctx.fillRect(0, 0, W, H);
          var rg = ctx.createRadialGradient(W * .8, H * .15, 10, W * .8, H * .15, W * .7); rg.addColorStop(0, 'rgba(255,255,255,.18)'); rg.addColorStop(1, 'rgba(255,255,255,0)'); ctx.fillStyle = rg; ctx.fillRect(0, 0, W, H); }
        // card frame, like the Kingdom cards
        ctx.strokeStyle = st[4]; ctx.globalAlpha = .9; ctx.lineWidth = 3; ctx.strokeRect(44, 44, W - 88, H - 88); ctx.globalAlpha = .45; ctx.lineWidth = 1.5; ctx.strokeRect(58, 58, W - 116, H - 116); ctx.globalAlpha = 1;
        ctx.fillStyle = st[4]; [[44, 44], [W - 44, 44], [44, H - 44], [W - 44, H - 44]].forEach(function (p) { ctx.save(); ctx.translate(p[0], p[1]); ctx.rotate(Math.PI / 4); ctx.fillRect(-9, -9, 18, 18); ctx.restore(); });
        // big quotation mark
        ctx.fillStyle = st[3]; ctx.globalAlpha = .22; ctx.font = '700 260px "Cormorant Garamond", Georgia, serif'; ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic'; ctx.fillText('“', 96, 300); ctx.globalAlpha = 1;
        // the verse, sized to fit
        var words = vcWords(VC.text), maxW = W - 220, top = VC.shape === 'st' ? 360 : 190, bottom = H - (VC.shape === 'st' ? 420 : 250), px = VC.shape === 'st' ? 92 : 78, L;
        for (; px >= 30; px -= 2) { L = vcLayout(ctx, words, VC.font, px, maxW); if (L.lines.length * px * 1.32 <= bottom - top) break; }
        var lh = px * 1.32, y0 = top + ((bottom - top) - L.lines.length * lh) / 2 + px;
        ctx.textBaseline = 'alphabetic'; ctx.shadowColor = im ? 'rgba(0,0,0,.45)' : 'transparent'; ctx.shadowBlur = im ? 14 : 0;
        L.lines.forEach(function (ln, k) {
          var x = (W - ln.w) / 2, y = y0 + k * lh;
          ln.ws.forEach(function (o) { var mk = VC.marks[o[0]] || 0; ctx.fillStyle = mk === 1 ? st[2] : mk === 2 ? st[3] : st[1]; ctx.fillText(o[1], x, y);
            if (mk === 2) { ctx.fillRect(x, y + px * .14, o[2], Math.max(2, px * .045)); } o.x = x; o.y = y; x += o[2] + L.sp; });
        });
        VC.hit = { lines: L.lines, px: px, W: W, H: H };
        ctx.shadowBlur = 0;
        // reference and signature
        ctx.textAlign = 'center'; ctx.fillStyle = st[4]; ctx.font = '600 ' + (VC.shape === 'st' ? 40 : 34) + 'px "Inter", system-ui, sans-serif';
        var refY = bottom + (VC.shape === 'st' ? 110 : 80); var rs = VC.ref.toUpperCase().split('').join(' ');
        ctx.fillText(rs + '  ·  KJV', W / 2, refY);
        ctx.fillRect(W / 2 - 60, refY - (VC.shape === 'st' ? 78 : 64), 120, 3);
        ctx.globalAlpha = .75; ctx.fillStyle = st[1]; ctx.font = 'italic 400 26px "Libre Caslon Text", Georgia, serif'; ctx.fillText('Scripture · Attend, affirm, matter', W / 2, H - 84); ctx.globalAlpha = 1;
      });
    };
    var vcSet = function (dv) { if (!dv) return false; if (VC.ref !== dv.ref) { VC.ref = dv.ref; VC.text = String(dv.t).replace(/([?!;:,.])(?=[A-Za-z])/g, '$1 ').replace(/\s+/g, ' ').trim(); VC.marks = vcAuto(vcWords(dv.t)); VC.bg = VC.bg || 'auto'; } return true; };
    var vcRender = function () { var cvs = document.querySelectorAll('canvas.vccv'); cvs.forEach(function (cv) { vcDraw(cv); }); };
    var vcBlob = function () { return new Promise(function (res) { var cv = document.createElement('canvas'); vcDraw(cv).then(function () { cv.toBlob(function (b) { res(b); }, 'image/png'); }); }); };
    var vcName = function () { return (VC.ref || 'verse').replace(/[^A-Za-z0-9]+/g, '-') + '.png'; };
    var vcStudio = function () {
      var bgs = VCB.map(function (b) { return '<button class="vcbg' + ((VC.bg || 'auto') === b[0] ? ' on' : '') + '" data-act="vcbg" data-v="' + b[0] + '" style="' + (VCS[b[0]] ? 'background:linear-gradient(135deg,' + VCS[b[0]][0][0] + ',' + VCS[b[0]][0][1] + ')' : '') + '">' + (!VCS[b[0]] && b[0] !== 'auto' && window.KGScenes ? KGScenes.svg(b[0]) : '') + '<span>' + b[1] + '</span></button>'; }).join('');
      var fonts = VCF.map(function (f, i) { return '<button class="vcfont' + (VC.font === i ? ' on' : '') + '" data-act="vcfont" data-v="' + i + '" style="font-family:\'' + f[0] + '\',Georgia,serif;font-weight:' + f[1].replace('italic ', '') + ';' + (/italic/.test(f[1]) ? 'font-style:italic' : '') + '">' + f[2] + '</button>'; }).join('');
      return '<div class="vcwrap2" id="vcstudio" role="dialog" aria-modal="true" aria-label="Verse card"><div class="vcpanel"><div class="vchead"><h3>Verse card</h3><button class="ib" data-act="vcclose" aria-label="Close">' + ic('x', 18) + '</button></div>' +
        '<div class="vcbody"><div class="vcprev"><canvas class="vccv" id="vcmain" aria-label="Verse card preview"></canvas><p class="vctip">Tap a word on the card to colour it: gold, then a second colour, then plain.</p></div>' +
        '<div class="vcopts"><h4>Background</h4><div class="vcbgs">' + bgs + '</div><h4>Font</h4><div class="vcfonts">' + fonts + '</div>' +
        '<h4>Shape</h4><div class="vcseg"><button data-act="vcshape" data-v="sq" class="' + (VC.shape === 'sq' ? 'on' : '') + '">Square post</button><button data-act="vcshape" data-v="st" class="' + (VC.shape === 'st' ? 'on' : '') + '">Story</button></div>' +
        '<h4>Coloured words</h4><div class="vcseg"><button data-act="vcauto">Choose for me</button><button data-act="vcclear">Plain</button></div>' +
        '<div class="vcsave"><button class="pri" data-act="vcshare">' + ic('imp', 16) + ' Save or share image</button><button data-act="vcdl">Download</button></div></div></div></div></div>';
    };
    var vcOpenStudio = function () { var dv = dailyVerse(); if (!vcSet(dv)) { toast('The verse of the day is still loading'); return; } var o = document.getElementById('vcstudio'); if (o) o.remove(); document.body.insertAdjacentHTML('beforeend', vcStudio()); VC.open = true; vcRender(); };
    var vcRefresh = function () { if (!VC.open) return; var o = document.getElementById('vcstudio'); if (!o) return; var y = o.querySelector('.vcopts').scrollTop; o.outerHTML = vcStudio(); var n = document.getElementById('vcstudio'); n.querySelector('.vcopts').scrollTop = y; vcRender(); };
    var vcShow = function (blob) { // fallback: show the image so it can be long-pressed and saved
      var u = URL.createObjectURL(blob); var o = document.createElement('div'); o.className = 'vcwrap2 vcimgv'; o.innerHTML = '<div class="vcpanel" style="max-width:520px"><div class="vchead"><h3>Your image</h3><button class="ib" aria-label="Close">' + ic('x', 18) + '</button></div><img src="' + u + '" alt="Verse card for ' + esc(VC.ref) + '"><p class="vctip">On a phone, press and hold the image, then choose Save image or Add to Photos.</p><a class="pri vcdla" href="' + u + '" download="' + vcName() + '">Download</a></div>';
      o.addEventListener('click', function (e) { if (e.target === o || e.target.closest('.ib')) o.remove(); }); document.body.appendChild(o);
    };
    document.addEventListener('click', function (e) {
      var cv = e.target.closest && e.target.closest('#vcmain'); if (!cv || !VC.hit) return;
      var r = cv.getBoundingClientRect(), sx = VC.hit.W / r.width, x = (e.clientX - r.left) * sx, y = (e.clientY - r.top) * sx, px = VC.hit.px;
      VC.hit.lines.forEach(function (ln) { ln.ws.forEach(function (o) { if (x >= o.x - 6 && x <= o.x + o[2] + 6 && y <= o.y + px * .3 && y >= o.y - px * 1.0) { VC.marks[o[0]] = ((VC.marks[o[0]] || 0) + 1) % 3; } }); });
      vcRender();
    });
    var actVC = act;
    act = function (a, d) {
      d = d || {};
      switch (a) {
        case 'vcopen': vcOpenStudio(); return;
        case 'vcclose': var o = document.getElementById('vcstudio'); if (o) o.remove(); VC.open = false; render(); return;
        case 'vcbg': VC.bg = d.v; vcRefresh(); return;
        case 'vcfont': VC.font = +d.v; vcRefresh(); return;
        case 'vcshape': VC.shape = d.v; vcRefresh(); return;
        case 'vcauto': VC.marks = vcAuto(vcWords(VC.text)); vcRender(); return;
        case 'vcclear': VC.marks = {}; vcRender(); return;
        case 'vcshare': vcBlob().then(function (b) {
            if (!b) { toast('The image could not be made on this device'); return; }
            var file; try { file = new File([b], vcName(), { type: 'image/png' }); } catch (e) {}
            if (file && navigator.canShare && navigator.canShare({ files: [file] })) { navigator.share({ files: [file], title: VC.ref, text: VC.text + ' (' + VC.ref + ', KJV)' }).catch(function (err) { if (err && err.name !== 'AbortError') vcShow(b); }); }
            else vcShow(b);
          }); return;
        case 'vcdl': vcBlob().then(function (b) { if (!b) return; var u = URL.createObjectURL(b), aa = document.createElement('a'); aa.href = u; aa.download = vcName(); document.body.appendChild(aa); aa.click(); aa.remove(); setTimeout(function () { vcShow(b); }, 400); }); return;
      }
      return actVC(a, d);
    };
    // show the designed card on the home page
    var homeVC = homeHtml;
    homeHtml = function () {
      var h = homeVC(), dv = dailyVerse(); if (!dv || h.indexOf('<section class="votd">') < 0) return h; vcSet(dv);
      h = h.replace('<section class="votd"><div class="lbl">Verse of the day</div>', '<section class="votd vccard"><div class="lbl">Verse of the day</div><button class="vchome" data-act="vcopen" aria-label="Design and share this verse"><canvas class="vccv" aria-hidden="true"></canvas></button>');
      h = h.replace(/(<section class="votd vccard">[\s\S]*?)<blockquote>/, '$1<blockquote class="vcsr">');
      return h.replace(/(<section class="votd vccard">[\s\S]*?<div class="acts">)/, '$1<button data-act="vcopen">' + ic('imp', 15) + ' Design and save</button>');
    };
    var renderVC = render;
    render = function () { renderVC(); if (view === 'home' && document.querySelector('.vchome canvas')) vcRender(); };
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && VC.open) act('vcclose'); });
    window.__vc = VC;
  } catch (e) { console.warn('verse card', e); }

  // ===== 31. Living Word Mode and Deep Study Mode: two independent controls =====
  // Living Word: while the recording plays, the verse being read lifts into a card, the rest of the chapter softly blurs,
  // and each word is highlighted from measured word timings (audio/<book>/words.json). Where a verse has no reliable
  // word timing, the card highlights the whole verse instead and says so. Deep Study never turns Living Word on;
  // inside Deep Study the effect runs only if "Immersive Scripture Focus" is switched on.
  try {
    var lsj = function (k, d) { try { return Object.assign({}, d, JSON.parse(localStorage.getItem(k) || '{}')); } catch (e) { return Object.assign({}, d); } };
    var LWS = lsj('lwset', { on: false, words: true, spot: true, blur: true, inten: 'balanced', hl: 'glow', auto: true });
    var DSS = lsj('dsset', { on: false, focus: false });
    var lwSave = function () { try { localStorage.setItem('lwset', JSON.stringify(LWS)); localStorage.setItem('dsset', JSON.stringify(DSS)); } catch (e) {} };
    var LW = { vi: -1, wi: -1, card: null, words: {}, wload: {}, raf: 0, paused: false, held: -1, pane: null };
    var lwEff = function () { return !!LWS.on && (!DSS.on || !!DSS.focus); };
    if (AUDM.Genesis && !AUDM.Genesis.w) AUDM.Genesis.w = 'audio/genesis/words.json';
    var lwWords = function (book) {
      var B = AUDM[book]; if (!B || !B.w) return null; if (LW.words[book]) return LW.words[book];
      if (!LW.wload[book]) { LW.wload[book] = 1; fetch(B.w + '?v=' + (SUM && SUM.v || '1')).then(function (r) { return r.json(); }).then(function (d) { LW.words[book] = d; LW.vi = -1; }).catch(function () { LW.wload[book] = 0; }); }
      return null;
    };
    var lwToks = function (t) { return String(t).replace(/\s+/g, ' ').trim().replace(/([?!;:,.])(?=[A-Za-z])/g, '$1 ').split(' ').filter(Boolean); };
    var reduced = function () { try { return matchMedia('(prefers-reduced-motion: reduce)').matches; } catch (e) { return false; } };
    var INT = { subtle: [1, .72, 2], balanced: [2.2, .5, 6], cinematic: [3.5, .34, 10] };
    var lwVars = function (el) { var x = INT[LWS.inten] || INT.balanced; el.style.setProperty('--lwb', (LWS.blur ? x[0] : 0) + 'px'); el.style.setProperty('--lwo', LWS.blur ? x[1] : .6); el.style.setProperty('--lwl', (reduced() ? 0 : x[2]) + 'px'); };
    var lwClear = function (keepCard) {
      document.querySelectorAll('.pane.lw-active').forEach(function (p) { p.classList.remove('lw-active'); });
      document.body.classList.remove('lw-dim');
      if (LW.card && !keepCard) { var c = LW.card; c.classList.remove('up'); setTimeout(function () { c.remove(); }, reduced() ? 0 : 320); LW.card = null; }
      LW.vi = -1; LW.wi = -1;
    };
    var lwTarget = function () { // the verse element being read, in the reading area
      if (!(view === 'read' && cur && AU.open && cur.b === AU.book && +cur.c === AU.c)) return null;
      var i = aVerseAt(AU.el.currentTime || 0), els = document.querySelectorAll('#rd .vs[data-vk$="|' + AU.book + ' ' + AU.c + ':' + (i + 1) + '"]');
      return els.length ? { i: i, el: els[0] } : null;
    };
    var lwBuild = function (tg) {
      var pane = tg.el.closest('.pane') || tg.el.closest('#rd'), txt = tg.el.closest('.txt') || pane; if (!pane) return;
      var vt = (KJV[AU.book] && KJV[AU.book][AU.c] && KJV[AU.book][AU.c][tg.i]) || '', toks = lwToks(plain(vt));
      var wd = lwWords(AU.book), times = wd && wd[String(AU.c)] && wd[String(AU.c)][tg.i];
      var exact = !!(LWS.words && times && times.length === toks.length);
      var c = document.createElement('div'); c.className = 'lwcard hl-' + LWS.hl + (exact ? '' : ' noword'); c.setAttribute('aria-live', 'off');
      c.innerHTML = '<span class="lwn">' + (tg.i + 1) + '</span><div class="lwt">' + toks.map(function (w, k) { return '<span class="lww" data-k="' + k + '">' + esc(w) + '</span>'; }).join(' ') + '</div>' +
        (!exact && LWS.words ? '<span class="lwnote">Verse focus (word timing not available for this verse)</span>' : '') + '<button class="lwcont" data-act="lwcont" hidden>Continue ' + ic('cr', 14) + '</button>';
      c._times = exact ? times : null;
      var pr = pane.getBoundingClientRect(), tr = txt.getBoundingClientRect(), vr = tg.el.getBoundingClientRect();
      if (getComputedStyle(pane).position === 'static') pane.style.position = 'relative';
      var cl = Math.max(6, tr.left - pr.left - 16), cw = Math.min(tr.width + 32, pr.width - cl - 6);
      c.style.top = Math.round(vr.top - pr.top - 14) + 'px'; c.style.left = Math.round(cl) + 'px'; c.style.width = Math.round(cw) + 'px';
      lwVars(c); pane.appendChild(c); LW.pane = pane;
      if (!LWS.spot) c.classList.add('flat');
      requestAnimationFrame(function () { requestAnimationFrame(function () { c.classList.add('up'); }); });
      return c;
    };
    var lwTick = function () {
      LW.raf = 0;
      if (!lwEff() || LW.paused || !AU.open) { lwClear(); return; }
      var tg = lwTarget(); if (!tg) { lwClear(); return; }
      // auto-advance off: stop when the reading reaches the end of the verse in focus
      if (!LWS.auto && !AU.el.paused && LW.vi >= 0 && tg.i === LW.vi + 1 && LW.held !== LW.vi && LW.card && document.body.contains(LW.card)) {
        var Cn = aCh(), nx = Cn && Cn.v[LW.vi + 1], tn = AU.el.currentTime || 0;
        if (nx != null && tn - nx < 0.6) { LW.held = LW.vi; AU.el.pause(); try { AU.el.currentTime = Math.max(0, nx - 0.2); } catch (e) {} var bc = LW.card.querySelector('.lwcont'); if (bc) bc.hidden = false; return; }
      }
      if (tg.i !== LW.vi || !LW.card || !document.body.contains(LW.card)) {
        if (LW.card) { var old = LW.card; old.classList.remove('up'); setTimeout(function () { old.remove(); }, reduced() ? 0 : 320); }
        LW.vi = tg.i; LW.wi = -1; LW.card = lwBuild(tg);
        if (LW.card && !LWS.auto && AU.el.paused && LW.held === tg.i) { var bcc = LW.card.querySelector('.lwcont'); if (bcc) bcc.hidden = false; }
        var pane = LW.card && LW.pane; document.querySelectorAll('.pane.lw-active').forEach(function (p) { if (p !== pane) p.classList.remove('lw-active'); });
        if (pane) { lwVars(pane); pane.classList.add('lw-active'); }
        if (LWS.inten === 'cinematic' && LWS.blur) document.body.classList.add('lw-dim'); else document.body.classList.remove('lw-dim');
      }
      // word by word, from measured timings
      var c = LW.card, t = AU.el.currentTime || 0;
      if (c && c._times) {
        var cs = t * 100 + 4, k = -1, T = c._times; for (var j = 0; j < T.length; j++) { if (T[j] <= cs) k = j; else break; }
        if (k !== LW.wi) { var ws = c.querySelectorAll('.lww'); ws.forEach(function (w, n) { w.classList.toggle('on', n === k); w.classList.toggle('done', n < k); }); LW.wi = k; }
      } else if (c && !c.classList.contains('whole')) c.classList.add('whole');
      if (!AU.el.paused) LW.raf = requestAnimationFrame(lwTick);
    };
    var lwKick = function () { if (!LW.raf) LW.raf = requestAnimationFrame(lwTick); };
    ['play', 'seeked', 'loadedmetadata'].forEach(function (ev) { AU.el.addEventListener(ev, function () { LW.vi = ev === 'play' ? LW.vi : -1; if (ev === 'play') LW.held = -1; lwKick(); }); });
    AU.el.addEventListener('pause', function () { lwKick(); });
    // tap the blurred text to pause or resume the effect; the audio keeps playing
    document.addEventListener('click', function (e) {
      if (!lwEff() || !AU.open) return;
      if (e.target.closest && e.target.closest('.lwcard,.vn,#abar,#tb,button,a,input,select,textarea')) return;
      var inText = e.target.closest && e.target.closest('#rd .txt'); if (!inText) return;
      if (LW.paused) { LW.paused = false; lwPill(false); lwKick(); }
      else if (document.querySelector('.pane.lw-active')) { LW.paused = true; lwClear(); lwPill(true); }
    });
    var lwPill = function (show) { var p = document.getElementById('lwpill'); if (!show) { if (p) p.remove(); return; } if (!p) { p = document.createElement('button'); p.id = 'lwpill'; p.className = 'lwpill'; p.setAttribute('data-act', 'lwresume'); p.textContent = 'Living Word paused · tap to resume'; document.body.appendChild(p); } };
    var lwSwitch = function (key, label, desc, on, dis) { return '<button type="button" class="lwsw" role="switch" aria-checked="' + !!on + '" data-act="lwset" data-k="' + key + '"' + (dis ? ' disabled' : '') + '><span class="lwsl"><b>' + label + '</b>' + (desc ? '<small>' + desc + '</small>' : '') + '</span><span class="lwtrack"><i></i></span></button>'; };
    var lwSeg = function (key, opts, val) { return '<div class="lwseg" role="radiogroup">' + opts.map(function (o) { return '<button type="button" role="radio" aria-checked="' + (String(val) === String(o[0])) + '" data-act="lwset" data-k="' + key + '" data-v="' + o[0] + '" class="' + (String(val) === String(o[0]) ? 'on' : '') + '">' + o[1] + '</button>'; }).join('') + '</div>'; };
    var lwPanel = function (where) {
      var note = DSS.on && LWS.on && !DSS.focus ? '<p class="lwnote2">Deep Study is on, so Living Word is resting. Turn on Immersive Scripture Focus in Deep Study to use it while you study.</p>' : '';
      var noaud = !(cur && AUDM[cur.b]) ? '<p class="lwnote2">Living Word follows the audio recording. ' + (cur ? esc(cur.b) + ' has no recording yet, so the text stays still.' : '') + '</p>' : '';
      return '<div class="lwpanel" data-where="' + where + '">' + lwSwitch('on', 'Living Word Mode', 'The verse being read lifts into a card while you listen', LWS.on) + (where === 'toolbar' ? lwSwitch('ds', 'Deep Study Mode', 'Study tools, with the text kept still', DSS.on) : '') + note + noaud +
        '<div class="lwmore' + (LWS.on ? '' : ' off') + '">' + lwSwitch('words', 'Word-by-word highlighting', '', LWS.words) + lwSwitch('spot', 'Verse spotlight', 'The card lifts from the page', LWS.spot) + lwSwitch('blur', 'Background blur', '', LWS.blur) + lwSwitch('auto', 'Auto-advance verses', 'Off: pause after each verse', LWS.auto) +
        '<h6>Animation intensity</h6>' + lwSeg('inten', [['subtle', 'Subtle'], ['balanced', 'Balanced'], ['cinematic', 'Cinematic']], LWS.inten) +
        '<h6>Highlight style</h6>' + lwSeg('hl', [['glow', 'Soft glow'], ['solid', 'Solid'], ['under', 'Underline']], LWS.hl) +
        '<h6>Audio speed</h6>' + lwSeg('rate', [[0.75, '0.75×'], [1, '1×'], [1.25, '1.25×'], [1.5, '1.5×'], [2, '2×']], AUS.rate) + '</div></div>';
    };
    var dsBar = function () {
      if (!DSS.on) return '';
      return '<section class="dsbar" aria-label="Deep Study tools"><div class="dshead"><b>' + ic('bulb', 16) + ' Deep Study</b><span>Everything stays still while you study' + (DSS.focus ? ', except Living Word when it plays' : '') + '.</span></div>' +
        '<div class="dstools"><button data-act="drawer">' + ic('book', 15) + ' Study panel: words, verse, notes</button><button data-act="sn" data-m="' + ((+S.il || 0) ? 0 : 2) + '">' + ic('target', 15) + ' Strong\'s and meanings: ' + ((+S.il || 0) ? 'on' : 'off') + '</button><button data-act="picker">' + ic('cols', 15) + ' Compare translations</button><button data-act="analyze">' + ic('chart', 15) + ' Across passages</button><button data-act="wstudy">' + ic('spark', 15) + ' Hebrew and Greek word study</button></div>' +
        '<div class="dsset">' + lwSwitch('focus', 'Immersive Scripture Focus', 'Allow Living Word while in Deep Study', DSS.focus) + lwSwitch('on', 'Living Word Mode', '', LWS.on) + '</div></section>';
    };
    var tbSwitch = function () { return '<button type="button" class="lwtb" role="switch" aria-checked="' + !!LWS.on + '" data-act="lwset" data-k="on" title="Living Word Mode"><span class="lwtrack"><i></i></span><span>Living Word</span></button><button type="button" class="lwtb ds" role="switch" aria-checked="' + !!DSS.on + '" data-act="lwset" data-k="ds" title="Deep Study Mode"><span class="lwtrack"><i></i></span><span>Deep Study</span></button><button class="ib ghost lwgear" data-act="lwpanel" title="Living Word settings" aria-expanded="' + !!LW.panel + '">' + ic('spark') + '</button>'; };
    var ribLW = ribbon;
    ribbon = function () {
      var h = ribLW();
      h = h.replace(/(<button class="ib ghost[^"]*" data-act="aa")/, tbSwitch() + '$1');
      if (LW.panel) h = h.replace('<div class="rd2" role="toolbar" aria-label="Reader">', '<div class="rd2" role="toolbar" aria-label="Reader"><div class="lwpop">' + lwPanel('toolbar') + '</div>');
      return h;
    };
    var readLW = readHtml;
    readHtml = function () { var h = readLW(), d = dsBar(); if (!d) return h; var i = h.indexOf('</header>'); return i > 0 ? h.slice(0, i + 9) + d + h.slice(i + 9) : d + h; };
    var aaLW = aaHtml;
    aaHtml = function () { var h = aaLW(); return h.replace(/<\/div>$/, '<div class="lwaa"><h6>Living Word</h6>' + lwSwitch('on', 'Living Word Mode', 'Verse spotlight while the audio plays', LWS.on) + '<button class="lwmorebtn" data-act="lwpanel">More Living Word settings</button></div></div>'); };
    var actLW = act;
    act = function (a, d) {
      d = d || {};
      if (a === 'lwset') {
        var k = d.k;
        if (k === 'ds') { DSS.on = !DSS.on; }
        else if (k === 'focus') { DSS.focus = !DSS.focus; }
        else if (k === 'rate') { AUS.rate = +d.v; ausSave(); AU.el.playbackRate = AUS.rate; }
        else if (d.v != null) { LWS[k] = d.v; }
        else { LWS[k] = !LWS[k]; }
        if (k === 'on' && !LWS.on) { LW.paused = false; lwPill(false); }
        lwSave(); lwClear(); LW.held = -1;
        if (k === 'ds' || k === 'focus') render(); else lwRefreshPanels();
        if (AU.bar) abUpdate(true);
        lwKick(); return;
      }
      if (a === 'lwpanel') { LW.panel = !LW.panel; render(); return; }
      if (a === 'lwresume') { LW.paused = false; lwPill(false); lwKick(); return; }
      if (a === 'lwcont') { var b = LW.card && LW.card.querySelector('.lwcont'); if (b) b.hidden = true; var Cc = aCh(), nv = Cc && Cc.v[LW.vi + 1]; if (nv != null) { try { AU.el.currentTime = nv + 0.01; } catch (e) {} } LW.held = LW.vi; AU.el.play(); return; }
      return actLW(a, d);
    };
    // update every open settings panel and switch in place, without re-rendering the chapter
    var lwRefreshPanels = function () {
      document.querySelectorAll('.lwpanel').forEach(function (p) { p.outerHTML = lwPanel(p.dataset.where); });
      document.querySelectorAll('[role="switch"][data-k]').forEach(function (b) { var k = b.dataset.k, v = k === 'ds' ? DSS.on : k === 'focus' ? DSS.focus : LWS[k]; b.setAttribute('aria-checked', String(!!v)); });
      var rs = AU.bar && AU.bar.querySelector('[data-ab="rate"]'); if (rs) rs.value = String(AUS.rate);
    };
    // player: a settings button opens the same Living Word settings
    var abB = abBuild;
    abBuild = function () {
      var fresh = !AU.bar, b = abB(); if (!fresh) return b;
      var dl = b.querySelector('[data-ab="dlm"]'); if (dl) dl.insertAdjacentHTML('beforebegin', '<button class="abtg" data-ab="lwm" title="Living Word settings">' + ic('spark', 16) + '<span>Living Word</span></button>');
      b.insertAdjacentHTML('beforeend', '<div class="ablw" data-abf="lw" hidden></div>');
      var rs = b.querySelector('[data-ab="rate"]'); if (rs && !rs.querySelector('[value="2"]')) { rs.insertAdjacentHTML('beforeend', '<option value="2">2×</option>'); var o125 = document.createElement('option'); o125.value = '1.25'; o125.textContent = '1.25×'; rs.insertBefore(o125, rs.querySelector('[value="1.3"]')); }
      b.addEventListener('click', function (e) { var t = e.target.closest('[data-ab="lwm"]'); if (!t) return; var p = b.querySelector('[data-abf="lw"]'); p.hidden = !p.hidden; if (!p.hidden) p.innerHTML = lwPanel('player'); });
      return b;
    };
    var renderLW = render;
    render = function () { renderLW(); if (LW.card && !document.body.contains(LW.card)) LW.card = null; LW.vi = -1; lwKick(); };
    window.__lw = { LWS: LWS, DSS: DSS, LW: LW, eff: lwEff };
  } catch (e) { console.warn('living word', e); }

  // ===== 32. Phone selection sheet: Verse / Word, colour styles, actions, word-by-word navigation =====
  try {
    var MSH = { more: false };
    var MCOL = [['#8B5CF6', 'Purple'], ['#EC4899', 'Pink'], ['#F59E0B', 'Orange'], ['#EF4444', 'Red'], ['#16A34A', 'Green'], ['#2563EB', 'Blue']];
    var MHL = [['#FDE68A', 'Yellow'], ['#BBF7D0', 'Green'], ['#BFDBFE', 'Blue'], ['#FBCFE8', 'Pink'], ['#E9D5FF', 'Purple'], ['#FED7AA', 'Orange']];
    var msPhone = function () { return innerWidth <= 800; };
    var msWords = function () { return Array.prototype.slice.call(document.querySelectorAll('#rd .pane:first-of-type .w[data-vk], #rd .w[data-vk]')).filter(function (w, i, a) { return a.indexOf(w) === i; }); };
    var msVerses = function () { var seen = {}; return Array.prototype.slice.call(document.querySelectorAll('#rd .vs[data-vk]')).filter(function (v) { if (seen[v.dataset.vk]) return false; seen[v.dataset.vk] = 1; return true; }); };
    var msAll = function (fn) { return sel.length && sel.every(function (x) { return fn(M[keyOf(x)] || {}); }); };
    var msLabel = function () {
      if (!sel.length) return '';
      if (sel[0][1] >= 0) { var w = document.querySelector('.w[data-vk="' + sel[0][0] + '"][data-i="' + sel[0][1] + '"]'); var t = w ? w.textContent.replace(/[^A-Za-z'’-]/g, '') : ''; return '“' + esc(t) + '”' + (sel.length > 1 ? ' +' + (sel.length - 1) : ''); }
      var r = sel[0][0].split('|')[1]; return esc(r) + (sel.length > 1 ? ' +' + (sel.length - 1) : '');
    };
    var msSheet = function () {
      var word = sel[0] && sel[0][1] >= 0, A = function (y, v, inner, title, on, style) { return '<button class="msA' + (on ? ' on' : '') + '" data-y="' + y + '"' + (v != null ? ' data-v="' + v + '"' : '') + ' title="' + title + '" aria-label="' + title + '"' + (style ? ' style="' + style + '"' : '') + '>' + inner + '</button>'; };
      var row1 = MCOL.map(function (c) { return A('col', c[0], 'A', c[1] + ' text', msAll(function (m) { return m.c === c[0]; }), 'color:' + c[0]); }).join('') +
        A('hl', '#FDE68A', '<span class="mk">A</span>', 'Highlight', msAll(function (m) { return !!m.g; })) + A('z', '1', 'A', 'Bigger text', false, 'font-size:26px;font-weight:800') + A('z', '-1', 'A', 'Smaller text', false, 'font-size:14px;opacity:.6') +
        '<button class="msA msmore' + (MSH.more ? ' on' : '') + '" data-y="more" aria-label="More styles" aria-expanded="' + MSH.more + '">⋮</button>';
      var row2 = A('b', null, 'A', 'Bold', msAll(function (m) { return m.b; }), 'font-weight:900') + A('i', null, 'A', 'Italic', msAll(function (m) { return m.i; }), 'font-style:italic') +
        A('ul', '#EF4444', '<span style="text-decoration:underline;text-decoration-color:#EF4444;text-decoration-thickness:3px">A</span>', 'Red underline', msAll(function (m) { return m.u && m.uc === '#EF4444'; })) +
        A('ul', '#3B82F6', '<span style="text-decoration:underline;text-decoration-color:#3B82F6;text-decoration-thickness:3px">A</span>', 'Blue underline', msAll(function (m) { return m.u && m.uc === '#3B82F6'; })) +
        A('cp', null, 'AA', 'Capitals', msAll(function (m) { return m.cp; }), 'font-size:15px;font-weight:800') + A('ol', null, '<span class="olA">A</span>', 'Outlined letters', msAll(function (m) { return m.ol; })) +
        A('br', null, '[ ]', 'Brackets', msAll(function (m) { return m.br; }), 'font-size:16px') +
        MHL.map(function (c) { return A('hl', c[0], '<i class="sw2" style="background:' + c[0] + '"></i>', c[1] + ' highlight', msAll(function (m) { return m.g === c[0]; })); }).join('') +
        A('clr', null, '✕', 'Clear styles', false, 'font-size:15px;color:var(--mute)');
      var C = function (attr, icn, l, cls) { return '<button class="msc' + (cls ? ' ' + cls : '') + '" ' + attr + '>' + ic(icn, 18) + '<span>' + l + '</span></button>'; };
      var ws = word && document.querySelector('.w.sel[data-s]');
      var acts = C('data-t="copy"', 'copy', 'Copy') + C('data-x="note"', 'pen', 'Note') + C('data-t="study"', 'spark', 'Explain', 'ai') + (ws ? C('data-y="wstudy"', 'target', 'Word Study') : '') + C('data-y="search"', 'search', 'Search') +
        C('data-x="bm"', 'bookmark', 'Bookmark') + C('data-x="cmp"', 'cols', 'Compare') + C('data-x="rel"', 'link', 'Related') + C('data-x="mem"', 'star', 'Memorise') + C('data-t="jr"', 'note', 'Journal');
      var rows = (word ? '<button class="msr" data-t="study">' + ic('target', 18) + '<span>Word Info</span>' + ic('cr', 16) + '</button>' : '<button class="msr" data-t="study">' + ic('bulb', 18) + '<span>Verse Info</span>' + ic('cr', 16) + '</button>') +
        '<button class="msr" data-y="notes">' + ic('note', 18) + '<span>Notes & Journal</span>' + ic('cr', 16) + '</button><button class="msr" data-x="rel">' + ic('link', 18) + '<span>Related verses</span>' + ic('cr', 16) + '</button>';
      return '<div class="msheet"><div class="mshandle" aria-hidden="true"></div><div class="mstop"><div class="msseg" role="tablist"><button role="tab" aria-selected="' + !word + '" data-y="mverse" class="' + (word ? '' : 'on') + '">Verse</button><button role="tab" aria-selected="' + !!word + '" data-y="mword" class="' + (word ? 'on' : '') + '">Word</button></div><button class="ib msx" data-t="x" aria-label="Close">' + ic('x', 18) + '</button></div>' +
        '<div class="msrow">' + row1 + '</div>' + (MSH.more ? '<div class="msrow r2">' + row2 + '</div>' : '') + '<div class="msacts">' + acts + '</div><div class="mslist">' + rows + '</div>' +
        '<div class="msnav"><button class="msarrow" data-y="prev" aria-label="Previous ' + (word ? 'word' : 'verse') + '">' + ic('cl', 20) + '</button><b>' + msLabel() + '</b><button class="msarrow" data-y="next" aria-label="Next ' + (word ? 'word' : 'verse') + '">' + ic('cr', 20) + '</button></div></div>';
    };
    var tbMS = tbDraw;
    tbDraw = function () {
      tbMS(); var t = $('#tb'); if (!t) return;
      var on = msPhone() && t.style.display !== 'none' && sel.length && view === 'read';
      t.classList.toggle('msmode', !!on); if (on) t.innerHTML = msSheet();
    };
    var msFx = function () { // outlined letters and brackets, which the core styles do not cover
      document.querySelectorAll('.fx-ol,.fx-br').forEach(function (e) { e.classList.remove('fx-ol', 'fx-br'); });
      for (var k in M) { var m = M[k]; if (!m || !(m.ol || m.br)) continue; var p = k.split('|'), vk = p[0] + '|' + p[1], i = p[2];
        document.querySelectorAll(i != null ? '.w[data-vk="' + vk + '"][data-i="' + i + '"]' : '.vs[data-vk="' + vk + '"]').forEach(function (e) { if (m.ol) e.classList.add('fx-ol'); if (m.br) e.classList.add('fx-br'); }); }
    };
    var renderMS = render;
    render = function () { renderMS(); try { msFx(); } catch (e) {} };
    var msGo = function (d) {
      var word = sel[0] && sel[0][1] >= 0;
      if (word) { var L = msWords(), cw = document.querySelector('.w[data-vk="' + sel[0][0] + '"][data-i="' + sel[0][1] + '"]'), i = L.indexOf(cw), n = L[i + d]; if (!n) return; sel = [[n.dataset.vk, +n.dataset.i]]; selUpdate(); n.scrollIntoView({ block: 'nearest', behavior: 'smooth' }); }
      else { var V = msVerses(), j = -1; V.forEach(function (v, k) { if (v.dataset.vk === sel[0][0]) j = k; }); var nv = V[j + d]; if (!nv) return; sel = [[nv.dataset.vk, -1]]; selUpdate(); nv.scrollIntoView({ block: 'nearest', behavior: 'smooth' }); }
    };
    document.addEventListener('click', function (e) {
      var b = e.target.closest && e.target.closest('#tb [data-y]'); if (!b) return; e.stopPropagation(); var y = b.dataset.y, v = b.dataset.v;
      if (y === 'more') { MSH.more = !MSH.more; tbDraw(); return; }
      if (y === 'mverse') { sel = Object.keys(sel.reduce(function (o, x) { o[x[0]] = 1; return o; }, {})).map(function (vk) { return [vk, -1]; }); selUpdate(); return; }
      if (y === 'mword') { if (sel[0] && sel[0][1] < 0) { sel = [[sel[0][0], 0]]; selUpdate(); } return; }
      if (y === 'prev' || y === 'next') { msGo(y === 'next' ? 1 : -1); return; }
      if (y === 'col') { var all = msAll(function (m) { return m.c === v; }); ap(function (m) { m.c = all ? 0 : v; }); return; }
      if (y === 'hl') { var allh = msAll(function (m) { return m.g === v; }); ap(function (m) { m.g = allh ? 0 : v; }); return; }
      if (y === 'z') { szb(+v > 0 ? .15 : -.15); return; }
      if (y === 'b' || y === 'i') { tg(y); return; }
      if (y === 'ul') { var allu = msAll(function (m) { return m.u && m.uc === v; }); ap(function (m) { if (allu) { m.u = 0; m.uc = 0; } else { m.u = 1; m.uc = v; } }); return; }
      if (y === 'cp' || y === 'ol' || y === 'br') { var allx = msAll(function (m) { return m[y]; }); ap(function (m) { m[y] = allx ? 0 : 1; }); return; }
      if (y === 'clr') { ap(function (m) { for (var x in m) delete m[x]; }); return; }
      if (y === 'wstudy') { var w = document.querySelector('.w.sel[data-s]'); if (w) act('lab', { k: w.dataset.s.split(' ')[0] }); return; }
      if (y === 'search') { var q = sel[0][1] >= 0 ? Array.prototype.map.call(document.querySelectorAll('.w.sel'), function (x) { return x.textContent; }).join(' ').replace(/[^A-Za-z' ]/g, '').trim() : sel[0][0].split('|')[1]; sel = []; selUpdate(); headSearch(q); return; }
      if (y === 'notes') { sel = []; selUpdate(); act('diary', {}); return; }
    }, true);
    window.addEventListener('resize', function () { if (sel.length) tbDraw(); });
    // on phones a word tap opens this sheet; the study panel stays one tap away under Word Info
    document.addEventListener('click', function (e) {
      if (!msPhone() || !e.target.closest || !e.target.closest('#rd .w') || e.target.closest('#tb')) return;
      var was = drawer; setTimeout(function () { if (!was && drawer && sel.length) { drawer = false; render(); } else if (sel.length) tbDraw(); }, 0);
    }, true);
  } catch (e) { console.warn('phone sheet', e); }

  // ===== 33. Themes from the user's palettes =====
  try {
    var NEWT = {"rose": ["Rose Night", "#2B2523", "#EDE6E3", "#F48FB1"], "peach": ["Peach Night", "#212A31", "#E3EAEE", "#FFB48A"], "lavender": ["Lavender Night", "#1B1A1E", "#ECE6F0", "#C39BFF"], "violet": ["Violet", "#242235", "#ECE8F4", "#B79FD0"], "graphite": ["Graphite", "#2A2A2A", "#FAFAFA", "#B0BEC5"], "bluegrey": ["Blue Grey", "#FAFAFA", "#263238", "#455A64"], "walnut": ["Walnut", "#F8F2EA", "#3E362E", "#865D36"], "rosewood": ["Dusty Rose", "#F8F5F5", "#4B3D3D", "#8B5B5B"]};
    Object.keys(NEWT).forEach(function (k) { THEMES[k] = NEWT[k][0]; if (!TSW.some(function (x) { return x[0] === k; })) TSW.push([k, NEWT[k][1], NEWT[k][2], NEWT[k][3]]); });
  } catch (e) { console.warn('themes', e); }

  // ===== 34. Themes page: every theme as a live preview, and whether the sidebar changes too =====
  try {
    var TH = { side: (function () { try { return localStorage.getItem('themeside') || 'all'; } catch (e) { return 'all'; } })() };
    var DARKT = { kingdom: 1, blue: 1, forest: 1, black: 1, rose: 1, peach: 1, lavender: 1, violet: 1, graphite: 1 };
    var NEWS = { rose: 1, peach: 1, lavender: 1, violet: 1, graphite: 1, bluegrey: 1, walnut: 1, rosewood: 1 };
    var thSide = function () { document.body.classList.toggle('side-classic', TH.side === 'inside'); };
    thSide();
    var thCard = function (k) {
      var on = S.theme === k;
      return '<button class="thcard' + (on ? ' on' : '') + '" data-act="thpick" data-v="' + k + '" aria-pressed="' + on + '" aria-label="' + esc(THEMES[k] || k) + ' theme">' +
        '<span class="thprev" data-theme="' + k + '">' + (TH.side === 'all' ? '<span class="thside" data-side="' + k + '"><i></i><i></i><i></i><i></i></span>' : '<span class="thside classic"><i></i><i></i><i></i><i></i></span>') +
        '<span class="thpage"><small>Psalms</small><b>23</b><span class="thtxt">The LORD is my <em>shepherd</em>; I shall not want.</span><span class="thbtn">Read</span></span></span>' +
        '<span class="thname">' + esc(THEMES[k] || k) + (NEWS[k] ? ' <small>new</small>' : '') + (on ? '<span class="thuse">' + ic('check', 13) + ' In use</span>' : '') + '</span></button>';
    };
    var thPage = function () {
      var all = TSW.map(function (t) { return t[0]; }), light = all.filter(function (k) { return !DARKT[k]; }), dark = all.filter(function (k) { return DARKT[k]; });
      return '<div class="home thpageview"><div class="greet"><button class="ib mobm" data-act="side" aria-label="Menu">' + ic('menu') + '</button><div><h1>Themes</h1></div></div>' +
        '<p class="dim">Tap a theme to use it. It changes at once and is remembered on this device.</p>' +
        '<div class="thside-choice"><span>Apply the theme to</span><div class="lwseg" role="radiogroup"><button role="radio" aria-checked="' + (TH.side === 'all') + '" class="' + (TH.side === 'all' ? 'on' : '') + '" data-act="thside" data-v="all">Whole app</button><button role="radio" aria-checked="' + (TH.side === 'inside') + '" class="' + (TH.side === 'inside' ? 'on' : '') + '" data-act="thside" data-v="inside">Reading area only</button></div><small>' + (TH.side === 'all' ? 'The sidebar changes colour with the theme.' : 'The sidebar keeps its usual dark navy; only the inside changes.') + '</small></div>' +
        '<h3>Light</h3><div class="thgrid">' + light.map(thCard).join('') + '</div><h3>Dark</h3><div class="thgrid">' + dark.map(thCard).join('') + '</div></div>';
    };
    var actTH = act;
    act = function (a, d) {
      d = d || {};
      if (a === 'themes') { view = 'themes'; if (innerWidth <= 800) side = false; AA = false; sv(); render(); var mm = $('#main'); if (mm) mm.scrollTop = 0; return; }
      if (a === 'thpick') { S.theme = d.v; sv(); render(); toast((THEMES[d.v] || d.v) + ' theme on'); return; }
      if (a === 'thside') { TH.side = d.v; try { localStorage.setItem('themeside', TH.side); } catch (e) {} thSide(); render(); return; }
      return actTH(a, d);
    };
    var renderTH = render;
    render = function () { renderTH(); thSide(); if (view === 'themes') { $('#main').innerHTML = thPage(); var dr = $('#drawer'); if (dr) dr.classList.remove('open'); var tb = $('#tb'); if (tb) tb.style.display = 'none'; } };
    var sideTH = sideHtml;
    sideHtml = function () { var h = sideTH(), btn = '<button data-act="themes" class="' + (view === 'themes' ? 'on' : '') + '" title="Themes">' + ic('spark') + '<span class="lb">Themes</span></button>'; return h.replace('<span class="lb">Other Books</span></button>', '<span class="lb">Other Books</span></button>' + btn); };
    var aaTH = aaHtml;
    aaHtml = function () { return aaTH().replace('<h6>Theme</h6>', '<h6>Theme <button class="thall" data-act="themes">See all themes</button></h6>'); };
  } catch (e) { console.warn('themes page', e); }

  // 35. open cleanly: start on Home (not a deep page), always keep a way to the menu, and flag a non-Auto layout on a phone
  (function () {
    // Every time the app opens, start on Home. The reader keeps its place (cur), so "Continue reading" still works.
    try { var vOpen = store.g('view', 'home'); if (vOpen !== 'home' && vOpen !== 'read') { view = 'home'; store.s('view', 'home'); } } catch (e) {}
    var renderOC = render;
    render = function () {
      renderOC();
      document.body.classList.toggle('noside', !side);
    };
    // a phone showing the Tablet or Desktop layout gets a small reminder with a one-tap way back
    var rw = Math.min(screen.width || 9999, document.documentElement.clientWidth || 9999);
    if (typeof DM !== 'undefined' && DM.mode !== 'auto' && DM.z < 1 && rw <= 800) {
      setTimeout(function () {
        var b = document.createElement('div'); b.className = 'dmnote';
        b.innerHTML = '<span>' + (DMN[DM.mode] || 'Desktop') + ' layout is on</span><button data-act="dmode" data-m="auto">Fit to phone</button><button class="x" aria-label="Close">×</button>';
        b.querySelector('.x').onclick = function () { b.remove(); };
        b.querySelector('[data-m]').addEventListener('click', function () { setTimeout(function () { b.remove(); }, 0); });
        document.body.appendChild(b);
        setTimeout(function () { if (b.parentNode) b.remove(); }, 12000);
      }, 600);
    }
  })();

  // 36. Sermon Workshop study helper (AI). Optional and closed by default. It helps the preacher think about the text:
  // it reads the main passage and what has been written in the current stage, checks every reference it gives, and
  // never fills in the preacher's fields. Answers are kept with the sermon, per stage.
  (function () {
    var SAI = { open: false, busy: false, live: '', q: '', stage: null, ctl: null };
    var CHIPS = {
      found: ['What questions should I ask of this passage before I start?', 'Is my main Scripture a good fit for what is on my heart?'],
      text: ['Help me divide this passage into its natural sections', 'Which words in this passage are worth a word study?'],
      ctx: ['What can be known about the author, audience and setting of this passage?', 'Where does this passage sit in the flow of the book?'],
      obs: ['What repeated words, contrasts and connecting words do you notice?', 'What questions does the text raise that I should not skip?'],
      int: ['Which other passages help interpret this one, and how?', 'What are the main ways this passage has been understood?'],
      theo: ['What truth about God does this passage reveal?', 'How does this truth fit the wider teaching of Scripture?'],
      christ: ['How does this passage point to Christ without forcing it?', 'Which New Testament passages connect to this text?'],
      aud: ['What questions might my hearers bring to this passage?', 'Where might this text meet people who are struggling?'],
      big: ['Does my big idea come from the text? Where is it weak?', 'Help me test my one-sentence message against the passage'],
      outline: ['Does my outline follow the shape of the text?', 'Suggest questions that would test each point against the passage'],
      jesus: ['How did Jesus use questions and images when teaching a truth like this?', 'Which of Jesus\' teaching moments are close to this theme?'],
      paul: ['How does Paul reason step by step about a truth like this?', 'What objections might Paul anticipate here?'],
      mode: ['Which approach fits this passage better, and why?'],
      intro: ['Give me three ways an introduction could lead into this text', 'Is my introduction leading to the text or away from it?'],
      points: ['Is this point clearly supported by its Scripture?', 'What application questions grow out of this point?'],
      illus: ['Which biblical images or stories could illustrate this truth?', 'Is my illustration helping or distracting from the text?'],
      review: ['Review my sermon: is every point grounded in the text?', 'Where is my sermon saying more than the text says?']
    };
    var RULES = 'You are a careful study helper inside a sermon preparation workshop in a Bible app. A preacher is preparing a sermon and is working on one stage of the preparation. Help them THINK about the text: explain, observe, ask good questions, test their work against Scripture and offer short suggestions they can weigh.\n' +
      'Rules:\n- The sermon is theirs. Do not write their sermon or fill in their stage for them. If they ask for wording, give a few short options and say they are suggestions.\n' +
      '- Stay grounded in the Bible text. Use the read_passage and find_verses tools to read Scripture before quoting it. Quote the KJV exactly as the tools return it. Never invent a verse or a reference.\n' +
      '- Always write references as Book chapter:verse (for example John 15:5) so they can be checked.\n' +
      '- Keep three things clearly apart: what the text says, what it means (interpretation), and background or history. Say when something is uncertain or debated, and do not present one tradition\'s view as the only view.\n' +
      '- Point to Christ where the text does, without forcing it.\n- Be warm, clear and concise: short paragraphs or bullet points. Answer in the language of the question.';
    function clip(t, n) { t = String(t || ''); return t.length > n ? t.slice(0, n) + '…' : t; }
    function stageFields(s, id) {
      var out = [];
      (BLOCKS[id] || []).forEach(function (b) { var key = b && b[1]; if (typeof key === 'string' && b[0] !== 'h' && b[0] !== 'note') { var v = smF(s, key); if (v && typeof v === 'string') out.push((b[2] || key) + ': ' + clip(v, 1200)); } });
      if (id === 'points' && s.points && s.points.length) { var p = s.points[Math.min(SW.pt || 0, s.points.length - 1)] || {}; PFIELDS.forEach(function (x) { if (p[x[0]]) out.push('Point ' + ((SW.pt || 0) + 1) + ' - ' + x[1] + ': ' + clip(p[x[0]], 900)); }); }
      if ((id === 'outline' || id === 'review') && s.points && s.points.length) s.points.forEach(function (p, j) { out.push('Point ' + (j + 1) + ': ' + clip(p.title || '', 200) + (p.ref ? ' (' + p.ref + ')' : '') + (id === 'review' && p.says ? ' - ' + clip(p.says, 400) : '')); });
      if (id === 'review') ['b_idea', 'b_one', 'b_purp', 't_central'].forEach(function (k) { var v = smF(s, k); if (v) out.push(k + ': ' + clip(v, 600)); });
      return out;
    }
    function context(s, id) {
      var st = STAGES.filter(function (x) { return x[0] === id; })[0] || STAGES[0], mr = normRef(smF(s, 'main')), lines = [];
      lines.push('Sermon title: ' + (smF(s, 'title') || '(none yet)'));
      ['type', 'cat', 'aud', 'occ'].forEach(function (k) { if (smF(s, k)) lines.push(k + ': ' + smF(s, k)); });
      if (s.seed && s.seed.text) lines.push('Started from (' + s.seed.kind + '): ' + s.seed.text);
      if (mr) { var vs = passageVerses(mr, 'KJV') || []; lines.push('Main Scripture: ' + mr + ' (KJV)'); vs.slice(0, 60).forEach(function (x) { lines.push(x.b + ' ' + x.c + ':' + x.v + ' ' + x.t); }); if (vs.length > 60) lines.push('(passage continues; use read_passage for the rest)'); }
      else lines.push('Main Scripture: not chosen yet');
      if (smF(s, 'support')) lines.push('Supporting passages: ' + smF(s, 'support'));
      if (smF(s, 'b_idea') && id !== 'big') lines.push('Big idea so far: ' + smF(s, 'b_idea'));
      lines.push('', 'Current stage: ' + st[1] + ' ' + st[2] + ' - ' + st[3]);
      var f = stageFields(s, id); lines.push(f.length ? 'What the preacher has written in this stage:\n' + f.join('\n') : 'The preacher has not written anything in this stage yet.');
      return lines.join('\n');
    }
    function tools() {
      var rp = wzTools('G1').filter(function (t) { return t.name === 'read_passage'; })[0];
      return [rp, { name: 'find_verses', description: 'Search the KJV Bible for verses containing a word or phrase. Optionally limit to one book. Returns up to 30 verses.', inputSchema: { type: 'object', properties: { phrase: { type: 'string' }, book: { type: 'string' } }, required: ['phrase'] },
        execute: function (a) { var ph = String((a && a.phrase) || '').toLowerCase().trim(); if (ph.length < 2) throw new Error('Give a longer phrase'); var bk = a && a.book ? String(a.book).toLowerCase() : null, out = [], n = 0;
          BOOKS.forEach(function (b) { if (bk && b.toLowerCase() !== bk) return; var B = KJV[b]; if (!B) return; Object.keys(B).forEach(function (c) { B[c].forEach(function (t, i) { if (!t) return; var p = plain(t); if (p.toLowerCase().indexOf(ph) >= 0) { n++; if (out.length < 30) out.push(b + ' ' + c + ':' + (i + 1) + ' ' + p); } }); }); });
          return { total: n, verses: out }; } }].filter(Boolean);
    }
    function chat(s, id) { s.ai = s.ai || {}; return (s.ai[id] = s.ai[id] || []); }
    async function run(s, id, q) {
      if (SAI.busy) return;
      var list = chat(s, id), sample = await hasAI();
      if (!sample) { list.push({ q: q, a: '', err: 'The study helper isn\'t available in this view. Open the app from your Claude library to use it.', at: Date.now() }); smsv(); render(); return; }
      SAI.busy = true; SAI.live = ''; SAI.q = q; SAI.stage = id; SAI.sid = s.id; SAI.ctl = new AbortController(); render();
      var msgs = [], first = RULES + '\n\n=== THE SERMON SO FAR ===\n' + context(s, id) + '\n=== END ===\n\n';
      list.slice(-3).forEach(function (m) { if (m.a) { msgs.push({ role: 'user', content: m.q }); msgs.push({ role: 'assistant', content: m.a }); } });
      if (msgs.length) msgs[0].content = first + 'Question: ' + msgs[0].content;
      msgs.push({ role: 'user', content: (msgs.length ? '' : first + 'Question: ') + q });
      var ans = '', err = '';
      try { var r = await sample(msgs, { signal: SAI.ctl.signal, cache: false, modelTier: 'default', tools: tools(), onText: function (o) { SAI.live = o.text; var el = document.getElementById('smailive'); if (el) el.innerHTML = wzAnsHtml(o.text); } }); ans = r.text; if (r.truncated) err = 'The answer was cut short.'; }
      catch (e) { var c = e && e.code; ans = (e && e.text) || ''; err = c === 'not_granted' ? 'AI access was declined for this app.' : c === 'rate_limited' ? 'Too many requests just now. Please wait a moment and ask again.' : c === 'aborted' || c === 'canceled' || (e && e.name === 'AbortError') ? 'Stopped.' : 'That didn\'t work. Please try again in a moment.'; }
      list.push({ q: q, a: ans, err: err, at: Date.now() }); if (list.length > 20) s.ai[id] = list.slice(-20);
      SAI.busy = false; SAI.live = ''; SAI.ctl = null; smsv(); render();
      var box = document.getElementById('smaichat'); if (box && box.lastElementChild) box.lastElementChild.scrollIntoView({ block: 'nearest' });
    }
    function boxHtml(s, id) {
      if (!SAI.open) return '<div class="smaibar"><button data-act="smai">' + ic('spark', 15) + ' Study helper</button><span class="dim small">Ask Claude about the text and your work in this stage. It never writes into your sermon.</span></div>';
      var list = (s.ai && s.ai[id]) || [], live = SAI.busy && SAI.sid === s.id && SAI.stage === id;
      return '<section class="wzask smai" aria-label="Study helper"><div class="wzrow"><b>' + ic('spark', 15) + ' Study helper</b><span class="sp"></span><button class="ib" data-act="smai" aria-label="Close">' + ic('x', 15) + '</button></div>' +
        '<p class="wzhint">Claude reads your main passage and what you have written in this stage. References are checked against the Bible; any not found are marked ⚠. It helps you study — the sermon stays yours, so weigh every answer against the text.</p>' +
        '<div class="wzchat" id="smaichat">' + list.map(function (m, i) { return '<div class="wzq">' + esc(m.q) + '</div><div class="wza">' + wzAnsHtml(m.a) + (m.err ? '<p class="dim small">' + esc(m.err) + '</p>' : '') + (m.a ? '<div class="wzrow small"><button class="lnk" data-act="smaicopy" data-i="' + i + '">Copy</button></div>' : '') + '</div>'; }).join('') +
        (live ? '<div class="wzq">' + esc(SAI.q) + '</div><div class="wza" id="smailive">' + (SAI.live ? wzAnsHtml(SAI.live) : '<p class="dim">Reading the passage…</p>') + '</div>' : '') + '</div>' +
        (!live ? '<div class="wzchips">' + (CHIPS[id] || []).map(function (q) { return '<button class="chip" data-act="smaiq" data-q="' + esca(q) + '">' + esc(q) + '</button>'; }).join('') + '</div>' : '') +
        '<div class="wzform"><textarea id="smaiq" rows="2" placeholder="Ask about this passage or this stage…" aria-label="Your question"></textarea>' + (SAI.busy ? '<button data-act="smaistop">Stop</button>' : '<button class="pri" data-act="smaiq">Ask</button>') + (list.length && !SAI.busy ? '<button class="lnk" data-act="smaiclr">Clear</button>' : '') + '</div></section>';
    }
    var stageBodyAI = stageBody;
    stageBody = function (s, id) { var h = stageBodyAI(s, id); if (/class="smlock"/.test(h)) return h; return h + boxHtml(s, id); };
    var actAI = act;
    act = function (a, d) {
      d = d || {};
      if (a === 'smai' || a === 'smaiq' || a === 'smaistop' || a === 'smaiclr' || a === 'smaicopy') {
        var s = cur2(); if (!s) return; var id = SW.stage || 'found';
        if (a === 'smai') { SAI.open = !SAI.open; render(); if (SAI.open) { var b = document.querySelector('.smai'); if (b) b.scrollIntoView({ block: 'nearest', behavior: 'smooth' }); } return; }
        if (a === 'smaistop') { if (SAI.ctl) SAI.ctl.abort(); return; }
        if (a === 'smaiclr') { if (s.ai) s.ai[id] = []; smsv(); render(); return; }
        if (a === 'smaicopy') { var m = chat(s, id)[+d.i]; if (m && m.a) { var t = m.a; (navigator.clipboard && navigator.clipboard.writeText ? navigator.clipboard.writeText(t) : Promise.reject()).then(function () { toast('Copied'); }, function () { var ta = document.createElement('textarea'); ta.value = t; document.body.appendChild(ta); ta.select(); try { document.execCommand('copy'); toast('Copied'); } catch (e) {} ta.remove(); }); } return; }
        var q = d.q || (($('#smaiq') || {}).value || '').trim(); if (!q) { toast('Type a question'); return; }
        run(s, id, q); return;
      }
      return actAI(a, d);
    };
    document.addEventListener('keydown', function (e) { if (e.key === 'Enter' && !e.shiftKey && e.target && e.target.id === 'smaiq') { e.preventDefault(); act('smaiq', {}); } });
  })();

  // 37. a calmer phone layout: bottom tabs for the main places, a compact chapter header, the book introduction and
  // chapter summary folded into one short card, and a lighter Home page. Phones only; tablets and desktops unchanged.
  (function () {
    var PH = function () { return innerWidth <= 700; };
    var SUMX = false; // the folded summary opens for this visit only
    var readP = readHtml;
    readHtml = function () {
      var h = readP.apply(this, arguments);
      if (!PH() || h.indexOf('class="sumbox"') < 0) return h;
      return h.replace('<section class="sumbox"', '<section class="sumbox' + (SUMX ? ' open' : ' fold') + '"').replace('<div class="sumfoot">', '<button class="sumtgl" data-act="sumx">' + (SUMX ? 'Show less' : 'More about this book and chapter') + ' ' + '<span style="display:inline-block;transform:rotate(' + (SUMX ? 180 : 0) + 'deg)">' + ic('cd', 14) + '</span>' + '</button><div class="sumfoot">');
    };
    var TABS = [['home', 'home', 'Home'], ['read', 'book', 'Read'], ['plans', 'cal', 'Plans'], ['study', 'chart', 'Study'], ['side', 'menu', 'More']];
    var tabOn = function () { return view === 'home' ? 'home' : view === 'read' ? 'read' : view === 'plans' ? 'plans' : (view === 'study' || view === 'wstudy' || view === 'analyze') ? 'study' : ''; };
    var renderPH = render;
    render = function () {
      renderPH();
      if (PH()) {
        var pb = document.querySelector('.rd2 .psg');
        if (pb && cur && cur.b) { var bk = cur.b, m = /^(\d) (.+)$/.exec(bk), base = m ? m[2] : bk, ab = base.length > 5 ? base.slice(0, base === 'Philippians' || base === 'Philemon' ? 5 : base === 'Judges' ? 4 : 3) : base; ab = (m ? m[1] + ' ' : '') + ab; for (var ci = 0; ci < pb.childNodes.length; ci++) { var nd = pb.childNodes[ci]; if (nd.nodeType === 3 && nd.textContent.trim()) { nd.textContent = ab + ' ' + cur.c + ' '; break; } } pb.title = bk + ' ' + cur.c + ' - go to passage'; }
        var VL2 = { vcopen: 'Card', favr: 'Save', cpyr: 'Copy' };
        document.querySelectorAll('.votd .acts button').forEach(function (b) { var k = b.dataset.act ? VL2[b.dataset.act] : (b.classList.contains('pri') ? 'Read' : null); if (!k) return; for (var i = 0; i < b.childNodes.length; i++) { var nd = b.childNodes[i]; if (nd.nodeType === 3 && nd.textContent.trim()) { nd.textContent = ' ' + k; b.setAttribute('aria-label', nd.textContent.trim()); break; } } });
      }
      var old = document.getElementById('mtab'); if (old) old.remove();
      var show = PH() && view !== 'kingdom';
      document.body.classList.toggle('hasmtab', show);
      if (!show) return;
      var on = tabOn(), n = document.createElement('nav'); n.id = 'mtab'; n.className = 'mtab'; n.setAttribute('aria-label', 'Main');
      n.innerHTML = TABS.map(function (t) { return '<button data-act="' + t[0] + '" class="' + (on === t[0] || (t[0] === 'side' && side) ? 'on' : '') + '"' + (on === t[0] ? ' aria-current="page"' : '') + '>' + ic(t[1], 21) + '<span>' + t[2] + '</span></button>'; }).join('');
      document.body.appendChild(n);
    };
    var actPH = act;
    act = function (a, d) {
      if (a === 'sumx') { SUMX = !SUMX; render(); return; }
      return actPH(a, d);
    };
  })();

  // 38. brand splash: the full logo shows while the app loads, then fades (tap to skip); icon-only artwork elsewhere
  (function () {
    var sp = document.getElementById('bsplash'); if (!sp) return;
    var t0 = Date.now(), gone = false;
    var hide = function () { if (gone) return; gone = true; sp.style.opacity = '0'; setTimeout(function () { if (sp.parentNode) sp.remove(); }, 480); };
    sp.addEventListener('click', hide);
    var reduce = false; try { reduce = matchMedia('(prefers-reduced-motion: reduce)').matches; } catch (e) {}
    if (reduce) sp.style.transition = 'none';
    setTimeout(hide, Math.max(0, 900 - (Date.now() - t0))); // the app has rendered by the time this script finishes
    setTimeout(hide, 4000); // never stay longer than this
  })();

  // reopen a page the app's start-up list doesn't know about
  var v0 = store.g('view', null); if (v0 === 'plans' || v0 === 'sermons' || v0 === 'wstudy' || v0 === 'obooks' || v0 === 'account' || v0 === 'reflall' || v0 === 'themes') view = v0;
  render();
  window.__scriptureUpgrade = 'v16';
})();
